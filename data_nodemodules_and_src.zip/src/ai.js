import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const settingsPath = fileURLToPath(new URL("../data/ai-settings.json", import.meta.url));
const cooldownMs = 10_000;
const maxPromptLength = 1500;
const maxHistoryEntries = 12;
const userCooldowns = new Map();
const channelHistories = new Map();
const channelQueues = new Map();
let settingsQueue = Promise.resolve();

async function updateSettings(update, persist = true) {
  const task = settingsQueue.then(async () => {
    let settings;
    try {
      settings = JSON.parse(await readFile(settingsPath, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      settings = {};
    }

    const result = update(settings);
    if (persist) {
      await mkdir(new URL("../data/", import.meta.url), { recursive: true });
      const temporaryPath = `${settingsPath}.${process.pid}.tmp`;
      await writeFile(temporaryPath, `${JSON.stringify(settings, null, 2)}\n`, "utf8");
      await rename(temporaryPath, settingsPath);
    }
    return result;
  });

  settingsQueue = task.catch(() => {});
  return task;
}

function getGuildSettings(settings, guildId) {
  const saved = settings[guildId] ?? {};
  return {
    enabled: saved.enabled !== false,
    channelId: saved.channelId ?? null,
  };
}

function clearGuildHistory(guildId) {
  for (const key of channelHistories.keys()) {
    if (key.startsWith(`${guildId}:`)) channelHistories.delete(key);
  }
}

export function getAiSettings(guildId) {
  return updateSettings((settings) => getGuildSettings(settings, guildId), false);
}

export function setAiChannel(guildId, channelId) {
  clearGuildHistory(guildId);
  return updateSettings((settings) => {
    const guildSettings = settings[guildId] ??= {};
    guildSettings.channelId = channelId;
    return getGuildSettings(settings, guildId);
  });
}

export function unlinkAiChannel(guildId) {
  clearGuildHistory(guildId);
  return updateSettings((settings) => {
    const guildSettings = settings[guildId] ??= {};
    guildSettings.channelId = null;
    return getGuildSettings(settings, guildId);
  });
}

export function setAiEnabled(guildId, enabled) {
  if (!enabled) clearGuildHistory(guildId);
  return updateSettings((settings) => {
    const guildSettings = settings[guildId] ??= {};
    guildSettings.enabled = enabled;
    return getGuildSettings(settings, guildId);
  });
}

function claimUserCooldown(guildId, userId) {
  const key = `${guildId}:${userId}`;
  const now = Date.now();
  if (userCooldowns.size > 10_000) {
    for (const [cooldownKey, timestamp] of userCooldowns) {
      if (now - timestamp >= cooldownMs) userCooldowns.delete(cooldownKey);
    }
  }

  const previous = userCooldowns.get(key) ?? 0;
  if (now - previous < cooldownMs) {
    return `Please wait ${Math.ceil((cooldownMs - (now - previous)) / 1000)} seconds before asking again.`;
  }
  userCooldowns.set(key, now);
  return null;
}

async function requestGemini(contents) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("Gemini AI is not configured. Set GEMINI_API_KEY in the bot's .env file.");

  const model = process.env.GEMINI_MODEL || "gemini-3.8-flash";
  let response;
  try {
    response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: "You are a helpful assistant chatting in a Discord community. Be clear, friendly, and concise." }],
          },
          contents,
          generationConfig: { maxOutputTokens: 900, temperature: 0.7 },
        }),
        signal: AbortSignal.timeout(30_000),
      }
    );
  } catch (error) {
    if (error.name === "TimeoutError") throw new Error("Gemini did not respond within 30 seconds.", { cause: error });
    throw new Error("Could not reach the Gemini API.", { cause: error });
  }

  let payload;
  try {
    payload = await response.json();
  } catch (error) {
    throw new Error("Gemini returned an unreadable response.", { cause: error });
  }
  if (!response.ok) {
    const detail = payload.error?.message;
    throw new Error(`Gemini API returned HTTP ${response.status}${detail ? `: ${detail}` : "."}`);
  }

  const text = payload.candidates?.[0]?.content?.parts
    ?.map((part) => part.text ?? "")
    .join("")
    .trim();
  if (!text) throw new Error("Gemini returned no text for this request.");
  return text;
}

export async function askAi(guildId, userId, prompt) {
  const settings = await getAiSettings(guildId);
  if (!settings.enabled) return { error: "AI is disabled by this server's admins." };
  if (!process.env.GEMINI_API_KEY) return { error: "AI is not configured. The bot owner must set GEMINI_API_KEY." };
  if (!prompt.trim()) return { error: "Enter a question for the AI." };
  if (prompt.length > maxPromptLength) return { error: `Questions must be ${maxPromptLength} characters or fewer.` };

  const cooldownError = claimUserCooldown(guildId, userId);
  if (cooldownError) return { error: cooldownError };
  const text = await requestGemini([{ role: "user", parts: [{ text: prompt.trim() }] }]);
  return { text };
}

async function respondInChannel(message) {
  const settings = await getAiSettings(message.guildId);
  if (!settings.enabled || settings.channelId !== message.channelId) return { status: "inactive" };

  const prompt = message.content.trim();
  if (!prompt) return { status: "ignored" };
  if (prompt.length > maxPromptLength) {
    return { error: `Messages in this AI channel must be ${maxPromptLength} characters or fewer.` };
  }

  const cooldownError = claimUserCooldown(message.guildId, message.author.id);
  if (cooldownError) return { status: "cooldown" };

  const historyKey = `${message.guildId}:${message.channelId}`;
  const history = channelHistories.get(historyKey) ?? [];
  const text = await requestGemini([
    ...history,
    { role: "user", parts: [{ text: prompt }] },
  ]);
  const latestSettings = await getAiSettings(message.guildId);
  if (!latestSettings.enabled || latestSettings.channelId !== message.channelId) {
    return { status: "inactive" };
  }

  const updatedHistory = [
    ...history,
    { role: "user", parts: [{ text: prompt }] },
    { role: "model", parts: [{ text }] },
  ];
  channelHistories.set(historyKey, updatedHistory.slice(-maxHistoryEntries));
  return { status: "responded", text };
}

export function handleAiChannelMessage(message) {
  const key = `${message.guildId}:${message.channelId}`;
  const previous = channelQueues.get(key) ?? Promise.resolve();
  const task = previous.then(() => respondInChannel(message));
  const settledTask = task.then(() => {}, () => {}).finally(() => {
    if (channelQueues.get(key) === settledTask) channelQueues.delete(key);
  });
  channelQueues.set(key, settledTask);
  return task;
}

export function truncateAiResponse(text) {
  const maxLength = 1900;
  return text.length > maxLength ? `${text.slice(0, maxLength - 3)}...` : text;
}
