import { randomInt } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const economyPath = fileURLToPath(new URL("../data/economy.json", import.meta.url));
const initialBalance = 100;
const dailyReward = 50;
export const slotSymbols = [
  { emoji: "🍒", name: "Cherry", weight: 12, multiplier: 7 },
  { emoji: "🍋", name: "Lemon", weight: 9, multiplier: 11 },
  { emoji: "🍉", name: "Watermelon", weight: 6, multiplier: 26 },
  { emoji: "🔔", name: "Bell", weight: 4, multiplier: 64 },
  { emoji: "💎", name: "Diamond", weight: 1, multiplier: 320 },
];
export const slotWildSymbol = "🃏";
export const slotReelCount = 4;
export const slotRtpMinPercent = 85;
export const slotRtpMaxPercent = 98;
const weightedSlotSymbols = [
  ...slotSymbols,
  { emoji: slotWildSymbol, name: "WILD", weight: 1, multiplier: 0 },
];
const slotTotalWeight = weightedSlotSymbols.reduce((total, symbol) => total + symbol.weight, 0);
const rouletteRedNumbers = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
let queue = Promise.resolve();
const slotCooldownMs = 5_000;
const slotCooldowns = new Map();

export function randomSlotSymbol() {
  let roll = randomInt(slotTotalWeight);
  for (const symbol of weightedSlotSymbols) {
    roll -= symbol.weight;
    if (roll < 0) return symbol.emoji;
  }
  throw new Error("Slot symbol weights must add up to the total weight.");
}

export function getSlotOutcome(result) {
  if (result.length !== slotReelCount) {
    throw new RangeError(`A slot result must contain exactly ${slotReelCount} symbols.`);
  }
  if (result.some((reel) => !weightedSlotSymbols.some((symbol) => symbol.emoji === reel))) {
    throw new RangeError("A slot result contains an unknown symbol.");
  }

  const wildCount = result.filter((reel) => reel === slotWildSymbol).length;
  let bestOutcome = { symbol: null, matchCount: 0, multiplier: 0, usedWilds: false };
  for (const symbol of slotSymbols) {
    const matchCount = result.filter((reel) => reel === symbol.emoji).length + wildCount;
    if (matchCount < 3) continue;

    const multiplier = matchCount === slotReelCount ? symbol.multiplier * 2 : symbol.multiplier;
    if (multiplier > bestOutcome.multiplier) {
      bestOutcome = {
        symbol,
        matchCount,
        multiplier,
        usedWilds: wildCount > 0,
      };
    }
  }
  return bestOutcome;
}

export function getSlotMultiplier(result) {
  return getSlotOutcome(result).multiplier;
}

function calculateBaseSlotRtp() {
  let weightedMultiplier = 0;
  function visit(reels, weight) {
    if (reels.length === slotReelCount) {
      weightedMultiplier += (weight / slotTotalWeight ** slotReelCount) * getSlotMultiplier(reels);
      return;
    }
    for (const symbol of weightedSlotSymbols) {
      visit([...reels, symbol.emoji], weight * symbol.weight);
    }
  }
  visit([], 1);
  return weightedMultiplier * 100;
}

export const slotBaseRtpPercent = calculateBaseSlotRtp();

const blackjackCardNames = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const drawBlackjackCard = () => blackjackCardNames[randomInt(blackjackCardNames.length)];

function blackjackHandValue(cards) {
  let value = 0;
  let aces = 0;
  for (const card of cards) {
    if (card === "A") {
      value += 11;
      aces += 1;
    } else {
      value += Number(card) || 10;
    }
  }
  while (value > 21 && aces > 0) {
    value -= 10;
    aces -= 1;
  }
  return value;
}

export function playGame(game, wager) {
  let won = false;
  let detail;
  let payout = 0;
  let jackpot = false;
  let push = false;
  let reels;
  let slotMatchCount;
  let payoutPercent;
  let rtpTargetPercent;

  if (game === "coinflip") {
    const result = randomInt(2) === 0 ? "heads" : "tails";
    won = result === "heads";
    payout = won ? wager * 2 : 0;
    detail = `The coin landed **${result}**.`;
  } else if (game === "dice") {
    const result = randomInt(1, 7);
    won = result >= 4;
    payout = won ? wager * 2 : 0;
    detail = `The die rolled **${result}**.`;
  } else if (game === "slots") {
    reels = Array.from({ length: slotReelCount }, randomSlotSymbol);
    const outcome = getSlotOutcome(reels);
    rtpTargetPercent = randomInt(slotRtpMinPercent, slotRtpMaxPercent + 1);
    const adjustedMultiplier = outcome.multiplier * rtpTargetPercent / slotBaseRtpPercent;
    payout = Math.floor(wager * adjustedMultiplier);
    won = outcome.multiplier > 0;
    jackpot = outcome.symbol?.emoji === "💎" && outcome.matchCount === slotReelCount;
    slotMatchCount = outcome.matchCount;
    payoutPercent = won ? Math.round((payout / wager) * 100) : 0;
    detail = won
      ? `${outcome.matchCount} matching ${outcome.symbol.name}${outcome.usedWilds ? " (WILD substituted)" : ""}.`
      : "No match.";
  } else if (game === "blackjack") {
    const playerCards = [drawBlackjackCard(), drawBlackjackCard()];
    const dealerCards = [drawBlackjackCard(), drawBlackjackCard()];
    const playerNatural = blackjackHandValue(playerCards) === 21;
    const dealerNatural = blackjackHandValue(dealerCards) === 21;

    while (blackjackHandValue(playerCards) < 17 && !playerNatural) {
      playerCards.push(drawBlackjackCard());
    }
    while (blackjackHandValue(dealerCards) < 17 && blackjackHandValue(playerCards) <= 21) {
      dealerCards.push(drawBlackjackCard());
    }

    const playerScore = blackjackHandValue(playerCards);
    const dealerScore = blackjackHandValue(dealerCards);
    if (playerNatural || dealerNatural) {
      if (playerNatural && dealerNatural) {
        push = true;
      } else if (playerNatural) {
        won = true;
        payout = wager * 2 + Math.floor(wager / 2);
      }
    } else if (playerScore <= 21) {
      if (dealerScore > 21 || playerScore > dealerScore) {
        won = true;
        payout = wager * 2;
      } else if (playerScore === dealerScore) {
        push = true;
      }
    }

    const result = push
      ? "It's a push; your wager is returned."
      : won
        ? "Blackjack! You win."
        : playerScore > 21
          ? "You bust. The dealer wins."
          : dealerScore > 21
            ? "The dealer busts. You win."
            : "The dealer wins.";
    detail = `You: **${playerCards.join(", ")}** (${playerScore}) · Dealer: **${dealerCards.join(", ")}** (${dealerScore}). ${result}`;
  } else if (game === "roulette") {
    const number = randomInt(37);
    const color = number === 0 ? "green" : rouletteRedNumbers.has(number) ? "red" : "black";
    won = color === "red";
    payout = won ? wager * 2 : 0;
    detail = `Roulette landed on **${number} ${color}**. You automatically bet on red.`;
  } else {
    throw new Error(`Unknown gamble game: ${game}`);
  }

  if (push) payout = wager;

  return { won, detail, payout, wager, jackpot, reels, push, slotMatchCount, payoutPercent, rtpTargetPercent };
}

async function updateAccount(guildId, userId, update) {
  const task = queue.then(async () => {
    let economy;
    try {
      economy = JSON.parse(await readFile(economyPath, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      economy = {};
    }

    economy[guildId] ??= {};
    economy[guildId][userId] ??= { balance: initialBalance, lastDaily: null };
    const account = economy[guildId][userId];
    const result = update(account);

    await mkdir(new URL("../data/", import.meta.url), { recursive: true });
    const temporaryPath = `${economyPath}.${process.pid}.tmp`;
    await writeFile(temporaryPath, `${JSON.stringify(economy, null, 2)}\n`, "utf8");
    await rename(temporaryPath, economyPath);
    return result;
  });

  queue = task.catch(() => {});
  return task;
}

export function getBalance(guildId, userId) {
  return updateAccount(guildId, userId, (account) => account.balance);
}

export function claimDaily(guildId, userId) {
  return updateAccount(guildId, userId, (account) => {
    const today = new Date().toISOString().slice(0, 10);
    if (account.lastDaily === today) {
      return { claimed: false, balance: account.balance };
    }

    account.lastDaily = today;
    account.balance += dailyReward;
    return { claimed: true, reward: dailyReward, balance: account.balance };
  });
}

export function placeBet(guildId, userId, game, wager) {
  if (game === "slots") return placeSlotBet(guildId, userId, wager);

  return updateAccount(guildId, userId, (account) => {
    if (wager > account.balance) {
      return { error: "You don't have enough multicoins for that bet.", balance: account.balance };
    }

    const result = playGame(game, wager);
    account.balance += result.payout - wager;
    return { ...result, balance: account.balance };
  });
}

export function placeSlotBet(guildId, userId, wager) {
  const key = `${guildId}:${userId}`;
  if (slotCooldowns.size > 10_000) {
    const now = Date.now();
    for (const [cooldownKey, timestamp] of slotCooldowns) {
      if (now - timestamp >= slotCooldownMs) slotCooldowns.delete(cooldownKey);
    }
  }

  return updateAccount(guildId, userId, (account) => {
    const now = Date.now();
    const previousBet = slotCooldowns.get(key) ?? 0;
    if (now - previousBet < slotCooldownMs) {
      const secondsLeft = Math.ceil((slotCooldownMs - (now - previousBet)) / 1000);
      return {
        error: `Wait ${secondsLeft} second${secondsLeft === 1 ? "" : "s"} before playing slots again.`,
        balance: account.balance,
      };
    }
    if (!Number.isSafeInteger(wager) || wager < 1 || wager > 1000) {
      return { error: "Bet between 1 and 1,000 multicoins.", balance: account.balance };
    }
    if (wager > account.balance) {
      return { error: "You don't have enough multicoins for that bet.", balance: account.balance };
    }

    slotCooldowns.set(key, now);
    account.balance -= wager;
    const result = playGame("slots", wager);
    account.balance += result.payout;
    return { ...result, balance: account.balance };
  });
}
