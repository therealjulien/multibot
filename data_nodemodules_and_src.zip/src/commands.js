import {
  ActionRowBuilder,
  ActivityType,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
} from "discord.js";
import {
  askAi,
  getAiSettings,
  setAiChannel,
  setAiEnabled,
  truncateAiResponse,
  unlinkAiChannel,
} from "./ai.js";
import {
  claimDaily,
  getBalance,
  placeBet,
  placeSlotBet,
  randomSlotSymbol,
  slotRtpMaxPercent,
  slotRtpMinPercent,
  slotReelCount,
} from "./economy.js";
import { getLeaderboard, getUserLevel, resetUserLevel } from "./levels.js";

const economyGuildId = (interaction) => {
  if (interaction.guildId) return interaction.guildId;
  throw new Error("The economy commands can only be used in a server.");
};

const reasonOption = (builder) =>
  builder
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Why this moderation action is being taken")
        .setMaxLength(400)
    );

const moderationTargetProblem = (interaction, target, actor) => {
  if (target.id === interaction.user.id) return "You can't moderate yourself.";
  if (target.id === interaction.guild.ownerId) return "The server owner can't be moderated by a bot.";

  const botMember = interaction.guild.members.me;
  if (
    actor.id !== interaction.guild.ownerId &&
    target.roles.highest.comparePositionTo(actor.roles.highest) >= 0
  ) {
    return "That member's highest role must be below your highest role.";
  }
  if (!botMember) return "I couldn't verify the bot's role hierarchy. Please try again.";
  if (target.roles.highest.comparePositionTo(botMember.roles.highest) >= 0) {
    return "That member's highest role must be below the bot's highest role.";
  }
  return null;
};

const memberOption = (builder) =>
  builder.addUserOption((option) =>
    option.setName("user").setDescription("The member to target").setRequired(true)
  );

const kick = {
  data: reasonOption(
    memberOption(
      new SlashCommandBuilder()
        .setName("kick")
        .setDescription("Remove a member from the server")
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    )
  ),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const user = interaction.options.getUser("user", true);
    const target = await interaction.guild.members.fetch(user.id);
    const actor = await interaction.guild.members.fetch(interaction.user.id);
    const problem = moderationTargetProblem(interaction, target, actor);
    if (problem) return interaction.editReply(problem);

    await target.kick(interaction.options.getString("reason") ?? `Kicked by ${interaction.user.tag}`);
    return interaction.editReply(`👢 ${user.tag} has been kicked.`);
  },
};

const ban = {
  data: reasonOption(
    memberOption(
      new SlashCommandBuilder()
        .setName("ban")
        .setDescription("Ban a member from the server")
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    )
  ),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const user = interaction.options.getUser("user", true);
    const target = await interaction.guild.members.fetch(user.id);
    const actor = await interaction.guild.members.fetch(interaction.user.id);
    const problem = moderationTargetProblem(interaction, target, actor);
    if (problem) return interaction.editReply(problem);

    await target.ban({ reason: interaction.options.getString("reason") ?? `Banned by ${interaction.user.tag}` });
    return interaction.editReply(`🔨 ${user.tag} has been banned.`);
  },
};

const warn = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a server member publicly and by direct message")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((option) =>
      option.setName("user").setDescription("Member to warn").setRequired(true)
    )
    .addStringOption((option) =>
      option.setName("reason").setDescription("Reason for the warning").setRequired(true).setMaxLength(400)
    ),
  async execute(interaction) {
    if (!interaction.guild || !interaction.channel || !("send" in interaction.channel)) {
      return interaction.reply({ content: "This command only works in a server channel where I can post.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    const user = interaction.options.getUser("user", true);
    const target = await interaction.guild.members.fetch(user.id);
    const actor = await interaction.guild.members.fetch(interaction.user.id);
    if (target.id === interaction.user.id) return interaction.editReply("You can't warn yourself.");
    if (target.id === interaction.guild.ownerId) return interaction.editReply("The server owner can't be warned.");
    if (
      actor.id !== interaction.guild.ownerId &&
      target.roles.highest.comparePositionTo(actor.roles.highest) >= 0
    ) {
      return interaction.editReply("That member's highest role must be below your highest role.");
    }

    const reason = interaction.options.getString("reason", true);
    await interaction.channel.send({
      content: `⚠️ <@${user.id}> has received a moderator warning. **Reason:** ${reason}`,
      allowedMentions: { users: [user.id] },
    });

    const warningEmbed = new EmbedBuilder()
      .setColor(0xed4245)
      .setTitle(`Warning in ${interaction.guild.name}`)
      .setDescription(reason)
      .addFields({ name: "Moderator", value: interaction.user.tag });
    let dmDelivered = true;
    try {
      await user.send({ embeds: [warningEmbed] });
    } catch (error) {
      if (error.code !== 50007) throw error;
      dmDelivered = false;
    }

    return interaction.editReply(
      dmDelivered
        ? `⚠️ Warning posted in this server and sent to ${user.tag} by DM.`
        : `⚠️ Warning posted in this server, but I couldn't DM ${user.tag}; they may have DMs disabled.`
    );
  },
};

const hackban = {
  data: new SlashCommandBuilder()
    .setName("hackban")
    .setDescription("Ban a user by ID, even if they have not joined this server")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption((option) =>
      option.setName("user_id").setDescription("The user's Discord ID").setRequired(true).setMaxLength(20)
    )
    .addStringOption((option) =>
      option.setName("reason").setDescription("Reason for the ban").setMaxLength(400)
    ),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const userId = interaction.options.getString("user_id", true);
    if (!/^\d{17,20}$/.test(userId)) {
      return interaction.editReply("Enter a valid Discord user ID (17–20 digits).");
    }

    const reason = interaction.options.getString("reason") ?? `Hackbanned by ${interaction.user.tag}`;
    let target;
    try {
      target = await interaction.guild.members.fetch(userId);
    } catch (error) {
      if (error.code !== 10007) throw error;
    }

    if (target) {
      const actor = await interaction.guild.members.fetch(interaction.user.id);
      const problem = moderationTargetProblem(interaction, target, actor);
      if (problem) return interaction.editReply(problem);
      await target.ban({ reason });
    } else {
      await interaction.guild.bans.create(userId, { reason });
    }

    return interaction.editReply(`🔨 User ID ${userId} has been banned.`);
  },
};

const timeout = {
  data: reasonOption(
    memberOption(
      new SlashCommandBuilder()
        .setName("timeout")
        .setDescription("Give a member a timeout (up to 28 days)")
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .addIntegerOption((option) =>
          option
            .setName("minutes")
            .setDescription("Timeout length in minutes")
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(40320)
        )
    )
  ),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const user = interaction.options.getUser("user", true);
    const target = await interaction.guild.members.fetch(user.id);
    const actor = await interaction.guild.members.fetch(interaction.user.id);
    const problem = moderationTargetProblem(interaction, target, actor);
    if (problem) return interaction.editReply(problem);

    const minutes = interaction.options.getInteger("minutes", true);
    await target.timeout(
      minutes * 60 * 1000,
      interaction.options.getString("reason") ?? `Timed out by ${interaction.user.tag}`
    );
    return interaction.editReply(`🔇 ${user.tag} has a ${minutes}-minute timeout.`);
  },
};

const purge = {
  data: new SlashCommandBuilder()
    .setName("purge")
    .setDescription("Delete up to 100 recent messages in this channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption((option) =>
      option
        .setName("amount")
        .setDescription("Number of messages to delete")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100)
    ),
  async execute(interaction) {
    if (!interaction.channel || !("bulkDelete" in interaction.channel)) {
      return interaction.reply({ content: "This command only works in a text channel.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    const amount = interaction.options.getInteger("amount", true);
    const deleted = await interaction.channel.bulkDelete(amount, true);
    return interaction.editReply(
      `🧹 Deleted ${deleted.size} message${deleted.size === 1 ? "" : "s"}. Messages older than 14 days are skipped by Discord.`
    );
  },
};

const eightBallAnswers = [
  "Absolutely. The crystal ball has spoken.",
  "Nope. The crystal ball is being dramatic.",
  "The vibes say: probably.",
  "Ask again after the snack break.",
  "Outlook unclear. Try turning the question off and on again.",
  "The prophecy says yes, but in a silly hat.",
  "Not a chance. Even the magic 8-ball is concerned.",
];

const eightBall = {
  data: new SlashCommandBuilder()
    .setName("8ball")
    .setDescription("Ask the suspiciously confident magic 8-ball")
    .addStringOption((option) =>
      option.setName("question").setDescription("What do you want to know?").setRequired(true).setMaxLength(300)
    ),
  async execute(interaction) {
    const answer = eightBallAnswers[Math.floor(Math.random() * eightBallAnswers.length)];
    return interaction.reply(`🎱 **${interaction.options.getString("question", true)}**\n${answer}`);
  },
};

const coinflip = {
  data: new SlashCommandBuilder().setName("coinflip").setDescription("Flip a coin; blame the coin either way"),
  async execute(interaction) {
    const result = Math.random() < 0.5 ? "Heads" : "Tails";
    return interaction.reply(`🪙 **${result}!** The coin accepts no appeals.`);
  },
};

const rps = {
  data: new SlashCommandBuilder()
    .setName("rps")
    .setDescription("Challenge the bot to rock-paper-scissors")
    .addStringOption((option) =>
      option
        .setName("choice")
        .setDescription("Your move")
        .setRequired(true)
        .addChoices(
          { name: "Rock 🪨", value: "rock" },
          { name: "Paper 📄", value: "paper" },
          { name: "Scissors ✂️", value: "scissors" }
        )
    ),
  async execute(interaction) {
    const icons = { rock: "🪨", paper: "📄", scissors: "✂️" };
    const yours = interaction.options.getString("choice", true);
    const theirs = ["rock", "paper", "scissors"][Math.floor(Math.random() * 3)];
    const winsAgainst = { rock: "scissors", paper: "rock", scissors: "paper" };
    const result = yours === theirs ? "It's a draw. The bot calls for a rematch." :
      winsAgainst[yours] === theirs ? "You win! The bot claims it was lag." : "The bot wins. It has been training.";
    return interaction.reply(`${icons[yours]} **You** vs **Bot** ${icons[theirs]}\n${result}`);
  },
};

const wouldYouRather = {
  data: new SlashCommandBuilder().setName("wyr").setDescription("Get a ridiculous would-you-rather dilemma"),
  async execute(interaction) {
    const dilemmas = [
      "Would you rather have a tiny marching band announce every time you enter a room, or a goose narrate your day?",
      "Would you rather fight one horse-sized duck or ten duck-sized horses, but they all know your search history?",
      "Would you rather have spaghetti for hair or sneeze glitter exactly once a week?",
      "Would you rather only communicate through dramatic movie quotes or through interpretive dance?",
      "Would you rather be followed everywhere by elevator music or have a laugh track after every sentence?",
      "Would you rather have a personal theme song that changes with your mood or a tiny wizard who gives unsolicited advice?",
    ];
    const dilemma = dilemmas[Math.floor(Math.random() * dilemmas.length)];
    return interaction.reply(`🤔 ${dilemma}`);
  },
};

const truthOrDare = {
  data: new SlashCommandBuilder()
    .setName("truth-or-dare")
    .setDescription("Get a harmless truth question or a goofy dare")
    .addStringOption((option) =>
      option
        .setName("pick")
        .setDescription("Truth or dare?")
        .setRequired(true)
        .addChoices(
          { name: "Truth", value: "truth" },
          { name: "Dare", value: "dare" }
        )
    ),
  async execute(interaction) {
    const truths = [
      "What is the silliest thing you believed as a kid?",
      "What song do you secretly know every word to?",
      "What is your most oddly specific pet peeve?",
      "If your pet (or a pigeon) could review you, what would it say?",
    ];
    const dares = [
      "Speak like a pirate for your next three messages.",
      "Invent a new holiday and explain its extremely weird tradition.",
      "Give your current snack a dramatic movie-review score.",
      "Send a sentence where every word starts with the same letter.",
    ];
    const list = interaction.options.getString("pick", true) === "truth" ? truths : dares;
    const prompt = list[Math.floor(Math.random() * list.length)];
    return interaction.reply(`🎭 **${interaction.options.getString("pick", true)}!** ${prompt}`);
  },
};

const trivia = {
  data: new SlashCommandBuilder()
    .setName("trivia")
    .setDescription("What is a group of flamingos called?")
    .addStringOption((option) =>
      option
        .setName("answer")
        .setDescription("Pick your answer")
        .setRequired(true)
        .addChoices(
          { name: "A) A group of flamingos", value: "flamingos" },
          { name: "B) A group of cats", value: "cats" },
          { name: "C) A group of frogs", value: "frogs" }
        )
    ),
  async execute(interaction) {
    const answer = interaction.options.getString("answer", true);
    return interaction.reply(
      `🧠 What is the collective noun for flamingos? You picked **${answer}**. ${answer === "flamingos" ? "Correct! It's a flamboyance. Fancy birds, fancy name." : "Not quite! The answer is a flamboyance. The frogs are forming a committee about this."}`
    );
  },
};

const numberGuess = {
  data: new SlashCommandBuilder()
    .setName("number-guess")
    .setDescription("Guess the bot's number from 1 to 10")
    .addIntegerOption((option) =>
      option.setName("guess").setDescription("Your guess").setRequired(true).setMinValue(1).setMaxValue(10)
    ),
  async execute(interaction) {
    const guess = interaction.options.getInteger("guess", true);
    const answer = Math.floor(Math.random() * 10) + 1;
    const result = guess === answer
      ? "Bullseye! The number-guessing goblin respects you."
      : guess < answer
        ? "Too low! The number has gone to live on a taller shelf."
        : "Too high! The number has requested you calm down.";
    return interaction.reply(`🔢 The number was **${answer}**. ${result}`);
  },
};

const riddle = {
  data: new SlashCommandBuilder().setName("riddle").setDescription("Try a tiny riddle (the answer is spoiler-hidden)"),
  async execute(interaction) {
    const riddles = [
      ["What has keys but can't open locks?", "A piano."],
      ["What gets wetter the more it dries?", "A towel."],
      ["What has a face and two hands but no arms or legs?", "A clock."],
      ["What has one eye but cannot see?", "A needle."],
    ];
    const [question, answer] = riddles[Math.floor(Math.random() * riddles.length)];
    return interaction.reply(`🧩 ${question}\n||${answer}||`);
  },
};

const sillyStory = {
  data: new SlashCommandBuilder()
    .setName("sillystory")
    .setDescription("Make a ridiculous mini-story with your words")
    .addStringOption((option) =>
      option.setName("noun").setDescription("A person, place, or thing").setRequired(true).setMaxLength(40)
    )
    .addStringOption((option) =>
      option.setName("adjective").setDescription("A describing word").setRequired(true).setMaxLength(40)
    )
    .addStringOption((option) =>
      option.setName("verb").setDescription("An action word").setRequired(true).setMaxLength(40)
    ),
  async execute(interaction) {
    const noun = interaction.options.getString("noun", true);
    const adjective = interaction.options.getString("adjective", true);
    const verb = interaction.options.getString("verb", true);
    return interaction.reply(
      `📚 Breaking news: A ${adjective} ${noun} was spotted trying to ${verb} its way into the mayor's office. It is now wanted for crimes against grammar.`
    );
  },
};

const emojiQuiz = {
  data: new SlashCommandBuilder()
    .setName("emoji-quiz")
    .setDescription("Decode this phrase: a pig plus a flying plane")
    .addStringOption((option) =>
      option
        .setName("answer")
        .setDescription("What do the emojis mean?")
        .setRequired(true)
        .addChoices(
          { name: "A) When pigs fly", value: "pigs" },
          { name: "B) A piece of cake", value: "cake" },
          { name: "C) Let the cat out of the bag", value: "cat" }
        )
    ),
  async execute(interaction) {
    const answer = interaction.options.getString("answer", true);
    return interaction.reply(
      `🐷✈️ Decode this: You picked **${answer}**. ${answer === "pigs" ? "Correct! When pigs fly!" : "Close, but it's **when pigs fly**. The pigs have excellent air miles."}`
    );
  },
};

const ai = {
  data: new SlashCommandBuilder()
    .setName("ai")
    .setDescription("Ask Gemini AI a question")
    .addStringOption((option) =>
      option
        .setName("prompt")
        .setDescription("What would you like to ask?")
        .setRequired(true)
        .setMinLength(1)
        .setMaxLength(1500)
    ),
  async execute(interaction) {
    if (!interaction.guildId) {
      return interaction.reply({ content: "AI can only be used in a server.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    try {
      const result = await askAi(
        interaction.guildId,
        interaction.user.id,
        interaction.options.getString("prompt", true)
      );
      return interaction.editReply({
        content: result.error ?? truncateAiResponse(result.text),
        allowedMentions: { parse: [] },
      });
    } catch (error) {
      console.error("Gemini request failed for /ai:", error);
      return interaction.editReply("Gemini couldn't answer right now. Please try again later.");
    }
  },
};

const aiChannel = {
  data: new SlashCommandBuilder()
    .setName("ai-channel")
    .setDescription("Configure this server's AI chat channel (Manage Server required)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((option) =>
      option
        .setName("action")
        .setDescription("Choose how to configure AI")
        .setRequired(true)
        .addChoices(
          { name: "Setup a new #ai-chat channel", value: "setup" },
          { name: "Link this existing channel", value: "link" },
          { name: "Unlink the AI channel (keeps the channel)", value: "unlink" },
          { name: "Enable AI for this server", value: "enable" },
          { name: "Disable AI for this server", value: "disable" }
        )
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ content: "Manage Server permission is required.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    const action = interaction.options.getString("action", true);
    if (action === "disable" || action === "enable") {
      const settings = await setAiEnabled(interaction.guildId, action === "enable");
      return interaction.editReply(`AI is now **${settings.enabled ? "enabled" : "disabled"}** for this server.`);
    }

    if (action === "unlink") {
      const previousSettings = await getAiSettings(interaction.guildId);
      await unlinkAiChannel(interaction.guildId);
      return interaction.editReply(
        previousSettings.channelId
          ? "The AI channel link was removed. The Discord channel itself was not deleted."
          : "No AI channel was linked. No Discord channel was deleted."
      );
    }

    if (action === "setup") {
      const existingSettings = await getAiSettings(interaction.guildId);
      if (existingSettings.channelId) {
        return interaction.editReply("An AI channel is already linked. Unlink it first, or use the link action to connect a different channel.");
      }
      if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.editReply("Manage Channels permission is required to create an AI chat channel.");
      }

      const botMember = interaction.guild.members.me;
      if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.editReply("I need the Manage Channels permission to create an AI chat channel.");
      }

      const channel = await interaction.guild.channels.create({
        name: "ai-chat",
        type: ChannelType.GuildText,
        topic: "Chat with Gemini AI. Messages here are sent to Google's Gemini API.",
        permissionOverwrites: [{
          id: interaction.client.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        }],
      });
      await setAiChannel(interaction.guildId, channel.id);
      return interaction.editReply(`Created and linked ${channel}. Messages there will receive AI replies.`);
    }

    if (interaction.channel?.type !== ChannelType.GuildText) {
      return interaction.editReply("Run the link action in the regular text channel you want to use for AI chat.");
    }

    const botMember = interaction.guild.members.me;
    const permissions = botMember && interaction.channel.permissionsFor(botMember);
    if (!permissions?.has([
      PermissionFlagsBits.ViewChannel,
      PermissionFlagsBits.SendMessages,
      PermissionFlagsBits.ReadMessageHistory,
    ])) {
      return interaction.editReply("I need View Channel, Send Messages, and Read Message History permissions there.");
    }

    await setAiChannel(interaction.guildId, interaction.channel.id);
    return interaction.editReply(`Linked ${interaction.channel} as this server's AI chat channel.`);
  },
};

const balance = {
  data: new SlashCommandBuilder().setName("balance").setDescription("Check your multicoins balance"),
  async execute(interaction) {
    const coins = await getBalance(economyGuildId(interaction), interaction.user.id);
    return interaction.reply(`🪙 You have **${coins} multicoins**.`);
  },
};

const daily = {
  data: new SlashCommandBuilder().setName("daily").setDescription("Collect your once-a-day multicoins allowance"),
  async execute(interaction) {
    const result = await claimDaily(economyGuildId(interaction), interaction.user.id);
    const message = result.claimed
      ? `🎁 Daily allowance claimed: **+${result.reward} multicoins**. New balance: **${result.balance} multicoins**.`
      : `⏰ You already collected today's allowance. Your balance is **${result.balance} multicoins**.`;
    return interaction.reply(message);
  },
};

const gambleTitles = {
  coinflip: "🪙 Coin Flip",
  dice: "🎲 Dice",
  slots: "🎰 Slots",
  blackjack: "🃏 Blackjack",
  roulette: "🎡 Roulette — Red",
};

const createGambleEmbed = (game, result, frameReels, lockedReels = 0) => {
  const isSpinning = Boolean(frameReels);
  const embed = new EmbedBuilder()
    .setColor(isSpinning ? 0x5865f2 : result.jackpot ? 0xf1c40f : result.won ? 0x57f287 : result.push ? 0x95a5a6 : 0xed4245)
    .setTitle(gambleTitles[game]);

  if (isSpinning) {
    return embed
      .setDescription(`[ ${frameReels.join(" │ ")} ]`)
      .setFooter({ text: `Spinning… ${lockedReels}/${slotReelCount} reels stopped` });
  }

  const outcome = game === "slots"
    ? result.won
      ? `${result.jackpot ? "JACKPOT! " : ""}${result.detail} ${result.payoutPercent}% payout (${result.payout} multicoins).`
      : `No 3+ match — lost ${result.wager} multicoins.`
    : result.push
      ? `Push — your ${result.wager} multicoins were returned.`
      : result.won
        ? `${result.jackpot ? "JACKPOT! " : ""}Won ${result.payout - result.wager} multicoins.`
        : `Lost ${result.wager} multicoins.`;
  const description = game === "slots"
    ? `[ ${result.reels.join(" │ ")} ]`
    : result.detail;

  const fields = [
    { name: "Result", value: outcome, inline: true },
    { name: "Balance", value: `${result.balance} multicoins`, inline: true },
  ];
  if (game === "slots") {
    fields.push({ name: "RTP target", value: `${result.rtpTargetPercent}% this spin`, inline: true });
  }

  return embed
    .setDescription(description)
    .addFields(fields)
    .setFooter({ text: "Multicoins are virtual and have no cash value." });
};

const gamble = {
  data: new SlashCommandBuilder()
    .setName("gamble")
    .setDescription("Bet multicoins on a game (no real money or prizes)")
    .addStringOption((option) =>
      option
        .setName("game")
        .setDescription("Choose a game; roulette automatically bets red")
        .setRequired(true)
        .addChoices(
          { name: "Coin flip (win on heads)", value: "coinflip" },
          { name: "Dice (win on 4–6)", value: "dice" },
          { name: "Blackjack (automatic play)", value: "blackjack" },
          { name: "Roulette (auto-bet red)", value: "roulette" }
        )
    )
    .addIntegerOption((option) =>
      option.setName("wager").setDescription("Multicoins to wager (1–1000)").setRequired(true).setMinValue(1).setMaxValue(1000)
    ),
  async execute(interaction) {
    const game = interaction.options.getString("game", true);
    const wager = interaction.options.getInteger("wager", true);

    await interaction.deferReply();
    const result = await placeBet(economyGuildId(interaction), interaction.user.id, game, wager);
    if (result.error) {
      const errorEmbed = new EmbedBuilder()
        .setColor(0xed4245)
        .setTitle("Not enough multicoins")
        .setDescription(`${result.error} Balance: **${result.balance} multicoins**.`);
      return interaction.editReply({ embeds: [errorEmbed] });
    }
    return interaction.editReply({ embeds: [createGambleEmbed(game, result)] });
  },
};

const slots = {
  data: new SlashCommandBuilder()
    .setName("slots")
    .setDescription(`Play four-reel slots with WILD cards and ${slotRtpMinPercent}–${slotRtpMaxPercent}% per-spin RTP`)
    .addIntegerOption((option) =>
      option
        .setName("bet")
        .setDescription("Multicoins to wager (1–1000)")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(1000)
    ),
  async execute(interaction) {
    if (!interaction.guildId) {
      return interaction.reply({ content: "Slots can only be played in a server.", ephemeral: true });
    }

    const wager = interaction.options.getInteger("bet", true);
    const result = await placeSlotBet(interaction.guildId, interaction.user.id, wager);
    if (result.error) {
      return interaction.reply({
        content: `${result.error} Balance: **${result.balance} multicoins**.`,
        ephemeral: true,
      });
    }

    await interaction.deferReply();
    const spinStartedAt = Date.now();
    const makeFrame = (lockedReels) =>
      Array.from({ length: slotReelCount }, (_, index) =>
        index < lockedReels ? result.reels[index] : randomSlotSymbol()
      );

    await interaction.editReply({ embeds: [createGambleEmbed("slots", result, makeFrame(0))] });
    for (let lockedReels = 1; lockedReels <= slotReelCount; lockedReels += 1) {
      const nextStopAt = spinStartedAt + Math.round(lockedReels * 5000 / slotReelCount);
      await new Promise((resolve) => setTimeout(resolve, Math.max(0, nextStopAt - Date.now())));
      if (lockedReels === slotReelCount) {
        return interaction.editReply({ embeds: [createGambleEmbed("slots", result)] });
      }
      await interaction.editReply({
        embeds: [createGambleEmbed("slots", result, makeFrame(lockedReels), lockedReels)],
      });
    }
  },
};

const postEmbed = {
  data: new SlashCommandBuilder()
    .setName("embed")
    .setDescription("Post a formatted announcement embed in this channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption((option) =>
      option.setName("title").setDescription("Embed heading").setRequired(true).setMaxLength(256)
    )
    .addStringOption((option) =>
      option.setName("message").setDescription("Embed text").setRequired(true).setMaxLength(4000)
    )
    .addStringOption((option) =>
      option
        .setName("color")
        .setDescription("Embed accent color")
        .addChoices(
          { name: "Discord blue", value: "blue" },
          { name: "Green", value: "green" },
          { name: "Purple", value: "purple" },
          { name: "Orange", value: "orange" },
          { name: "Red", value: "red" }
        )
    )
    .addStringOption((option) =>
      option.setName("footer").setDescription("Optional small footer text").setMaxLength(2048)
    ),
  async execute(interaction) {
    if (!interaction.channel || !("send" in interaction.channel)) {
      return interaction.reply({ content: "This command only works in a channel where I can post.", ephemeral: true });
    }

    const colorValues = {
      blue: 0x5865f2,
      green: 0x57f287,
      purple: 0x9b59b6,
      orange: 0xe67e22,
      red: 0xed4245,
    };
    const color = interaction.options.getString("color") ?? "blue";
    const embed = new EmbedBuilder()
      .setColor(colorValues[color])
      .setTitle(interaction.options.getString("title", true))
      .setDescription(interaction.options.getString("message", true));
    const footer = interaction.options.getString("footer");
    if (footer) embed.setFooter({ text: footer });

    await interaction.deferReply({ ephemeral: true });
    await interaction.channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    return interaction.editReply("📣 Embed posted.");
  },
};

const poll = {
  data: new SlashCommandBuilder()
    .setName("poll")
    .setDescription("Start a reaction-vote poll with 2–5 choices")
    .addStringOption((option) =>
      option.setName("question").setDescription("What are you asking?").setRequired(true).setMaxLength(256)
    )
    .addStringOption((option) =>
      option.setName("option1").setDescription("First choice").setRequired(true).setMaxLength(80)
    )
    .addStringOption((option) =>
      option.setName("option2").setDescription("Second choice").setRequired(true).setMaxLength(80)
    )
    .addStringOption((option) =>
      option.setName("option3").setDescription("Optional third choice").setMaxLength(80)
    )
    .addStringOption((option) =>
      option.setName("option4").setDescription("Optional fourth choice").setMaxLength(80)
    )
    .addStringOption((option) =>
      option.setName("option5").setDescription("Optional fifth choice").setMaxLength(80)
    ),
  async execute(interaction) {
    if (!interaction.channel || !("send" in interaction.channel)) {
      return interaction.reply({ content: "This command only works in a channel where I can post.", ephemeral: true });
    }

    const options = [1, 2, 3, 4, 5]
      .map((number) => interaction.options.getString(`option${number}`))
      .filter(Boolean);
    const emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"];
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(interaction.options.getString("question", true))
      .setDescription(options.map((text, index) => `${emojis[index]} ${text}`).join("\n"))
      .setFooter({ text: `Poll by ${interaction.user.tag} · react to vote` });

    await interaction.deferReply({ ephemeral: true });
    const message = await interaction.channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    for (let index = 0; index < options.length; index += 1) {
      await message.react(emojis[index]);
    }
    return interaction.editReply(`📊 Poll posted in <#${interaction.channelId}>.`);
  },
};

const suggest = {
  data: new SlashCommandBuilder()
    .setName("suggest")
    .setDescription("Post a community suggestion for members to vote on")
    .addStringOption((option) =>
      option.setName("idea").setDescription("Your suggestion").setRequired(true).setMaxLength(1000)
    ),
  async execute(interaction) {
    if (!interaction.channel || !("send" in interaction.channel)) {
      return interaction.reply({ content: "This command only works in a channel where I can post.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x57f287)
      .setTitle("💡 Community suggestion")
      .setDescription(interaction.options.getString("idea", true))
      .setFooter({ text: `Suggested by ${interaction.user.tag}` });

    await interaction.deferReply({ ephemeral: true });
    const message = await interaction.channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    await message.react("👍");
    await message.react("👎");
    return interaction.editReply("💡 Suggestion posted for the community to vote on.");
  },
};

const serverInfo = {
  data: new SlashCommandBuilder().setName("server-info").setDescription("Show details about this server"),
  async execute(interaction) {
    const guild = interaction.guild;
    if (!guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`🏠 ${guild.name}`)
      .addFields(
        { name: "Members", value: String(guild.memberCount), inline: true },
        { name: "Channels", value: String(guild.channels.cache.size), inline: true },
        { name: "Created", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
        { name: "Server ID", value: guild.id }
      );
    const icon = guild.iconURL();
    if (icon) embed.setThumbnail(icon);
    return interaction.reply({ embeds: [embed] });
  },
};

const userInfo = {
  data: new SlashCommandBuilder()
    .setName("user-info")
    .setDescription("Show your details or another server member's details")
    .addUserOption((option) =>
      option.setName("user").setDescription("Member to look up (defaults to you)")
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    const user = interaction.options.getUser("user") ?? interaction.user;
    const member = await interaction.guild.members.fetch(user.id);
    const embed = new EmbedBuilder()
      .setColor(member.displayColor || 0x5865f2)
      .setTitle(`👤 ${user.tag}`)
      .addFields(
        { name: "Joined server", value: member.joinedAt ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>` : "Unknown", inline: true },
        { name: "Account created", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true },
        { name: "Roles", value: String(Math.max(0, member.roles.cache.size - 1)), inline: true },
        { name: "User ID", value: user.id }
      )
      .setThumbnail(user.displayAvatarURL());
    return interaction.reply({ embeds: [embed] });
  },
};

const youtubeShare = {
  data: new SlashCommandBuilder()
    .setName("youtube")
    .setDescription("Share a YouTube link with Discord's video preview")
    .addStringOption((option) =>
      option.setName("url").setDescription("HTTPS YouTube video or Shorts link").setRequired(true).setMaxLength(2048)
    ),
  async execute(interaction) {
    const rawUrl = interaction.options.getString("url", true);
    let url;
    try {
      url = new URL(rawUrl);
    } catch {
      return interaction.reply({ content: "Enter a valid HTTPS YouTube link.", ephemeral: true });
    }

    const allowedHosts = new Set([
      "youtube.com",
      "www.youtube.com",
      "m.youtube.com",
      "music.youtube.com",
      "youtu.be",
    ]);
    if (
      url.protocol !== "https:" ||
      url.username ||
      url.password ||
      url.port ||
      !allowedHosts.has(url.hostname.toLowerCase())
    ) {
      return interaction.reply({ content: "Only HTTPS links from youtube.com or youtu.be are allowed.", ephemeral: true });
    }
    const videoId = url.hostname.toLowerCase() === "youtu.be"
      ? url.pathname.slice(1).split("/")[0]
      : url.pathname === "/watch"
        ? url.searchParams.get("v")
        : url.pathname.match(/^\/(?:shorts|live|embed)\/([^/]+)/)?.[1];
    if (!videoId || !/^[A-Za-z0-9_-]{11}$/.test(videoId)) {
      return interaction.reply({ content: "Use a YouTube video, Shorts, or live-video URL.", ephemeral: true });
    }
    if (!interaction.channel || !("send" in interaction.channel)) {
      return interaction.reply({ content: "This command only works in a channel where I can post.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    await interaction.channel.send({ content: url.toString(), allowedMentions: { parse: [] } });
    return interaction.editReply("▶️ YouTube link shared. Discord will show a preview when that video allows embeds.");
  },
};

export const helpSelectCustomId = "multicoins-help-category";

const helpCategories = {
  economy: {
    label: "🪙 Economy",
    description: [
      "`/balance` — check your multicoins balance.",
      "`/daily` — claim your daily multicoins reward.",
      "`/slots bet` — play animated, weighted four-reel slots with WILD cards and a random 85–98% RTP target per spin.",
      "`/gamble game wager` — wager multicoins on coin flip, dice, blackjack, or roulette.",
    ].join("\n"),
  },
  games: {
    label: "🎮 Games",
    description: [
      "`/8ball question` — ask the magic 8-ball.",
      "`/coinflip` — flip a coin.",
      "`/rps choice` — play rock-paper-scissors.",
      "`/wyr` and `/truth-or-dare pick` — get a prompt.",
      "`/trivia answer` and `/emoji-quiz answer` — try a quiz.",
      "`/number-guess guess` and `/riddle` — solve a puzzle.",
      "`/sillystory noun adjective verb` — make a silly story.",
    ].join("\n"),
  },
  information: {
    label: "📊 Information",
    description: [
      "`/help` — open this interactive guide.",
      "`/level [user]` — view a member's level and XP.",
      "`/leaderboard` — see the server's top active members.",
      "`/server-info` — view server details.",
      "`/user-info user` — view member details.",
      "`/youtube url` — share a YouTube link.",
    ].join("\n"),
  },
  ai: {
    label: "🤖 AI",
    description: [
      "`/ai prompt` — ask Gemini privately.",
      "Messages in the linked AI chat channel get public replies with short-lived conversation context.",
      "Admins: `/ai-channel action` — create or link a chat channel, unlink it without deleting it, or enable/disable AI.",
    ].join("\n"),
  },
  moderation: {
    label: "🛡️ Moderation",
    description: [
      "`/warn user reason` — warn a member in-channel and by DM.",
      "`/kick user` and `/ban user` — remove or ban a member.",
      "`/hackban user_id` — ban by user ID, even if they have not joined.",
      "`/timeout user minutes` — temporarily restrict a member.",
      "`/purge amount` — delete recent channel messages.",
      "Admins: `/level-reset user` — reset a member's level.",
    ].join("\n"),
  },
  community: {
    label: "🧰 Community",
    description: [
      "`/embed title message` — post a formatted announcement.",
      "`/poll question option1 option2` — create a reaction poll.",
      "`/suggest idea` — post a community suggestion.",
    ].join("\n"),
  },
  owner: {
    label: "⚙️ Owner",
    description: "`/bot-presence status text` — update the bot's status and activity.",
  },
};

const helpSupportUrl = "https://discord.gg/rkER55w7m6";

function getBotInviteUrl() {
  const clientId = process.env.CLIENT_ID;
  if (!clientId) return null;
  const query = new URLSearchParams({
    client_id: clientId,
    scope: "bot applications.commands",
  });
  return `https://discord.com/oauth2/authorize?${query}`;
}

function createHelpLinks() {
  const inviteUrl = getBotInviteUrl();
  return [
    `[Support Server](${helpSupportUrl})`,
    inviteUrl ? `[Invite the bot](${inviteUrl})` : null,
  ].filter(Boolean).join("\n");
}

export function createHelpEmbed(category) {
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(category ? helpCategories[category]?.label ?? "Multicoins Help" : "Multicoins Help")
    .setDescription(category ? helpCategories[category]?.description ?? "Choose a category below." : "Use the select menu to explore multicoins")
    .addFields({ name: "Links", value: createHelpLinks() })
    .setFooter({ text: "Choose another category from the menu at any time." });
  return embed;
}

export function createHelpComponents() {
  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId(helpSelectCustomId)
    .setPlaceholder("Select a category")
    .addOptions(
      ...Object.entries(helpCategories).map(([value, category]) => ({
        label: category.label.slice(3),
        value,
        emoji: category.label.slice(0, 2),
      }))
    );
  const buttons = [
    new ButtonBuilder()
      .setLabel("Support")
      .setStyle(ButtonStyle.Link)
      .setURL(helpSupportUrl),
  ];
  const inviteUrl = getBotInviteUrl();
  if (inviteUrl) {
    buttons.push(
      new ButtonBuilder()
        .setLabel("Invite Bot")
        .setStyle(ButtonStyle.Link)
        .setURL(inviteUrl)
    );
  }
  return [
    new ActionRowBuilder().addComponents(selectMenu),
    new ActionRowBuilder().addComponents(buttons),
  ];
}

const help = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("Browse multicoins commands by category"),
  async execute(interaction) {
    return interaction.reply({
      embeds: [createHelpEmbed()],
      components: createHelpComponents(),
      ephemeral: false,
    });
  },
};

export async function handleHelpSelect(interaction) {
  const category = interaction.values[0];
  if (!Object.hasOwn(helpCategories, category)) {
    return interaction.reply({ content: "That help category is not available.", ephemeral: false });
  }
  return interaction.update({
    embeds: [createHelpEmbed(category)],
    components: createHelpComponents(),
  });
}

const level = {
  data: new SlashCommandBuilder()
    .setName("level")
    .setDescription("Check your level or another member's level")
    .addUserOption((option) =>
      option.setName("user").setDescription("Member to check (defaults to you)")
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    const user = interaction.options.getUser("user") ?? interaction.user;
    const progress = await getUserLevel(interaction.guild.id, user.id);
    return interaction.reply(
      `📈 **${user.username} — Level ${progress.level}**\n${progress.currentXp}/${progress.nextLevelXp} XP to level ${progress.level + 1} (${progress.totalXp} total XP).`
    );
  },
};

const leaderboard = {
  data: new SlashCommandBuilder().setName("leaderboard").setDescription("Show the top 10 active members by level"),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    await interaction.deferReply();
    const activeUserIds = new Set();
    let after;
    while (true) {
      const members = await interaction.guild.members.list({ limit: 1000, after });
      for (const [userId] of members) activeUserIds.add(userId);
      if (members.size < 1000) break;
      after = members.last().id;
    }

    const entries = await getLeaderboard(interaction.guild.id, activeUserIds, 10);
    if (entries.length === 0) {
      return interaction.editReply("📈 No levels yet. Send messages to start earning XP!");
    }

    const rows = entries.map((entry, index) =>
      `**${index + 1}.** <@${entry.userId}> — Level **${entry.level}** (${entry.totalXp} XP)`
    );
    return interaction.editReply({
      content: `🏆 **${interaction.guild.name} Level Leaderboard**\n${rows.join("\n")}`,
      allowedMentions: { parse: [] },
    });
  },
};

const levelReset = {
  data: new SlashCommandBuilder()
    .setName("level-reset")
    .setDescription("Reset a member's level and XP (administrator only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption((option) =>
      option.setName("user").setDescription("Member whose level to reset").setRequired(true)
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: "Only server administrators can reset levels.", ephemeral: true });
    }

    const user = interaction.options.getUser("user", true);
    await resetUserLevel(interaction.guild.id, user.id);
    return interaction.reply({ content: `✅ Reset <@${user.id}>'s level and XP.`, allowedMentions: { parse: [] } });
  },
};

const botPresence = {
  data: new SlashCommandBuilder()
    .setName("bot-presence")
    .setDescription("Set the bot's visible status and activity text (bot owner only)")
    .addStringOption((option) =>
      option
        .setName("status")
        .setDescription("The status to show")
        .setRequired(true)
        .addChoices(
          { name: "Online", value: "online" },
          { name: "Idle", value: "idle" },
          { name: "Do Not Disturb", value: "dnd" },
          { name: "Invisible", value: "invisible" }
        )
    )
    .addStringOption((option) =>
      option
        .setName("text")
        .setDescription("Text shown as the bot's Playing activity")
        .setRequired(true)
        .setMaxLength(128)
    ),
  async execute(interaction) {
    const ownerId = process.env.BOT_OWNER_ID;
    if (!ownerId) throw new Error("Set BOT_OWNER_ID in .env to enable the owner-only presence command.");
    if (interaction.user.id !== ownerId) {
      return interaction.reply({ content: "Only the configured bot owner can change my presence.", ephemeral: true });
    }

    const status = interaction.options.getString("status", true);
    const text = interaction.options.getString("text", true);
    interaction.client.user.setPresence({
      status,
      activities: [{ name: text, type: ActivityType.Playing }],
    });
    return interaction.reply({ content: `✅ Bot presence set to **${status}** · Playing **${text}**.`, ephemeral: true });
  },
};

export const commands = [
  kick, ban, warn, hackban, timeout, purge,
  eightBall, coinflip, rps, wouldYouRather, truthOrDare,
  trivia, numberGuess, riddle, sillyStory, emojiQuiz, ai, aiChannel,
  balance, daily, gamble, slots,
  level, leaderboard, levelReset,
  postEmbed, poll, suggest, serverInfo, userInfo, youtubeShare, help, botPresence,
];
