import "dotenv/config";
import { REST, Routes } from "discord.js";
import { commands } from "./commands.js";

const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;

if (!DISCORD_TOKEN || !CLIENT_ID) {
  throw new Error("Set DISCORD_TOKEN and CLIENT_ID in your .env file before deploying commands.");
}

const rest = new REST({ version: "10" }).setToken(DISCORD_TOKEN);
if (GUILD_ID) {
  console.warn("GUILD_ID is ignored: commands are always registered globally for every server with the bot.");
}

await rest.put(Routes.applicationCommands(CLIENT_ID), {
  body: commands.map((command) => command.data.toJSON()),
});
console.log(`Registered ${commands.length} slash commands globally for every server with the bot.`);
