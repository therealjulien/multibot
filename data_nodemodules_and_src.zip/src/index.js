import "dotenv/config";
import { Client, Events, GatewayIntentBits } from "discord.js";
import { commands, handleHelpSelect, helpSelectCustomId } from "./commands.js";
import { getAiSettings, handleAiChannelMessage, truncateAiResponse } from "./ai.js";
import { awardMessageXp, removeMemberLevel } from "./levels.js";

const token = process.env.DISCORD_TOKEN;

if (!token) {
  throw new Error("Set DISCORD_TOKEN in your .env file before starting the bot.");
}

const commandMap = new Map(commands.map((command) => [command.data.name, command]));
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
  ],
});

client.once(Events.ClientReady, (readyClient) => {
  console.log(`Ready as ${readyClient.user.tag}`);
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isStringSelectMenu() && interaction.customId === helpSelectCustomId) {
    try {
      await handleHelpSelect(interaction);
    } catch (error) {
      console.error("Help category selection failed:", error);
      const response = { content: "I couldn't update the help menu. Please try again.", ephemeral: false };
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp(response);
      } else {
        await interaction.reply(response);
      }
    }
    return;
  }

  if (!interaction.isChatInputCommand()) return;

  const command = commandMap.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(`Command /${interaction.commandName} failed:`, error);
    const message = "That command failed. Check the bot's permissions and try again.";
    if (interaction.deferred) {
      await interaction.editReply({ content: message });
    } else if (interaction.replied) {
      await interaction.followUp({ content: message, ephemeral: true });
    } else {
      await interaction.reply({ content: message, ephemeral: true });
    }
  }
});

client.on(Events.MessageCreate, async (message) => {
  if (!message.guild || message.author.bot) return;

  try {
    const result = await handleAiChannelMessage(message);
    if (result.status === "responded" || result.error) {
      const settings = await getAiSettings(message.guild.id);
      if (!settings.enabled || settings.channelId !== message.channelId) return;
      const content = result.error
        ? result.error
        : truncateAiResponse(result.text);
      await message.reply({
        content,
        allowedMentions: { parse: [] },
      });
    }
  } catch (error) {
    console.error(`AI channel response failed in ${message.guild.id}/${message.channelId}:`, error);
    try {
      const settings = await getAiSettings(message.guild.id);
      if (settings.enabled && settings.channelId === message.channelId) {
        await message.reply({
          content: "Gemini couldn't respond right now. Please try again later.",
          allowedMentions: { parse: [] },
        });
      }
    } catch (replyError) {
      console.error("Could not report the AI channel failure:", replyError);
    }
  }
});

client.on(Events.MessageCreate, async (message) => {
  if (!message.guild || message.author.bot) return;

  let progress;
  try {
    progress = await awardMessageXp(message.guild.id, message.author.id);
  } catch (error) {
    console.error("Could not award message XP:", error);
    return;
  }

  if (progress?.leveledUp) {
    try {
      await message.channel.send({
        content: `🎉 <@${message.author.id}> reached **level ${progress.level}**!`,
        allowedMentions: { users: [message.author.id] },
      });
    } catch (error) {
      console.error("Could not announce a level-up:", error);
    }
  }
});

client.on(Events.GuildMemberRemove, async (member) => {
  try {
    await removeMemberLevel(member.guild.id, member.id);
  } catch (error) {
    console.error(`Could not remove level data for departed member ${member.id}:`, error);
  }
});

client.login(token);
