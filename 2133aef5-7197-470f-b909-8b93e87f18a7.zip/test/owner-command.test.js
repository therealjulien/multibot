import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { botMaintenance } from "../src/commands/owner.js";
import { createBotPresenceCommand } from "../src/commands/legacy.js";
import { requestServerRestart } from "../src/server-control.js";

test("bot maintenance exposes only the requested fixed actions", async () => {
  const command = botMaintenance.data.toJSON();
  const packageJson = JSON.parse(await readFile(new URL("../package.json", import.meta.url), "utf8"));
  assert.deepEqual(
    command.options[0].choices.map((choice) => choice.value),
    ["deploy", "npm-restart", "server-restart"]
  );
  assert.equal(packageJson.scripts.restart, "node src/restart-server.js");
});

test("bot maintenance command denies users other than the configured owner", async () => {
  const previousOwnerId = process.env.BOT_OWNER_ID;
  process.env.BOT_OWNER_ID = "configured-owner";
  let response;

  try {
    await botMaintenance.execute({
      user: { id: "another-user" },
      reply: async (options) => { response = options; },
    });
  } finally {
    if (previousOwnerId === undefined) delete process.env.BOT_OWNER_ID;
    else process.env.BOT_OWNER_ID = previousOwnerId;
  }

  assert.match(response.content, /Only the configured bot owner/);
  assert.equal(response.ephemeral, true);
});

test("presence replies publicly to the owner but denies other users privately", async (t) => {
  const previousOwnerId = process.env.BOT_OWNER_ID;
  t.after(() => {
    if (previousOwnerId === undefined) delete process.env.BOT_OWNER_ID;
    else process.env.BOT_OWNER_ID = previousOwnerId;
  });
  process.env.BOT_OWNER_ID = "owner";
  let update;
  let response;
  const command = createBotPresenceCommand(async (client, settings) => {
    update = { client, settings };
    return "Playing";
  });
  const interaction = {
    user: { id: "owner" },
    client: {},
    options: {
      getString: (name) => name === "status" ? "online" : " Playing ",
      getBoolean: () => false,
    },
    reply: async (payload) => { response = payload; },
  };
  await command.execute(interaction);
  assert.equal(response.ephemeral, undefined);
  assert.match(response.content, /Bot presence set to/);
  assert.deepEqual(update.settings, { status: "online", text: "Playing", serverCount: false });
  assert.match(response.content, /Playing/);
  interaction.options.getBoolean = () => true;
  await command.execute(interaction);
  assert.match(response.content, /Watching/);
  update = undefined;
  interaction.user.id = "other";
  await command.execute(interaction);
  assert.equal(response.ephemeral, true);
  assert.match(response.content, /Only the configured bot owner/);
  assert.equal(update, undefined);
});

test("restart announces the request before starting the server restart", async (t) => {
  for (const [name, value] of Object.entries({
    BOT_OWNER_ID: "owner",
    PANEL_API_KEY: "test-key",
    PANEL_API_URL: "https://panel.example.test",
    PANEL_SERVER_ID: "test-server",
  })) {
    const previous = process.env[name];
    t.after(() => {
      if (previous === undefined) delete process.env[name];
      else process.env[name] = previous;
    });
    process.env[name] = value;
  }
  const events = [];
  t.mock.method(globalThis, "fetch", async () => {
    events.push("restart");
    return { ok: true, status: 204 };
  });
  await botMaintenance.execute({
    user: { id: "owner" },
    options: { getString: () => "server-restart" },
    deferReply: async (options) => { assert.equal(options?.ephemeral, undefined); events.push("deferred"); },
    editReply: async ({ content }) => { events.push(content); },
  });
  assert.deepEqual(events, [
    "deferred",
    "Requesting the server restart...",
    "restart",
    "✅ The hosting panel accepted the server restart request.",
  ]);
});

test("maintenance failures are public without exposing error details", async (t) => {
  for (const [name, value] of Object.entries({
    BOT_OWNER_ID: "owner",
    PANEL_API_KEY: "test-key",
    PANEL_API_URL: "https://panel.example.test",
    PANEL_SERVER_ID: "test-server",
  })) {
    const previous = process.env[name];
    t.after(() => {
      if (previous === undefined) delete process.env[name];
      else process.env[name] = previous;
    });
    process.env[name] = value;
  }
  t.mock.method(globalThis, "fetch", async () => { throw new Error("sensitive diagnostic"); });
  const log = t.mock.method(console, "error", () => {});
  const responses = [];
  await botMaintenance.execute({
    user: { id: "owner" },
    options: { getString: () => "server-restart" },
    deferReply: async (options) => assert.equal(options?.ephemeral, undefined),
    editReply: async (payload) => responses.push(payload.content),
  });
  assert.match(responses.at(-1), /failed.*logs/);
  assert.doesNotMatch(responses.at(-1), /sensitive diagnostic/);
  assert.equal(log.mock.callCount(), 1);
});

test("server restart uses the configured panel power endpoint", async () => {
  let request;
  await requestServerRestart({
    env: {
      PANEL_API_KEY: "test-key",
    },
    fetchImpl: async (url, options) => {
      request = { url: String(url), options };
      return { ok: true, status: 204 };
    },
  });

  assert.equal(request.url, "https://panel.mc-node.net/api/client/servers/9d912719/power");
  assert.equal(request.options.method, "POST");
  assert.equal(request.options.headers.Authorization, "Bearer test-key");
  assert.equal(request.options.redirect, "manual");
  assert.deepEqual(JSON.parse(request.options.body), { signal: "restart" });
});

test("server restart fails clearly when panel credentials are missing", async () => {
  await assert.rejects(
    requestServerRestart({ env: {}, fetchImpl: async () => assert.fail("fetch must not run") }),
    /Set PANEL_API_KEY/
  );
});

test("server restart rejects insecure panel URLs and API errors", async () => {
  const env = {
    PANEL_API_URL: "http://panel.example.test",
    PANEL_API_KEY: "test-key",
  };
  await assert.rejects(requestServerRestart({ env }), /must be a clean HTTPS URL/);

  await assert.rejects(
    requestServerRestart({
      env: { ...env, PANEL_API_URL: "https://panel.example.test" },
      fetchImpl: async () => ({ ok: false, status: 403 }),
    }),
    /Panel API returned HTTP 403/
  );
});
