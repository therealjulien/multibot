import assert from "node:assert/strict";
import test from "node:test";
import {
  getSlotBaseRtpPercent,
  getSlotOutcome,
  slotMachines,
  slotReelCount,
} from "../src/economy.js";
import { commands } from "../src/commands.js";

test("classic slots preserve their existing WILD matching paytable", () => {
  assert.equal(getSlotOutcome(["🍒", "🍒", "🍒", "🍋"]).multiplier, 7);
  assert.equal(getSlotOutcome(["🍒", "🍒", "🍒", "🃏"]).multiplier, 14);
  assert.equal(getSlotOutcome(["💎", "💎", "💎", "💎"]).multiplier, 640);
});

test("themed slot machines trigger their bonus rounds only on three or more bonus icons", () => {
  const treasureBonus = getSlotOutcome(["🧰", "🧰", "🧰", "🪙"], "treasure");
  assert.equal(treasureBonus.bonus, true);
  assert.equal(treasureBonus.matchCount, 3);
  assert.equal(treasureBonus.multiplier, 5);

  const fourGalaxyBonuses = getSlotOutcome(["🌀", "🌀", "🌀", "🌀"], "galaxy");
  assert.equal(fourGalaxyBonuses.bonus, true);
  assert.equal(fourGalaxyBonuses.multiplier, 12);

  const twoCandyBonuses = getSlotOutcome(["🌈", "🌈", "🍬", "🍫"], "candy");
  assert.equal(twoCandyBonuses.bonus, undefined);
  assert.equal(twoCandyBonuses.multiplier, 0);
});

test("each slot machine has a calculable RTP and is available on /slots", () => {
  assert.deepEqual(slotMachines.map(({ id }) => id), ["classic", "treasure", "galaxy", "candy"]);
  for (const { id } of slotMachines) {
    assert.ok(Number.isFinite(getSlotBaseRtpPercent(id)));
    assert.ok(getSlotBaseRtpPercent(id) > 0);
  }

  const slotsCommand = commands.find((command) => command.data.name === "slots").data.toJSON();
  const machineChoices = slotsCommand.options.find((option) => option.name === "machine").choices;
  assert.deepEqual(machineChoices.map(({ value }) => value), slotMachines.map(({ id }) => id));
  assert.equal(slotReelCount, 4);
});

test("slot outcomes reject reels from a different machine", () => {
  assert.throws(() => getSlotOutcome(["🧰", "🪙", "🪙", "🪙"], "classic"), RangeError);
  assert.throws(() => getSlotOutcome(["🍬", "🍬", "🍬"], "candy"), RangeError);
});