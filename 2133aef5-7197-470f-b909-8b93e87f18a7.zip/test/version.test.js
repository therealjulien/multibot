import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { formatBotVersion, incrementRebootCounter } from "../src/version.js";

async function createCounterPath(t) {
  const directory = await mkdtemp(join(tmpdir(), "multibot-version-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  return join(directory, "version.json");
}

test("the reboot counter starts at 0001 and increments on each process start", async (t) => {
  const counterPath = await createCounterPath(t);

  assert.equal(await incrementRebootCounter(counterPath), 1);
  assert.equal(formatBotVersion(1), "0.2611a");
  assert.equal(await incrementRebootCounter(counterPath), 2);
  assert.equal(formatBotVersion(2), "0.2611a");
  assert.deepEqual(JSON.parse(await readFile(counterPath, "utf8")), { rebootCount: 2 });
});

test("the reboot counter stops at 9999", async (t) => {
  const counterPath = await createCounterPath(t);
  await writeFile(counterPath, JSON.stringify({ rebootCount: 9998 }), "utf8");

  assert.equal(await incrementRebootCounter(counterPath), 9999);
  assert.equal(await incrementRebootCounter(counterPath), 9999);
});

test("an invalid saved counter is reported instead of silently reset", async (t) => {
  const counterPath = await createCounterPath(t);
  await writeFile(counterPath, JSON.stringify({ rebootCount: -1 }), "utf8");

  await assert.rejects(
    incrementRebootCounter(counterPath),
    /saved reboot counter must contain an integer from 0 to 9999/
  );
});
