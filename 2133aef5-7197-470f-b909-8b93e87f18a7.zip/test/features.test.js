import assert from "node:assert/strict";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { EventEmitter } from "node:events";
import test from "node:test";
import { ActivityType, AuditLogEvent, ChannelType, Collection, EmbedBuilder, Events, PermissionFlagsBits, PermissionsBitField, SlashCommandBuilder } from "discord.js";
import { commands } from "../src/commands.js";
import { getModerationReason } from "../src/features/automod.js";
import { isSafeReactionRole } from "../src/features/interactive.js";
import { createLevelRewardStore, applyLevelRoleReward } from "../src/features/level-rewards.js";
import { createModerationStore } from "../src/features/moderation.js";
import { createCustomCommandStore } from "../src/features/social.js";
import { createFeatureStore } from "../src/features/store.js";
import { registerFeatureEvents, renderCustomCommandResponse } from "../src/features/runtime.js";
import { createReactionRoleStore, emojiKey, handleReactionRoleEvent } from "../src/features/reaction-roles.js";
import { builderTemplates, handleServerBuilder } from "../src/features/server-builder.js";
import { configureHelpCommands, createHelpComponents, createHelpEmbed, handleHelpCancel, handleHelpMention, handleHelpSelect } from "../src/commands/legacy.js";
import { createPresenceManager, registerPresenceEvents } from "../src/features/presence.js";
import { startCommandTyping } from "../src/features/typing.js";
import { createFullAuditEmbed, registerAuditEvents } from "../src/features/audit-events.js";
import { createLogsCommand, createReactionRoleCommand, createStickyCommand } from "../src/commands/server-tools.js";
import { createLogsMenuHandler, logsSetupMenu } from "../src/features/logs-menu.js";

async function createStore(t) {
  const directory = await mkdtemp(join(tmpdir(), "multibot-features-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const filePath = join(directory, "features.json");
  return { filePath, store: createFeatureStore(filePath) };
}

test("feature settings serialize concurrent updates and persist per guild", async (t) => {
  const { filePath, store } = await createStore(t);
  await Promise.all(Array.from({ length: 20 }, () =>
    store.updateGuild("guild-a", (guild) => {
      guild.counter = (guild.counter ?? 0) + 1;
    })
  ));
  await store.updateGuild("guild-b", (guild) => {
    guild.enabled = true;
  });

  const reopened = createFeatureStore(filePath);
  assert.equal((await reopened.getGuild("guild-a")).counter, 20);
  assert.deepEqual(await reopened.getGuild("guild-b"), { enabled: true });
  assert.deepEqual((await reopened.getGuildIds()).sort(), ["guild-a", "guild-b"]);
});

test("invalid feature data is reported instead of reset", async (t) => {
  const { filePath, store } = await createStore(t);
  await writeFile(filePath, "{invalid json", "utf8");

  await assert.rejects(store.getGuild("guild-a"), SyntaxError);
});

test("moderation cases are numbered per guild and returned newest first", async (t) => {
  const { store } = await createStore(t);
  const moderation = createModerationStore(store);

  const first = await moderation.createCase("guild-a", {
    action: "warn",
    targetId: "user-a",
    moderatorId: "mod-a",
    reason: "First warning",
  });
  const second = await moderation.createCase("guild-a", {
    action: "timeout",
    targetId: "user-a",
    moderatorId: "mod-b",
    reason: "Repeated issue",
    durationMs: 60_000,
  });
  const otherGuild = await moderation.createCase("guild-b", {
    action: "ban",
    targetId: "user-b",
    moderatorId: "mod-c",
    reason: "Separate server",
  });

  assert.equal(first.caseNumber, 1);
  assert.equal(second.caseNumber, 2);
  assert.equal(second.durationMs, 60_000);
  assert.equal(otherGuild.caseNumber, 1);
  assert.deepEqual(
    (await moderation.getCases("guild-a", "user-a")).map((entry) => entry.caseNumber),
    [2, 1]
  );
});

test("full audit-log mode persists separately per server and defaults to standard", async (t) => {
  const { filePath, store } = await createStore(t);
  const moderation = createModerationStore(store);
  assert.deepEqual(await moderation.getAuditLogSettings("guild"), { channelId: null, mode: "standard", enabled: false });
  await moderation.setAuditLogChannel("guild", "private-channel");
  await moderation.setAuditLogMode("guild", "full");
  const reopened = createModerationStore(createFeatureStore(filePath));
  assert.deepEqual(await reopened.getAuditLogSettings("guild"), { channelId: "private-channel", mode: "full", enabled: true });
  assert.equal((await reopened.getAuditLogSettings("other")).mode, "standard");
  assert.throws(() => moderation.setAuditLogMode("guild", "invalid"), /standard or full/);
});

test("level rewards replace older milestone roles with the highest reached reward", async (t) => {
  const { store } = await createStore(t);
  const rewardStore = createLevelRewardStore(store);
  await rewardStore.set("guild-a", 5, "role-five");
  await rewardStore.set("guild-a", 10, "role-ten");

  const oldRole = { id: "role-five", editable: true };
  const newRole = { id: "role-ten", editable: true };
  const roles = new Collection([[oldRole.id, oldRole]]);
  const member = {
    guild: {
      id: "guild-a",
      roles: { fetch: async (roleId) => roleId === newRole.id ? newRole : oldRole },
    },
    roles: {
      cache: roles,
      add: async (role) => roles.set(role.id, role),
      remove: async (removedRoles) => {
        for (const roleId of removedRoles.keys()) roles.delete(roleId);
      },
    },
  };

  assert.equal(
    await applyLevelRoleReward(member, 12, rewardStore.list),
    newRole
  );
  assert.deepEqual([...roles.keys()], ["role-ten"]);
});

test("custom commands can be edited and safely interpolate arguments", async (t) => {
  const { store } = await createStore(t);
  const customCommands = createCustomCommandStore(store);
  assert.deepEqual(await customCommands.add("guild-a", "hello", "Hi {user}"), { added: true });
  assert.equal(await customCommands.update("guild-a", "hello", "Hi {user} in {channel}: {args}"), true);
  assert.equal(await customCommands.get("guild-a", "hello"), "Hi {user} in {channel}: {args}");
  assert.deepEqual(await customCommands.list("guild-a"), ["hello"]);
  assert.equal(
    renderCustomCommandResponse("Hi {user} in {channel}: {args}", {
      userId: "user-a",
      channelName: "lobby",
      args: "literal {server}",
    }),
    "Hi <@user-a> in lobby: literal {server}"
  );
});

test("automod matches invite links and whole blocked words without substring false positives", () => {
  const config = {
    enabled: true,
    blockInvites: true,
    blockedWords: ["bad word", "class"],
  };
  assert.equal(getModerationReason("Join us at discord.gg/example", config), "invite");
  assert.equal(getModerationReason("Please avoid a BAD WORD here", config), "blocked-word");
  assert.equal(getModerationReason("This is a classic example", config), null);
  assert.equal(getModerationReason("discord.gg/example", { ...config, enabled: false }), null);
});

test("reaction-role panels reject roles with administrative permissions", () => {
  const permissionsFor = (...values) => ({ has: (permission) => values.includes(permission) });
  assert.equal(isSafeReactionRole({ permissions: permissionsFor() }), true);
  assert.equal(isSafeReactionRole({ permissions: permissionsFor(8n) }), false);
});

test("reaction roles persist multiple mappings, reject conflicts, and remove individual mappings", async (t) => {
  const { filePath, store } = await createStore(t);
  const roles = createReactionRoleStore(store.updateGuild);
  assert.equal(emojiKey("<:game:123456789012345678>"), "123456789012345678");
  assert.equal(emojiKey("not an emoji"), null);
  assert.equal(await roles.add("guild", "message", "channel", "🎮", "game"), null);
  assert.equal(await roles.add("guild", "message", "channel", "💻", "tech"), null);
  assert.equal(await roles.add("guild", "message", "channel", "🎮", "other"), "emoji");
  assert.equal(await roles.add("guild", "message", "channel", "😀", "tech"), "role");
  await roles.remove("guild", "message", "🎮");
  const reopened = createFeatureStore(filePath);
  assert.deepEqual((await reopened.getGuild("guild")).reactionAssignments.message.roles, { "💻": "tech" });
});

test("reaction-role setup requires Manage Roles and rejects a role above the configurator", async () => {
  const command = commands.find((entry) => entry.data.name === "reaction-role");
  let response;
  const interaction = {
    guild: {
      id: "guild", ownerId: "owner",
      members: { fetch: async () => ({ roles: { highest: { comparePositionTo: () => -1 } } }) },
    },
    user: { id: "admin" },
    memberPermissions: { has: () => false },
    channel: { messages: {} },
    options: {
      getSubcommand: () => "add",
      getRole: () => ({ editable: true, permissions: { has: () => false } }),
      getChannel: () => null,
      getString: (name) => name === "message_id" ? "123456789012345678" : "🎮",
    },
    reply: async (payload) => { response = payload.content; },
  };
  await command.execute(interaction);
  assert.match(response, /Manage Roles/);
  interaction.memberPermissions.has = () => true;
  await command.execute(interaction);
  assert.match(response, /below your highest role/);
});

test("reaction events assign and remove configured roles in order and ignore unsafe roles", async () => {
  const calls = [];
  const role = { id: "role", editable: true, permissions: { has: () => false } };
  const guild = {
    id: "guild",
    roles: { fetch: async () => role },
    members: { fetch: async () => ({ roles: {
      add: async () => { await new Promise((resolve) => setTimeout(resolve, 10)); calls.push("add"); },
      remove: async () => calls.push("remove"),
    } }) },
  };
  let fetched = false;
  const reaction = {
    partial: true,
    fetch: async () => { fetched = true; },
    message: { id: "message", channelId: "channel", guild },
    emoji: { id: "123456789012345678", name: "game" },
  };
  const user = { id: "user", bot: false };
  const getData = async () => ({ reactionAssignments: { message: { channelId: "channel", roles: { "123456789012345678": "role" } } } });
  await Promise.all([handleReactionRoleEvent(reaction, user, true, getData), handleReactionRoleEvent(reaction, user, false, getData)]);
  assert.equal(fetched, true);
  assert.deepEqual(calls, ["add", "remove"]);
  role.editable = false;
  const oldError = console.error;
  try {
    console.error = () => {};
    await handleReactionRoleEvent(reaction, user, true, getData);
  } finally {
    console.error = oldError;
  }
  assert.deepEqual(calls, ["add", "remove"]);
});

test("server builder previews, creates selected templates, and reuses existing channels", async () => {
  const cache = new Collection([
    ["1", { id: "1", name: "My Server - Gaming Server", type: ChannelType.GuildCategory }],
    ["2", { id: "2", name: "game-chat", parentId: "1", type: ChannelType.GuildText }],
    ["3", { id: "3", name: "Gaming", parentId: "1", type: ChannelType.GuildVoice }],
  ]);
  const guild = {
    name: "My Server",
    members: { me: { permissions: { has: (permission) => permission === PermissionFlagsBits.ManageChannels } } },
    channels: {
      cache,
      fetch: async () => cache,
      create: async (options) => {
        const channel = { ...options, id: String(cache.size + 1), parentId: options.parent ?? null };
        cache.set(channel.id, channel);
        return channel;
      },
    },
  };
  let preview;
  const common = {
    guild, guildId: "guild", user: { id: "123456789012345678", tag: "admin" },
    message: { id: "menu" },
    memberPermissions: { has: () => true },
    isStringSelectMenu: () => false,
    isButton: () => true,
  };
  const command = commands.find((entry) => entry.data.name === "server-builder");
  await command.execute({ ...common, reply: async (payload) => { preview = payload; } });
  let buttons = preview.components[0].toJSON().components;
  assert.equal(buttons.length, 4);
  assert.equal(preview.components[1].toJSON().components.find((button) => button.label === "Create selected").disabled, true);
  await handleServerBuilder({
    ...common, customId: buttons.find((button) => button.label === "Gaming").custom_id,
    update: async (payload) => { preview = payload; },
  });
  buttons = preview.components[0].toJSON().components;
  await handleServerBuilder({
    ...common, customId: buttons.find((button) => button.label === "Tech").custom_id,
    update: async (payload) => { preview = payload; },
  });
  assert.match(preview.content, /My Server - Gaming Server/);
  assert.match(preview.content, /My Server - Tech Server/);
  assert.match(preview.content, /#game-chat/);
  assert.match(preview.content, /Voice: General/);
  const confirmId = preview.components[1].toJSON().components.find((button) => button.label === "Create selected").custom_id;
  let result;
  const confirm = () => ({
    ...common, customId: confirmId, isStringSelectMenu: () => false, isButton: () => true,
    deferUpdate: async function () { this.deferred = true; },
    editReply: async (payload) => { result = payload; },
  });
  await handleServerBuilder(confirm());
  assert.equal(cache.size, 25);
  assert.equal([...cache.values()].filter((channel) => channel.type === ChannelType.GuildCategory).length, 2);
  for (const category of [...cache.values()].filter((channel) => channel.type === ChannelType.GuildCategory)) {
    const children = [...cache.values()].filter((channel) => channel.parentId === category.id);
    assert.equal(children.filter((channel) => channel.type === ChannelType.GuildText).length, 10);
    assert.equal(children.filter((channel) => channel.type === ChannelType.GuildVoice && channel.name === "General").length, 1);
  }
  assert.equal(cache.get("3").name, "Gaming");
  await handleServerBuilder(confirm());
  assert.equal(cache.size, 25);
  assert.match(result.content, /already exist/);
  let denied;
  await handleServerBuilder({ ...confirm(), user: { id: "other" }, reply: async (payload) => { denied = payload.content; } });
  assert.match(denied, /Only the setup owner/);
});

test("server builder select all and clear buttons preview every complete template", async () => {
  let preview;
  const cache = new Collection();
  const guild = {
    name: "A".repeat(100),
    members: { me: { permissions: { has: () => true } } },
    channels: {
      cache,
      fetch: async () => cache,
      create: async (options) => {
        const channel = { ...options, id: String(cache.size + 1), parentId: options.parent ?? null };
        cache.set(channel.id, channel);
        return channel;
      },
    },
  };
  const common = {
    guild, guildId: "guild", message: { id: "menu" },
    user: { id: "123456789012345678", tag: "admin" }, memberPermissions: { has: () => true },
    isStringSelectMenu: () => false, isButton: () => true,
    update: async (payload) => { preview = payload; },
  };
  await handleServerBuilder({ ...common, customId: "multibot:builder:all:123456789012345678:-" });
  for (const template of Object.values(builderTemplates)) {
    assert.equal(template.channels.length, 10);
    assert.equal(new Set(template.channels).size, 10);
    assert.match(preview.content, new RegExp(template.label));
    for (const name of template.channels) assert.ok(preview.content.includes(`#${name}`));
  }
  const actions = preview.components[1].toJSON().components;
  assert.equal(actions.find((button) => button.label === "Create selected").disabled, false);
  assert.ok(preview.content.length <= 2000);
  let result;
  await handleServerBuilder({
    ...common, customId: actions.find((button) => button.label === "Create selected").custom_id,
    deferUpdate: async function () { this.deferred = true; },
    editReply: async (payload) => { result = payload; },
  });
  assert.equal(cache.size, 48);
  const categories = [...cache.values()].filter((channel) => channel.type === ChannelType.GuildCategory);
  assert.equal(categories.length, 4);
  for (const category of categories) {
    assert.ok(category.name.length <= 100);
    const children = [...cache.values()].filter((channel) => channel.parentId === category.id);
    assert.equal(children.filter((channel) => channel.type === ChannelType.GuildText).length, 10);
    assert.deepEqual(children.filter((channel) => channel.type === ChannelType.GuildVoice).map((channel) => channel.name), ["General"]);
  }
  assert.ok(result.content.length <= 2000);
  await handleServerBuilder({ ...common, customId: actions.find((button) => button.label === "Clear").custom_id });
  assert.match(preview.content, /Each adds 10 text channels/);
  assert.equal(preview.components[1].toJSON().components.find((button) => button.label === "Create selected").disabled, true);
});

test("existing dropdown menus remain usable after the builder update", async () => {
  let preview;
  await handleServerBuilder({
    customId: "multibot:builder:select:123456789012345678",
    guildId: "guild", guild: { name: "Example" }, message: { id: "old-menu" },
    user: { id: "123456789012345678" }, memberPermissions: { has: () => true },
    values: ["community"], isStringSelectMenu: () => true,
    update: async (payload) => { preview = payload; },
  });
  assert.match(preview.content, /Example - Community Server/);
  assert.equal(preview.components[0].toJSON().components.length, 4);
});

test("server builder does not create from stale selections during a menu update", async () => {
  let release;
  let denied;
  const common = {
    guildId: "guild", guild: { name: "Example" }, message: { id: "menu" },
    user: { id: "123456789012345678" }, memberPermissions: { has: () => true },
    isStringSelectMenu: () => false, isButton: () => true,
    reply: async (payload) => { denied = payload.content; },
  };
  const updating = handleServerBuilder({
    ...common, customId: "multibot:builder:toggle:123456789012345678:gaming:tech",
    update: () => new Promise((resolve) => { release = resolve; }),
  });
  await handleServerBuilder({
    ...common, customId: "multibot:builder:create:123456789012345678:gaming",
  });
  assert.match(denied, /wait for the selection to update/);
  release();
  await updating;
});

test("server builder reports partial creation when a channel fails", async () => {
  const cache = new Collection();
  let result;
  const oldError = console.error;
  const interaction = {
    customId: "multibot:builder:create:123456789012345678:gaming",
    guildId: "guild", user: { id: "123456789012345678", tag: "admin" },
    memberPermissions: { has: () => true },
    guild: {
      name: "Example",
      members: { me: { permissions: { has: () => true } } },
      channels: {
        cache, fetch: async () => cache,
        create: async (options) => {
          if (options.type !== ChannelType.GuildCategory) throw new Error("Missing channel permission");
          const category = { id: "category", ...options };
          cache.set(category.id, category);
          return category;
        },
      },
    },
    isStringSelectMenu: () => false,
    isButton: () => true,
    deferUpdate: async function () { this.deferred = true; },
    editReply: async (payload) => { result = payload; },
  };
  try {
    console.error = () => {};
    await handleServerBuilder(interaction);
  } finally {
    console.error = oldError;
  }
  assert.match(result.content, /stopped/);
  assert.match(result.content, /Category: Example - Gaming Server/);
});

test("all slash commands serialize with unique names", () => {
  const definitions = commands.map((command) => command.data.toJSON());
  const names = definitions.map((command) => command.name);
  assert.equal(new Set(names).size, names.length);
  assert.ok(names.includes("automod"));
  assert.ok(names.includes("tickets"));
  assert.ok(names.includes("birthday"));
  assert.ok(names.includes("embed-edit"));
  assert.ok(names.includes("modlog"));
  assert.ok(names.includes("logs"));
  assert.ok(names.includes("level-reward"));
  const welcome = definitions.find((command) => command.name === "welcome");
  assert.ok(welcome.options.some((option) => option.name === "edit"));
});

test("help categories include every registered slash command", () => {
  const categories = createHelpComponents("owner")[0].toJSON().components[0].options.map((option) => option.value);
  const description = categories.map((category) => createHelpEmbed(category).toJSON().description).join("\n");
  const documented = new Set([...description.matchAll(/\/([a-z0-9-]+)/g)].map((match) => match[1]));
  assert.deepEqual(commands.map((command) => command.data.name).filter((name) => !documented.has(name)), []);
  assert.equal((description.match(/`\/logs`/g) ?? []).length, 1);
  assert.match(createHelpEmbed("moderation").toJSON().description, /`mode`/);
});

test("new commands automatically appear in an Other help category", () => {
  const extra = { data: new SlashCommandBuilder().setName("new-command").setDescription("An added command") };
  try {
    configureHelpCommands([...commands, extra]);
    assert.ok(createHelpComponents("owner")[0].toJSON().components[0].options.some((option) => option.value === "other"));
    assert.match(createHelpEmbed("other").toJSON().description, /`\/new-command`/);
  } finally {
    configureHelpCommands(commands);
  }
});

test("only explicit human mentions of the bot open the interactive help menu", async () => {
  let replies = 0;
  let payload;
  const message = {
    guild: { id: "guild" }, author: { id: "owner", bot: false }, mentions: { users: new Set(["bot"]) },
    content: "<@bot> help",
    reply: async (value) => { replies++; payload = value; },
  };
  assert.equal(await handleHelpMention(message, "bot"), true);
  assert.equal(replies, 1);
  assert.equal(payload.components.length, 2);
  assert.equal(payload.components[1].toJSON().components.find((button) => button.label === "Cancel").custom_id, "multibot:help:cancel:owner");
  assert.deepEqual(payload.allowedMentions, { parse: [], repliedUser: false });
  assert.equal(await handleHelpMention({ ...message, content: "Thanks for the answer!", reference: { messageId: "previous" } }, "bot"), false);
  assert.equal(await handleHelpMention({ ...message, content: "<@other> help", mentions: { users: new Set(["bot", "other"]) } }, "bot"), false);
  assert.equal(await handleHelpMention({ ...message, content: "@everyone" }, "bot"), false);
  assert.equal(await handleHelpMention({ ...message, mentions: { users: new Set() } }, "bot"), false);
  assert.equal(await handleHelpMention({ ...message, author: { bot: true } }, "bot"), false);
  assert.equal(await handleHelpMention({ ...message, content: "<@!bot> help", reference: { messageId: "previous" } }, "bot"), true);
  assert.equal(replies, 2);
});

test("help cancel belongs to the opener and survives category changes", async () => {
  const command = commands.find((entry) => entry.data.name === "help");
  let initial;
  await command.execute({ user: { id: "owner" }, reply: async (payload) => { initial = payload; } });
  const cancel = initial.components[1].toJSON().components.find((button) => button.label === "Cancel");
  assert.equal(cancel.custom_id, "multibot:help:cancel:owner");
  let selected;
  await handleHelpSelect({
    values: ["games"], user: { id: "other" },
    message: { components: [{ components: [{ customId: cancel.custom_id }] }] },
    update: async (payload) => { selected = payload; },
  });
  assert.equal(selected.components[1].toJSON().components.find((button) => button.label === "Cancel").custom_id, cancel.custom_id);

  let deleted = 0;
  let deferred = 0;
  let denied;
  const interaction = {
    customId: cancel.custom_id, user: { id: "other" },
    message: { delete: async () => { deleted++; } },
    deferUpdate: async () => { deferred++; },
    reply: async (payload) => { denied = payload; },
  };
  await handleHelpCancel(interaction);
  assert.equal(denied.ephemeral, true);
  assert.equal(deleted, 0);
  interaction.user.id = "owner";
  await handleHelpCancel(interaction);
  assert.equal(deferred, 1);
  assert.equal(deleted, 1);
});

test("legacy help menus retain their original requester when a category is selected", async () => {
  let selected;
  await handleHelpSelect({
    values: ["games"], user: { id: "viewer" },
    message: { components: [], interactionMetadata: { user: { id: "owner" } } },
    update: async (payload) => { selected = payload; },
  });
  assert.equal(selected.components[1].toJSON().components.find((button) => button.label === "Cancel").custom_id, "multibot:help:cancel:owner");
});

test("enabling full logs requires View Audit Log for both moderator and bot", async () => {
  const command = commands.find((entry) => entry.data.name === "logs");
  let response;
  const interaction = {
    guild: { id: "guild", members: { me: { permissions: { has: () => false } } } },
    memberPermissions: { has: (permission) => permission === PermissionFlagsBits.ManageGuild },
    options: { getSubcommand: () => "mode", getString: () => "full" },
    reply: async (payload) => { response = payload.content; },
  };
  await command.execute(interaction);
  assert.match(response, /You also need View Audit Log/);
  interaction.memberPermissions.has = () => true;
  await command.execute(interaction);
  assert.match(response, /I need the View Audit Log/);
});

test("log setup enables full mode, reports status, and preserves it when disabled", async (t) => {
  const { store } = await createStore(t);
  const moderation = createModerationStore(store);
  const command = createLogsCommand(moderation);
  let action = "mode";
  let response;
  const interaction = {
    guild: { id: "guild", members: { me: { permissions: { has: () => true } } } },
    memberPermissions: { has: () => true },
    options: {
      getSubcommand: () => action,
      getString: () => "full",
      getChannel: () => ({ id: "private-channel", permissionsFor: () => ({ has: () => true }) }),
    },
    reply: async (payload) => { response = payload.content; },
  };
  await command.execute(interaction);
  assert.match(response, /First choose a private log channel/);
  action = "channel";
  await command.execute(interaction);
  action = "mode";
  await command.execute(interaction);
  assert.match(response, /Full logging enabled/);
  interaction.memberPermissions.has = (permission) => permission === PermissionFlagsBits.ManageGuild;
  action = "channel";
  await command.execute(interaction);
  assert.match(response, /View Audit Log to change the channel/);
  interaction.memberPermissions.has = () => true;
  interaction.guild.members.me.permissions.has = () => false;
  action = "status";
  await command.execute(interaction);
  assert.match(response, /private-channel.*full/);
  assert.match(response, /need View Audit Log/);
  action = "disable";
  await command.execute(interaction);
  assert.deepEqual(await moderation.getAuditLogSettings("guild"), { channelId: "private-channel", mode: "full", enabled: false });
  assert.equal(await moderation.getAuditLogChannel("guild"), null);
});

test("existing log configuration stays enabled and the module toggle persists without losing settings", async (t) => {
  const { filePath, store } = await createStore(t);
  await store.updateGuild("legacy", (guild) => {
    guild.auditLogChannelId = "logs";
    guild.auditLogMode = "full";
  });
  const moderation = createModerationStore(store);
  assert.deepEqual(await moderation.getAuditLogSettings("legacy"), { channelId: "logs", mode: "full", enabled: true });
  await moderation.setAuditLogEnabled("legacy", false);
  const reopened = createModerationStore(createFeatureStore(filePath));
  assert.deepEqual(await reopened.getAuditLogSettings("legacy"), { channelId: "logs", mode: "full", enabled: false });
  assert.equal(await reopened.getAuditLogChannel("legacy"), null);
  await reopened.setAuditLogEnabled("legacy", true);
  assert.equal(await reopened.getAuditLogChannel("legacy"), "logs");
  await assert.rejects(reopened.setAuditLogEnabled("new-guild", true), /Choose an audit-log channel/);
});

test("modlogs setup selects a channel, toggles the module, and changes detail", async (t) => {
  const { store } = await createStore(t);
  const moderation = createModerationStore(store);
  const command = createLogsCommand(moderation);
  const handle = createLogsMenuHandler(moderation);
  const owner = { id: "owner" };
  const bot = { id: "bot", permissions: new PermissionsBitField([PermissionFlagsBits.ViewAuditLog]) };
  const channel = {
    id: "logs", type: ChannelType.GuildText,
    permissionsFor: () => new PermissionsBitField([
      PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks,
    ]),
  };
  const guild = {
    id: "guild",
    members: { me: bot, resolve: () => owner, fetch: async () => owner },
    channels: { fetch: async () => channel },
  };
  const state = { payload: null, problem: null };
  const interaction = {
    guild, guildId: guild.id, user: owner,
    memberPermissions: new PermissionsBitField([PermissionFlagsBits.ManageGuild, PermissionFlagsBits.ViewAuditLog]),
    options: { getSubcommand: () => "setup" },
    reply: async (payload) => { state.payload = payload; },
  };
  await command.execute(interaction);
  assert.equal(state.payload.ephemeral, true);
  assert.match(state.payload.embeds[0].toJSON().description, /Select a private log channel/);
  assert.equal(state.payload.components[0].toJSON().components[0].type, 8);

  const component = {
    ...interaction,
    customId: "multibot:logs:channel:owner",
    values: ["logs"],
    isChannelSelectMenu() { return this.customId.includes(":channel:"); },
    isButton() { return !this.isChannelSelectMenu(); },
    deferUpdate: async () => {},
    editReply: async (payload) => { state.payload = payload; },
    followUp: async (payload) => { state.problem = payload.content; },
  };
  await handle(component);
  assert.deepEqual(await moderation.getAuditLogSettings("guild"), { channelId: "logs", mode: "standard", enabled: true });
  assert.match(state.payload.embeds[0].toJSON().fields[0].value, /Enabled/);
  component.customId = "multibot:logs:mode:owner";
  await handle(component);
  assert.equal((await moderation.getAuditLogSettings("guild")).mode, "full");
  component.customId = "multibot:logs:toggle:owner";
  await handle(component);
  assert.deepEqual(await moderation.getAuditLogSettings("guild"), { channelId: "logs", mode: "full", enabled: false });
  bot.permissions.remove(PermissionFlagsBits.ViewAuditLog);
  await handle(component);
  assert.match(state.problem, /I need View Audit Log/);
  assert.equal((await moderation.getAuditLogSettings("guild")).enabled, false);
  bot.permissions.add(PermissionFlagsBits.ViewAuditLog);
  state.problem = null;
  await handle(component);
  assert.equal((await moderation.getAuditLogSettings("guild")).enabled, true);
  assert.equal(state.problem, null);
});

test("modlogs menu checks ownership, channel access and full-mode permissions", async (t) => {
  const { store } = await createStore(t);
  const moderation = createModerationStore(store);
  const handle = createLogsMenuHandler(moderation);
  const owner = { id: "owner" };
  const bot = { permissions: new PermissionsBitField([]) };
  let canView = false;
  let botCanSend = false;
  const channel = {
    id: "logs", type: ChannelType.GuildText,
    permissionsFor: (member) => new PermissionsBitField((member === bot ? botCanSend : canView) ? [
      PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks,
    ] : []),
  };
  let response;
  const interaction = {
    customId: "multibot:logs:channel:owner",
    guild: { id: "guild", channels: { fetch: async () => channel }, members: { me: bot, resolve: () => owner } },
    user: { id: "other" },
    memberPermissions: new PermissionsBitField([PermissionFlagsBits.ManageGuild]),
    values: ["logs"],
    isChannelSelectMenu: () => true,
    isButton: () => false,
    deferUpdate: async () => {},
    editReply: async () => {},
    reply: async (payload) => { response = payload.content; },
    followUp: async (payload) => { response = payload.content; },
  };
  await handle(interaction);
  assert.match(response, /Only the setup owner/);
  interaction.user = owner;
  await handle(interaction);
  assert.match(response, /You need View Channel/);
  assert.equal((await moderation.getAuditLogSettings("guild")).channelId, null);
  canView = true;
  await handle(interaction);
  assert.match(response, /I need View Channel/);
  assert.equal((await moderation.getAuditLogSettings("guild")).enabled, false);
  botCanSend = true;
  await handle(interaction);
  interaction.customId = "multibot:logs:mode:owner";
  interaction.isChannelSelectMenu = () => false;
  interaction.isButton = () => true;
  await handle(interaction);
  assert.match(response, /You need View Audit Log/);
  interaction.memberPermissions.add(PermissionFlagsBits.ViewAuditLog);
  await handle(interaction);
  assert.match(response, /I need View Audit Log/);
  assert.equal((await moderation.getAuditLogSettings("guild")).mode, "standard");
  const menu = logsSetupMenu("owner", await moderation.getAuditLogSettings("guild"));
  assert.equal(menu.components[1].toJSON().components[0].label, "Disable modlogs");
});

test("the feature dispatcher routes the modlogs channel picker", async () => {
  const client = new EventEmitter();
  registerFeatureEvents(client, () => {});
  let response;
  client.emit(Events.InteractionCreate, {
    customId: "multibot:logs:channel:owner",
    guild: { id: "guild" },
    user: { id: "other" },
    memberPermissions: new PermissionsBitField([PermissionFlagsBits.ManageGuild]),
    isButton: () => false,
    isStringSelectMenu: () => false,
    isChannelSelectMenu: () => true,
    reply: async (payload) => { response = payload.content; },
  });
  await new Promise((resolve) => setImmediate(resolve));
  assert.match(response, /Only the setup owner/);
});

test("full audit entries include actions and actors, redact sensitive values, and respect embed limits", () => {
  const entry = {
    id: "entry", action: AuditLogEvent.RoleUpdate, executorId: "moderator", targetId: "role", targetType: "Role",
    reason: "Changed access",
    changes: [
      { key: "permissions", old: "0", new: "8" },
      { key: "token", old: "old-secret", new: "new-secret" },
      { key: "details", old: { token: "nested-secret", name: "test" }, new: null },
      ...Array.from({ length: 20 }, (_, index) => ({ key: `field-${index}`, old: "x".repeat(500), new: "y".repeat(500) })),
    ],
  };
  const result = createFullAuditEmbed(entry).toJSON();
  const text = JSON.stringify(result);
  assert.match(text, /RoleUpdate/);
  assert.match(text, /moderator/);
  assert.match(text, /\[redacted\]/);
  assert.doesNotMatch(text, /old-secret|new-secret|nested-secret/);
  assert.match(text, /additional changes omitted/);
  const length = result.title.length + result.description.length + result.fields.reduce((sum, field) => sum + field.name.length + field.value.length, 0);
  assert.ok(length < 6000);
});

test("Discord audit entries are sent only when a channel and full mode are configured", async () => {
  const client = new EventEmitter();
  const reports = [];
  let settings = { channelId: "logs", mode: "standard", enabled: true };
  registerAuditEvents(client, (guild, label, event) => reports.push(event.toJSON()), async () => settings);
  const entry = { id: "entry", action: AuditLogEvent.EmojiCreate, changes: [], targetType: "Emoji" };
  client.emit(Events.GuildAuditLogEntryCreate, entry, { id: "guild" });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(reports.length, 0);
  settings = { channelId: null, mode: "full", enabled: false };
  client.emit(Events.GuildAuditLogEntryCreate, entry, { id: "guild" });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(reports.length, 0);
  settings = { channelId: "logs", mode: "full", enabled: false };
  client.emit(Events.GuildAuditLogEntryCreate, entry, { id: "guild" });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(reports.length, 0);
  settings.enabled = true;
  client.emit(Events.GuildAuditLogEntryCreate, entry, { id: "guild" });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(reports.length, 1);
  assert.match(reports[0].description, /EmojiCreate/);
});

test("presence watches rounded member and server counts and preserves optional text", async (t) => {
  const definition = commands.find((command) => command.data.name === "bot-presence").data.toJSON();
  assert.equal(definition.options.find((option) => option.name === "text").required, false);
  assert.equal(definition.options.find((option) => option.name === "server_count").required, false);
  const directory = await mkdtemp(join(tmpdir(), "multibot-presence-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const file = join(directory, "presence.json");
  const manager = createPresenceManager(file);
  const updates = [];
  const client = {
    guilds: { cache: new Map([["one", { id: "one", memberCount: 500 }], ["two", { id: "two", memberCount: 530 }]]) },
    user: { setPresence: (presence) => updates.push(presence) },
  };
  await manager.set(client, { status: "idle", text: "", serverCount: false });
  assert.deepEqual(updates.at(-1), { status: "idle", activities: [] });
  await manager.set(client, { status: "online", text: "Playing", serverCount: true });
  assert.deepEqual(updates.at(-1).activities[0], { name: "Playing | 1k people in 2 servers", type: ActivityType.Watching });
  client.guilds.cache.set("three", { id: "three", memberCount: 50 });
  await createPresenceManager(file).refresh(client, true);
  assert.equal(updates.at(-1).activities[0].name, "Playing | 1,1k people in 3 servers");
  await manager.set(client, { status: "online", text: "x".repeat(128), serverCount: true });
  assert.equal(updates.at(-1).activities[0].name.length, 128);
  assert.match(updates.at(-1).activities[0].name, /1,1k people in 3 servers$/);
  await manager.set(client, { status: "online", text: "hello", serverCount: false });
  assert.deepEqual(updates.at(-1).activities[0], { name: "hello", type: ActivityType.Playing });
});

test("people counts round to the nearest hundred and avoid redundant presence updates", async (t) => {
  const directory = await mkdtemp(join(tmpdir(), "multibot-presence-count-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  const manager = createPresenceManager(join(directory, "presence.json"));
  const guild = { id: "guild", memberCount: 999 };
  const updates = [];
  const client = {
    guilds: { cache: new Map([["guild", guild]]) },
    user: { setPresence: (presence) => updates.push(presence) },
  };
  await manager.set(client, { status: "online", text: "", serverCount: true });
  assert.equal(updates.at(-1).activities[0].name, "999 people in 1 server");
  for (const [count, expected] of [[1000, "1k"], [1030, "1k"], [1049, "1k"], [1050, "1,1k"], [1080, "1,1k"], [1100, "1,1k"], [1999, "2k"]]) {
    guild.memberCount = count;
    await manager.refresh(client, true);
    assert.equal(updates.at(-1).activities[0].name, `${expected} people in 1 server`);
  }
  assert.equal(updates.length, 4);
  const warning = t.mock.method(console, "warn", () => {});
  client.guilds.cache.set("unavailable", { id: "unavailable" });
  await manager.refresh(client, true);
  assert.equal(updates.at(-1).activities[0].name, "2k people in 2 servers");
  assert.match(warning.mock.calls[0].arguments[0], /unavailable/);
});

test("presence refreshes coalesce member changes and periodically reconcile counts", async (t) => {
  let scheduled;
  let periodic;
  t.mock.method(globalThis, "setTimeout", (callback, delay) => {
    assert.equal(delay, 5_000);
    scheduled = callback;
    return 42;
  });
  t.mock.method(globalThis, "setInterval", (callback, delay) => {
    assert.equal(delay, 60_000);
    periodic = callback;
    return 43;
  });
  const client = new EventEmitter();
  client.isReady = () => true;
  const refreshes = [];
  registerPresenceEvents(client, { refresh: async (target, onlyCounts) => refreshes.push([target, onlyCounts]) });
  client.emit(Events.ClientReady);
  client.emit(Events.GuildMemberAdd);
  client.emit(Events.GuildMemberRemove);
  client.emit(Events.GuildCreate);
  assert.equal(refreshes.length, 1);
  assert.equal(globalThis.setTimeout.mock.callCount(), 1);
  scheduled();
  assert.equal(refreshes.length, 2);
  assert.equal(refreshes[1][1], true);
  periodic();
  assert.equal(refreshes.length, 3);
  client.emit(Events.GuildAvailable);
  assert.equal(globalThis.setTimeout.mock.callCount(), 2);
});

test("command typing refreshes, stops, and logs permission failures without throwing", async (t) => {
  let refresh;
  const timer = {};
  const setTimer = t.mock.method(globalThis, "setInterval", (callback, delay) => {
    assert.equal(delay, 8000);
    refresh = callback;
    return timer;
  });
  const clearTimer = t.mock.method(globalThis, "clearInterval", () => {});
  const log = t.mock.method(console, "error", () => {});
  let calls = 0;
  const stop = startCommandTyping({ commandName: "test", channel: { sendTyping: async () => { calls++; throw new Error("Missing permission"); } } });
  await new Promise((resolve) => setImmediate(resolve));
  refresh();
  await new Promise((resolve) => setImmediate(resolve));
  stop();
  assert.equal(calls, 2);
  assert.equal(log.mock.callCount(), 2);
  assert.equal(setTimer.mock.callCount(), 1);
  assert.equal(clearTimer.mock.calls[0].arguments[0], timer);
});

test("audit events report messages, emoji, role, channel and server changes", () => {
  const client = new EventEmitter();
  client.user = { id: "bot" };
  const reports = [];
  registerFeatureEvents(client, (guild, label, event) => reports.push({ guild, label, embed: event.toJSON() }));
  const guild = { id: "guild" };
  client.emit(Events.MessageUpdate, { content: "old" }, { guild, content: "new", channelId: "channel", author: { tag: "user" } });
  client.emit(Events.MessageDelete, { guild, content: null, channelId: "channel" });
  client.emit(Events.GuildEmojiCreate, { guild, id: "emoji", name: "smile" });
  const beforeRole = { guild, id: "role", name: "old", hexColor: "#000000", hoist: false, mentionable: false, permissions: new PermissionsBitField() };
  const afterRole = { ...beforeRole, name: "new", permissions: new PermissionsBitField(PermissionFlagsBits.ManageMessages) };
  client.emit(Events.GuildRoleUpdate, beforeRole, afterRole);
  const channel = { guild, id: "channel", name: "old", type: ChannelType.GuildText, permissionOverwrites: { cache: new Collection() } };
  const overwrites = new Collection([["role", { id: "role", type: 0, allow: new PermissionsBitField(), deny: new PermissionsBitField(PermissionFlagsBits.ViewChannel) }]]);
  client.emit(Events.ChannelUpdate, channel, { ...channel, name: "new", permissionOverwrites: { cache: overwrites } });
  client.emit(Events.GuildUpdate, { id: "guild", name: "old" }, { id: "guild", name: "new" });
  assert.deepEqual(reports.map((report) => report.embed.title), [
    "Message edited", "Message deleted", "Emoji created", "Role updated", "Channel updated", "Server settings updated",
  ]);
  assert.match(reports[1].embed.fields.find((field) => field.name === "Content").value, /unavailable/);
  assert.match(reports[3].embed.fields.find((field) => field.name === "Permissions").value, /ManageMessages/);
  assert.match(reports[4].embed.fields.find((field) => field.name === "Permissions").value, /overwrites changed/);
  client.emit(Events.GuildRoleUpdate, afterRole, afterRole);
  assert.equal(reports.length, 6);
  client.emit(Events.MessageUpdate, { content: "⏳." }, { guild, content: "⏳..", channelId: "channel", author: { id: "bot" } });
  client.emit(Events.MessageUpdate, { content: "⏳..." }, { guild, content: "AI answer", channelId: "channel", author: { id: "bot" } });
  client.emit(Events.MessageDelete, { guild, content: "⏳...", channelId: "channel", author: { id: "bot" } });
  assert.equal(reports.length, 6);
});

test("embed edit changes selected fields and preserves the remaining embed", async () => {
  const command = commands.find((entry) => entry.data.name === "embed-edit");
  const originalEmbed = new EmbedBuilder()
    .setColor(0x57f287)
    .setTitle("Old title")
    .setDescription("Keep this description")
    .setFooter({ text: "Keep this footer" });
  let editedEmbeds;
  const message = {
    author: { id: "bot-id" },
    embeds: [originalEmbed],
    edit: async ({ embeds }) => { editedEmbeds = embeds; },
  };
  const options = { message_id: "message-id", title: "New title" };
  const interaction = {
    channel: { messages: { fetch: async () => message } },
    client: { user: { id: "bot-id" } },
    memberPermissions: { has: () => true },
    options: { getString: (name) => options[name] ?? null, getChannel: () => null },
    deferReply: async () => {},
    editReply: async () => {},
  };

  await command.execute(interaction);

  const editedEmbed = editedEmbeds[0].toJSON();
  assert.equal(editedEmbed.color, 0x57f287);
  assert.equal(editedEmbed.title, "New title");
  assert.equal(editedEmbed.description, "Keep this description");
  assert.equal(editedEmbed.footer.text, "Keep this footer");
});

function channelCommandFixture() {
  const member = { id: "member", roles: { highest: { comparePositionTo: () => 1 } } };
  const bot = { id: "bot" };
  const allPermissions = new PermissionsBitField([
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.EmbedLinks,
    PermissionFlagsBits.ReadMessageHistory,
    PermissionFlagsBits.AddReactions,
    PermissionFlagsBits.ManageRoles,
    PermissionFlagsBits.ManageChannels,
    PermissionFlagsBits.ManageMessages,
    PermissionFlagsBits.ManageGuild,
    PermissionFlagsBits.ModerateMembers,
  ]);
  const posts = [];
  const channel = (id) => ({
    id,
    type: ChannelType.GuildText,
    isTextBased: () => true,
    toString: () => `<#${id}>`,
    memberPermissions: allPermissions,
    botPermissions: allPermissions,
    permissionsFor(subject) { return subject === bot ? this.botPermissions : this.memberPermissions; },
    send: async (payload) => {
      const message = {
        id: "123456789012345678",
        url: "https://discord.com/channels/guild/target/message",
        react: async (emoji) => posts.push({ id, emoji }),
        edit: async () => {},
      };
      posts.push({ id, payload });
      return message;
    },
    messages: {
      fetch: async () => { throw new Error("Unexpected message fetch"); },
      delete: async () => {},
    },
  });
  const current = channel("current");
  const target = channel("target");
  const state = { selected: target, action: "panel", values: {}, response: null };
  const interaction = {
    guildId: "guild",
    guild: {
      id: "guild",
      ownerId: "owner",
      members: { me: bot, resolve: () => member, fetch: async () => member },
      channels: { fetch: async () => target },
    },
    user: { id: "member", tag: "member#0001" },
    client: { user: { id: "bot" } },
    channelId: current.id,
    channel: current,
    memberPermissions: { has: () => true },
    options: {
      getChannel: () => state.selected,
      getSubcommand: () => state.action,
      getString: (name) => state.values[name] ?? null,
      getInteger: (name) => state.values[name] ?? null,
      getRole: () => state.role,
    },
    reply: async (payload) => { state.response = payload.content; },
    deferReply: async () => {},
    editReply: async (payload) => { state.response = typeof payload === "string" ? payload : payload.content; },
  };
  return { interaction, state, current, target, posts };
}

test("channel-selectable commands expose optional channels after required options", () => {
  const expected = {
    warn: null, purge: null, "ai-channel": null, embed: null, "embed-edit": null,
    poll: null, suggest: null, giveaway: ["start"], tickets: ["panel"],
    sticky: ["set", "clear"], "reaction-role": ["post", "add"],
  };
  for (const [name, subcommands] of Object.entries(expected)) {
    const data = commands.find((entry) => entry.data.name === name).data.toJSON();
    const groups = subcommands ? subcommands.map((subcommand) => data.options.find((item) => item.name === subcommand)) : [data];
    for (const group of groups) {
      const options = group.options;
      const channel = options.find((option) => option.name === "channel");
      assert.equal(channel?.type, 7, `${name} ${group.name}`);
      assert.notEqual(channel.required, true);
      assert.ok(channel.channel_types.includes(ChannelType.GuildText));
      const firstOptional = options.findIndex((option) => !option.required);
      assert.ok(options.slice(firstOptional).every((option) => !option.required), `${name} required option order`);
    }
  }
});

test("ticket panels use the selected or current channel and reject missing target permissions", async () => {
  const command = commands.find((entry) => entry.data.name === "tickets");
  const { interaction, state, current, target, posts } = channelCommandFixture();
  await command.execute(interaction);
  assert.equal(posts[0].id, target.id);
  assert.match(state.response, /target/);

  state.selected = { id: target.id, type: ChannelType.GuildText };
  await command.execute(interaction);
  assert.equal(posts[1].id, target.id);

  state.selected = null;
  await command.execute(interaction);
  assert.equal(posts[2].id, current.id);

  state.selected = target;
  target.memberPermissions = new PermissionsBitField([PermissionFlagsBits.ViewChannel]);
  await command.execute(interaction);
  assert.match(state.response, /ManageChannels/);
  assert.equal(posts.length, 3);

  target.memberPermissions = new PermissionsBitField([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ManageChannels]);
  target.botPermissions = new PermissionsBitField([PermissionFlagsBits.ViewChannel]);
  await command.execute(interaction);
  assert.match(state.response, /SendMessages/);
  assert.equal(posts.length, 3);
});

test("cross-channel commands refuse channels the user cannot view", async () => {
  const cases = [
    ["warn"], ["purge"], ["ai-channel", null, { action: "link" }],
    ["giveaway", "start"], ["embed"], ["embed-edit"], ["poll"], ["suggest"],
    ["sticky", "set"], ["sticky", "clear"], ["reaction-role", "post"],
    ["reaction-role", "add"], ["tickets", "panel"],
  ];
  for (const [name, action, values] of cases) {
    const { interaction, state, target, posts } = channelCommandFixture();
    state.action = action;
    state.values = values ?? {};
    state.role = { id: "role", editable: true, permissions: { has: () => false } };
    target.memberPermissions = new PermissionsBitField([]);
    await commands.find((entry) => entry.data.name === name).execute(interaction);
    assert.match(state.response, /ViewChannel/, `${name} ${action ?? ""}`);
    assert.equal(posts.length, 0);
  }
});

test("sticky set, replace and clear use the selected channel and its messages", async () => {
  const records = new Map();
  const store = {
    setStickyMessage: async (guildId, channelId, content) => {
      const previous = records.get(channelId) ?? null;
      records.set(channelId, { content, messageId: previous?.messageId ?? null });
      return previous;
    },
    setStickyMessageId: async (guildId, channelId, messageId) => { records.get(channelId).messageId = messageId; },
    clearStickyMessage: async (guildId, channelId) => {
      const previous = records.get(channelId) ?? null;
      records.delete(channelId);
      return previous;
    },
  };
  const command = createStickyCommand(store);
  const { interaction, state, target, posts } = channelCommandFixture();
  state.action = "set";
  state.values.message = "First sticky";
  await command.execute(interaction);
  assert.deepEqual(records.get("target"), { content: "First sticky", messageId: "123456789012345678" });
  assert.equal(records.has("current"), false);
  let edited;
  target.messages.fetch = async (id) => ({
    id,
    edit: async (payload) => { edited = { id, content: payload.content }; },
  });
  state.values.message = "Updated sticky";
  await command.execute(interaction);
  assert.deepEqual(edited, { id: "123456789012345678", content: "Updated sticky" });
  assert.equal(posts.length, 1);
  let deleted;
  target.messages.delete = async (id) => { deleted = id; };
  state.action = "clear";
  await command.execute(interaction);
  assert.equal(deleted, "123456789012345678");
  assert.equal(records.has("target"), false);
});

test("reaction roles fetch and store the selected message channel", async () => {
  let saved;
  const command = createReactionRoleCommand({
    addReactionRole: async (...args) => { saved = args; return null; },
  });
  const { interaction, state, target, posts } = channelCommandFixture();
  state.action = "add";
  state.values = { message_id: "123456789012345678", emoji: "🎮" };
  state.role = { id: "role", editable: true, permissions: { has: () => false } };
  let fetched;
  target.messages.fetch = async (id) => {
    fetched = id;
    return { url: "https://discord.com/channels/guild/target/message", react: async (emoji) => posts.push({ emoji }) };
  };
  await command.execute(interaction);
  assert.equal(fetched, state.values.message_id);
  assert.deepEqual(saved, ["guild", state.values.message_id, "target", "🎮", "role"]);
  assert.deepEqual(posts, [{ emoji: "🎮" }]);
});

test("polls and embed edits act in the selected channel and deny inaccessible targets", async () => {
  const { interaction, state, target, posts } = channelCommandFixture();
  state.values = { question: "Question?", option1: "A", option2: "B" };
  const poll = commands.find((entry) => entry.data.name === "poll");
  await poll.execute(interaction);
  assert.equal(posts[0].id, "target");
  assert.deepEqual(posts.slice(1).map((post) => post.emoji), ["1️⃣", "2️⃣"]);
  assert.match(state.response, /<#target>/);

  let fetched;
  target.messages.fetch = async (id) => {
    fetched = id;
    return { author: { id: "bot" }, embeds: [new EmbedBuilder().setTitle("Old")], edit: async () => {} };
  };
  state.values = { message_id: "message", title: "New" };
  const edit = commands.find((entry) => entry.data.name === "embed-edit");
  await edit.execute(interaction);
  assert.equal(fetched, "message");
  target.memberPermissions = new PermissionsBitField([PermissionFlagsBits.SendMessages]);
  fetched = null;
  await edit.execute(interaction);
  assert.equal(fetched, null);
  assert.match(state.response, /ViewChannel/);
});

test("would-you-rather provides at least 50 unique prompts", async () => {
  const command = commands.find((entry) => entry.data.name === "wyr");
  const prompts = new Set();
  const originalRandom = Math.random;

  try {
    for (let index = 0; index < 100; index += 1) {
      Math.random = () => index / 100;
      let response;
      await command.execute({ reply: async (content) => { response = content; } });
      prompts.add(response);
    }
  } finally {
    Math.random = originalRandom;
  }

  assert.ok(prompts.size >= 50);
});
