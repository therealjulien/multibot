import assert from "node:assert/strict";
import { copyFile, mkdir, mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { pathToFileURL } from "node:url";
import { aiReplyOptions, askAi, isAiThinkingContent, withAiThinking } from "../src/ai.js";
import { createAiCommand } from "../src/commands/legacy.js";
import { createCommandCooldown } from "../src/features/cooldown.js";
import { runCommand } from "../src/features/command-progress.js";

test("AI replies mention only the requester and stay within Discord's message limit", () => {
  const reply = aiReplyOptions("123456789012345678", `@everyone <@999999999999999999> ${"x".repeat(2200)}`);
  assert.match(reply.content, /^<@123456789012345678>/);
  assert.ok(reply.content.length <= 2000);
  assert.deepEqual(reply.allowedMentions, { parse: [], users: ["123456789012345678"], repliedUser: false });
});

test("AI replies render Markdown tables and HTML breaks as readable Discord text", () => {
  const text = [
    "Overview:",
    "",
    "| Topic | Details |",
    "|-------|:--------|",
    "| **Career** | • First role<br>• Second role |",
    "| Vision | Friendly AI<br /> Global cooperation |",
    "",
    "Done.<BR/>Next line.",
  ].join("\n");
  assert.equal(aiReplyOptions("123", text).content, [
    "<@123> Overview:",
    "",
    "**Career**",
    "• First role",
    "• Second role",
    "",
    "**Vision**",
    "Friendly AI",
    " Global cooperation",
    "",
    "Done.",
    "Next line.",
  ].join("\n"));
});

test("AI formatting preserves code and handles multi-column tables with escaped pipes", () => {
  const text = [
    "Use `<br>` and `a | b` in code.",
    "```html",
    "| A | B |",
    "| --- | --- |",
    "| <br> | value |",
    "```",
    "",
    "Name | **Value** | Note",
    "--- | ---: | :---:",
    "One | `a | b` | A \\| B",
    "",
    "A | B",
    "Not a table",
  ].join("\n");
  assert.equal(aiReplyOptions("123", text).content, [
    "<@123> Use `<br>` and `a | b` in code.",
    "```html",
    "| A | B |",
    "| --- | --- |",
    "| <br> | value |",
    "```",
    "",
    "**One**",
    "**Value**: `a | b`",
    "**Note**: A \\| B",
    "",
    "A | B",
    "Not a table",
  ].join("\n"));
});

test("/ai replies publicly and still mentions the requester", async () => {
  let deferredOptions;
  let response;
  const command = createAiCommand(async () => ({ text: "| Topic | Details |\n| --- | --- |\n| Greeting | Hello! |" }));
  await command.execute({
    guildId: "guild",
    user: { id: "123456789012345678" },
    options: { getString: () => "Hi" },
    deferReply: async (options) => { deferredOptions = options; },
    editReply: async (options) => { response = options; },
  });
  assert.equal(deferredOptions?.ephemeral, undefined);
  assert.equal(response.content, "<@123456789012345678> **Greeting**\nHello!");
  assert.deepEqual(response.allowedMentions.users, ["123456789012345678"]);
});

test("/ai uses the shared server command cooldown through the dispatcher", async (t) => {
  const ticks = [];
  t.mock.method(globalThis, "setInterval", (callback) => { ticks.push(callback); return ticks.length; });
  t.mock.method(globalThis, "clearInterval", () => {});
  const command = createAiCommand(async (guildId, userId, prompt, withThinking) =>
    ({ text: await withThinking(async () => "Hello!") }));
  const makeInteraction = (id) => {
    const updates = [];
    const interaction = {
      guildId: "guild", commandName: "ai", user: { id },
      options: { getString: () => "Hi" },
      deferReply: async () => { interaction.deferred = true; },
      reply: async () => assert.fail("unexpected reply"),
      editReply: async (payload) => updates.push(payload),
    };
    return { interaction, updates };
  };
  const first = makeInteraction("123456789012345678");
  const second = makeInteraction("223456789012345678");
  const cooldown = createCommandCooldown();
  let finished = 0;
  const pending = Promise.all([first, second].map(({ interaction }) =>
    runCommand(interaction, command, cooldown).then(() => { finished++; })));
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(ticks.length, 2);
  for (const tick of ticks) tick();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(finished, 0);
  for (const tick of ticks) tick();
  await pending;
  assert.equal(first.updates.at(-2).content, "⏳..");
  assert.equal(first.updates.at(-1).content, "<@123456789012345678> Hello!");
  assert.deepEqual(first.updates.at(-1).allowedMentions.users, ["123456789012345678"]);
  assert.equal(second.updates.at(-2).content, "⏳..");
});

test("AI thinking adds a dot every second and keeps a fast answer for five ticks", async (t) => {
  let tick;
  const timer = {};
  t.mock.method(globalThis, "setInterval", (callback, delay) => {
    assert.equal(delay, 1_000);
    tick = callback;
    return timer;
  });
  const clear = t.mock.method(globalThis, "clearInterval", () => {});
  const updates = [];
  let finished = false;
  const pending = withAiThinking(async () => "answer", async (content) => { updates.push(content); })
    .then((answer) => { finished = true; return answer; });
  await new Promise((resolve) => setImmediate(resolve));
  assert.deepEqual(updates, ["⏳"]);
  for (let index = 0; index < 4; index++) {
    tick();
    await new Promise((resolve) => setImmediate(resolve));
    assert.equal(finished, false);
  }
  tick();
  assert.equal(await pending, "answer");
  assert.deepEqual(updates, ["⏳", "⏳.", "⏳..", "⏳...", "⏳....", "⏳....."]);
  assert.equal(clear.mock.calls[0].arguments[0], timer);
});

test("thinking continues for slow requests and clears its timer on errors", async (t) => {
  let tick;
  const clear = t.mock.method(globalThis, "clearInterval", () => {});
  t.mock.method(globalThis, "setInterval", (callback) => { tick = callback; return 42; });
  const updates = [];
  let resolveAnswer;
  const pending = withAiThinking(() => new Promise((resolve) => { resolveAnswer = resolve; }), async (content) => updates.push(content));
  await new Promise((resolve) => setImmediate(resolve));
  for (let index = 0; index < 6; index++) {
    tick();
    await new Promise((resolve) => setImmediate(resolve));
  }
  assert.equal(updates.at(-1), "⏳......");
  resolveAnswer("slow answer");
  assert.equal(await pending, "slow answer");
  await assert.rejects(withAiThinking(async () => { throw new Error("AI failed"); }, async () => {}), /AI failed/);
  assert.equal(clear.mock.callCount(), 2);
});

test("slow AI requests stop the hourglass after ten seconds but keep waiting", async (t) => {
  let tick;
  const clear = t.mock.method(globalThis, "clearInterval", () => {});
  t.mock.method(globalThis, "setInterval", (callback) => { tick = callback; return 42; });
  let resolveAnswer;
  const updates = [];
  let finished = false;
  const pending = withAiThinking(
    () => new Promise((resolve) => { resolveAnswer = resolve; }),
    async (content) => updates.push(content),
    5
  ).then((value) => { finished = true; return value; });
  await new Promise((resolve) => setImmediate(resolve));
  for (let index = 0; index < 10; index++) {
    tick();
    await new Promise((resolve) => setImmediate(resolve));
  }
  assert.equal(finished, false);
  assert.equal(updates.at(-1), "The AI is still working. Please wait...");
  assert.equal(isAiThinkingContent(updates.at(-1)), true);
  assert.equal(clear.mock.callCount(), 1);
  resolveAnswer("slow answer");
  assert.equal(await pending, "slow answer");
  assert.equal(clear.mock.callCount(), 1);
});

test("AI channel replaces its thinking message with a requester-mentioning answer", async (t) => {
  const directory = await mkdtemp(join(tmpdir(), "multibot-ai-response-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  await mkdir(join(directory, "src"));
  await copyFile(new URL("../src/ai.js", import.meta.url), join(directory, "src", "ai.mjs"));
  const { replyToAiChannelMessage, setAiChannel } = await import(pathToFileURL(join(directory, "src", "ai.mjs")).href);
  await setAiChannel("guild", "channel");
  const originalApiKey = process.env.GROQ_API_KEY;
  t.after(() => {
    if (originalApiKey === undefined) delete process.env.GROQ_API_KEY;
    else process.env.GROQ_API_KEY = originalApiKey;
  });
  process.env.GROQ_API_KEY = "test-groq-key";
  t.mock.method(globalThis, "fetch", async () => Response.json({
    choices: [{ message: { content: "| Topic | Details |\n| --- | --- |\n| Greeting | Hello<br>there! |" } }],
  }));
  let tick;
  let started;
  const ready = new Promise((resolve) => { started = resolve; });
  t.mock.method(globalThis, "setInterval", (callback, delay) => {
    if (delay === 1_000) { tick = callback; started(); }
    return { delay };
  });
  t.mock.method(globalThis, "clearInterval", () => {});
  const sent = [];
  const edits = [];
  const message = {
    guildId: "guild", channelId: "channel", author: { id: "123456789012345678" }, content: "Hi",
    channel: { sendTyping: async () => {} },
    reply: async (options) => {
      sent.push(options);
      return { edit: async (payload) => edits.push(payload), delete: async () => assert.fail("should not delete") };
    },
  };
  const pending = replyToAiChannelMessage(message);
  await ready;
  for (let index = 0; index < 5; index++) {
    tick();
    await new Promise((resolve) => setImmediate(resolve));
  }
  await pending;
  assert.equal(sent.length, 1);
  assert.equal(sent[0].content, "⏳");
  assert.deepEqual(edits.slice(0, 5).map((edit) => edit.content), ["⏳.", "⏳..", "⏳...", "⏳....", "⏳....."]);
  assert.equal(edits.at(-1).content, "<@123456789012345678> **Greeting**\nHello\nthere!");
  assert.deepEqual(edits.at(-1).allowedMentions.users, ["123456789012345678"]);
});

test("AI channel removes its thinking message if AI is disabled while waiting", async (t) => {
  const directory = await mkdtemp(join(tmpdir(), "multibot-ai-disabled-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  await mkdir(join(directory, "src"));
  await copyFile(new URL("../src/ai.js", import.meta.url), join(directory, "src", "ai.mjs"));
  const { replyToAiChannelMessage, setAiChannel, setAiEnabled } = await import(pathToFileURL(join(directory, "src", "ai.mjs")).href);
  await setAiChannel("guild", "channel");
  const originalApiKey = process.env.GROQ_API_KEY;
  t.after(() => {
    if (originalApiKey === undefined) delete process.env.GROQ_API_KEY;
    else process.env.GROQ_API_KEY = originalApiKey;
  });
  process.env.GROQ_API_KEY = "test-groq-key";
  let resolveFetch;
  let notifyStarted;
  const started = new Promise((resolve) => { notifyStarted = resolve; });
  t.mock.method(globalThis, "fetch", () => {
    notifyStarted();
    return new Promise((resolve) => { resolveFetch = resolve; });
  });
  let tick;
  t.mock.method(globalThis, "setInterval", (callback, delay) => {
    if (delay === 1_000) tick = callback;
    return { delay };
  });
  t.mock.method(globalThis, "clearInterval", () => {});
  let deleted = 0;
  const edits = [];
  const message = {
    guildId: "guild", channelId: "channel", author: { id: "user" }, content: "Hi",
    channel: { sendTyping: async () => {} },
    reply: async () => ({ edit: async (payload) => edits.push(payload), delete: async () => { deleted++; } }),
  };
  const pending = replyToAiChannelMessage(message);
  await started;
  await setAiEnabled("guild", false);
  resolveFetch(Response.json({ choices: [{ message: { content: "Answer" } }] }));
  for (let index = 0; index < 5; index++) tick();
  await pending;
  assert.equal(deleted, 1);
  assert.ok(edits.every((edit) => edit.content.startsWith("⏳")));
});

test("AI cooldown lasts exactly five seconds and is shared by slash and channel requests", async (t) => {
  const directory = await mkdtemp(join(tmpdir(), "multibot-ai-cooldown-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  await mkdir(join(directory, "src"));
  await copyFile(new URL("../src/ai.js", import.meta.url), join(directory, "src", "ai.mjs"));
  const { askAi: ask, handleAiChannelMessage, setAiChannel } = await import(pathToFileURL(join(directory, "src", "ai.mjs")).href);
  await setAiChannel("guild", "channel");
  const originalApiKey = process.env.GROQ_API_KEY;
  t.after(() => {
    if (originalApiKey === undefined) delete process.env.GROQ_API_KEY;
    else process.env.GROQ_API_KEY = originalApiKey;
  });
  process.env.GROQ_API_KEY = "test-groq-key";
  let now = 100_000;
  t.mock.method(Date, "now", () => now);
  let calls = 0;
  t.mock.method(globalThis, "fetch", async () => {
    calls++;
    return Response.json({ choices: [{ message: { content: "Hello!" } }] });
  });
  const message = {
    guildId: "guild", channelId: "channel", author: { id: "user" }, content: "Hi",
    channel: { sendTyping: async () => {} },
  };
  assert.deepEqual(await ask("guild", "user", "Hi"), { text: "Hello!" });
  now += 4_999;
  assert.deepEqual(await handleAiChannelMessage(message), { status: "cooldown" });
  assert.equal(calls, 1);
  now++;
  assert.deepEqual(await handleAiChannelMessage(message), { status: "responded", text: "Hello!" });
  assert.equal(calls, 2);
  now += 4_999;
  assert.match((await ask("guild", "user", "Hi")).error, /wait 1 seconds/);
  assert.deepEqual(await ask("guild", "other", "Hi"), { text: "Hello!" });
  now++;
  assert.deepEqual(await ask("guild", "user", "Hi"), { text: "Hello!" });
});

async function isolatedAi(t, label) {
  const directory = await mkdtemp(join(tmpdir(), `multibot-${label}-`));
  t.after(() => rm(directory, { recursive: true, force: true }));
  await mkdir(join(directory, "src"));
  await copyFile(new URL("../src/ai.js", import.meta.url), join(directory, "src", "ai.mjs"));
  return import(pathToFileURL(join(directory, "src", "ai.mjs")).href);
}

function useTestAiKey(t) {
  const original = process.env.GROQ_API_KEY;
  t.after(() => {
    if (original === undefined) delete process.env.GROQ_API_KEY;
    else process.env.GROQ_API_KEY = original;
  });
  process.env.GROQ_API_KEY = "test-groq-key";
}

function controlledFetch(t) {
  const calls = [];
  const waiters = [];
  t.mock.method(globalThis, "fetch", async (url, options) => {
    let resolve;
    let reject;
    const pending = new Promise((yes, no) => { resolve = yes; reject = no; });
    calls.push({ resolve, reject, body: JSON.parse(options.body) });
    for (const waiter of waiters.splice(0)) waiter();
    return pending;
  });
  return {
    calls,
    async waitFor(count) {
      while (calls.length < count) await new Promise((resolve) => waiters.push(resolve));
    },
    answer(index, text) {
      calls[index].resolve(Response.json({ choices: [{ message: { content: text } }] }));
    },
  };
}

test("each server permits two shared slash and channel AI prompts, and releases failed slots", async (t) => {
  const { askAi: ask, handleAiChannelMessage, setAiChannel } = await isolatedAi(t, "ai-concurrency");
  await setAiChannel("guild", "channel");
  useTestAiKey(t);
  const fetch = controlledFetch(t);
  const durations = [];
  const thinking = (operation, ticks) => { durations.push(ticks); return operation(); };
  const message = (user) => ({
    guildId: "guild", channelId: "channel", author: { id: user }, content: "Hi",
    channel: { sendTyping: async () => {} },
  });
  const first = ask("guild", "first", "Hi", thinking);
  const second = handleAiChannelMessage(message("second"), thinking);
  await fetch.waitFor(2);
  assert.deepEqual(durations, [5, 10]);
  assert.match((await ask("guild", "third", "Hi")).error, /two AI prompts/);
  assert.match((await handleAiChannelMessage(message("fourth"))).error, /two AI prompts/);
  assert.equal(fetch.calls.length, 2);

  const otherServer = ask("other-guild", "other", "Hi", thinking);
  await fetch.waitFor(3);
  assert.equal(durations[2], 5);
  fetch.answer(0, "First");
  assert.deepEqual(await first, { text: "First" });
  const retry = ask("guild", "third", "Hi", thinking);
  await fetch.waitFor(4);
  assert.equal(durations[3], 10);
  const failed = assert.rejects(second, /Could not reach the AI service/);
  fetch.calls[1].reject(new Error("network failure"));
  await failed;
  const replacement = ask("guild", "replacement", "Hi", thinking);
  await fetch.waitFor(5);
  fetch.answer(2, "Other server");
  fetch.answer(3, "Retry");
  fetch.answer(4, "Replacement");
  assert.deepEqual(await Promise.all([otherServer, retry, replacement]), [
    { text: "Other server" }, { text: "Retry" }, { text: "Replacement" },
  ]);
});

test("completed AI requests hold their server slots until their thinking finishes", async (t) => {
  const { askAi: ask } = await isolatedAi(t, "ai-thinking-slots");
  useTestAiKey(t);
  t.mock.method(globalThis, "fetch", async () => Response.json({ choices: [{ message: { content: "Hello" } }] }));
  let releaseThinking;
  const gate = new Promise((resolve) => { releaseThinking = resolve; });
  let bothReady;
  const ready = new Promise((resolve) => { bothReady = resolve; });
  let count = 0;
  const thinking = async (operation) => {
    const text = await operation();
    if (++count === 2) bothReady();
    await gate;
    return text;
  };
  const first = ask("guild", "a", "Hi", thinking);
  const second = ask("guild", "b", "Hi", thinking);
  await ready;
  assert.match((await ask("guild", "c", "Hi")).error, /two AI prompts/);
  releaseThinking();
  assert.deepEqual(await Promise.all([first, second]), [{ text: "Hello" }, { text: "Hello" }]);
  assert.deepEqual(await ask("guild", "c", "Hi"), { text: "Hello" });
});

test("/ai holds AI slots through the shared command cooldown", async (t) => {
  const { askAi: ask } = await isolatedAi(t, "ai-slash-slots");
  useTestAiKey(t);
  let fetchCount = 0;
  let notifyStarted;
  const started = new Promise((resolve) => { notifyStarted = resolve; });
  t.mock.method(globalThis, "fetch", async () => {
    if (++fetchCount === 2) notifyStarted();
    return Response.json({ choices: [{ message: { content: "Hello" } }] });
  });
  const ticks = [];
  t.mock.method(globalThis, "setInterval", (callback) => { ticks.push(callback); return ticks.length; });
  t.mock.method(globalThis, "clearInterval", () => {});
  const command = createAiCommand(ask);
  const cooldown = createCommandCooldown();
  const makeInteraction = (id) => {
    const interaction = {
      guildId: "guild", commandName: "ai", user: { id },
      options: { getString: () => "Hi" },
      deferReply: async () => { interaction.deferred = true; },
      editReply: async () => {},
      reply: async () => assert.fail("unexpected reply"),
    };
    return interaction;
  };
  const pending = Promise.all(["a", "b"].map((id) => runCommand(makeInteraction(id), command, cooldown)));
  await started;
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(ticks.length, 2);
  for (const tick of ticks) tick();
  await new Promise((resolve) => setImmediate(resolve));
  assert.match((await ask("guild", "c", "Hi")).error, /two AI prompts/);
  for (const tick of ticks) tick();
  await pending;
  assert.deepEqual(await ask("guild", "c", "Hi"), { text: "Hello" });
});

test("concurrent AI channel responses retain both completed exchanges in history", async (t) => {
  const { handleAiChannelMessage, setAiChannel } = await isolatedAi(t, "ai-history");
  await setAiChannel("guild", "channel");
  useTestAiKey(t);
  const fetch = controlledFetch(t);
  const message = (user, content) => ({
    guildId: "guild", channelId: "channel", author: { id: user }, content,
    channel: { sendTyping: async () => {} },
  });
  const first = handleAiChannelMessage(message("a", "First question"));
  const second = handleAiChannelMessage(message("b", "Second question"));
  await fetch.waitFor(2);
  fetch.answer(1, "Second answer");
  await second;
  fetch.answer(0, "First answer");
  await first;
  const third = handleAiChannelMessage(message("c", "Third question"));
  await fetch.waitFor(3);
  assert.deepEqual(fetch.calls[2].body.messages.slice(1).map(({ content }) => content), [
    "Second question", "Second answer", "First question", "First answer", "Third question",
  ]);
  fetch.answer(2, "Third answer");
  assert.equal((await third).text, "Third answer");
});

test("AI requests use GroqCloud with the configured model and API key", async (t) => {
  const originalFetch = globalThis.fetch;
  const originalApiKey = process.env.GROQ_API_KEY;
  const originalModel = process.env.GROQ_MODEL;
  t.after(() => {
    globalThis.fetch = originalFetch;
    if (originalApiKey === undefined) delete process.env.GROQ_API_KEY;
    else process.env.GROQ_API_KEY = originalApiKey;
    if (originalModel === undefined) delete process.env.GROQ_MODEL;
    else process.env.GROQ_MODEL = originalModel;
  });

  process.env.GROQ_API_KEY = "test-groq-key";
  process.env.GROQ_MODEL = "test-model";
  const calls = [];
  globalThis.fetch = async (url, options) => {
    calls.push({ url, options, body: JSON.parse(options.body) });
    return Response.json({ choices: [{ message: { content: "Hello!" } }] });
  };
  assert.deepEqual(await askAi("groq-test-guild", "first-user", "Hi"), { text: "Hello!" });
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, "https://api.groq.com/openai/v1/chat/completions");
  assert.equal(calls[0].options.headers.Authorization, "Bearer test-groq-key");
  assert.equal(calls[0].body.model, "test-model");
  assert.deepEqual(calls[0].body.messages, [
    {
      role: "system",
      content: "You are a helpful assistant chatting in a Discord community. Be clear, friendly, and concise. Format responses for Discord using short paragraphs and bullet lists. Do not use Markdown tables or HTML; use lists instead.",
    },
    { role: "user", content: "Hi" },
  ]);
  assert.deepEqual(await askAi("groq-test-guild", "second-user", "Hi"), { text: "Hello!" });
  assert.equal(calls.length, 2);

  delete process.env.GROQ_MODEL;
  assert.deepEqual(await askAi("groq-test-guild", "third-user", "Hi"), { text: "Hello!" });
  assert.equal(calls[2].body.model, "openai/gpt-oss-20b");
});

test("AI requests report missing GroqCloud credentials without calling the API", async (t) => {
  const originalFetch = globalThis.fetch;
  const originalApiKey = process.env.GROQ_API_KEY;
  t.after(() => {
    globalThis.fetch = originalFetch;
    if (originalApiKey === undefined) delete process.env.GROQ_API_KEY;
    else process.env.GROQ_API_KEY = originalApiKey;
  });

  delete process.env.GROQ_API_KEY;
  let called = false;
  globalThis.fetch = async () => {
    called = true;
    return Response.json({});
  };
  assert.deepEqual(await askAi("groq-missing-key-guild", "user", "Hi"), {
    error: "AI is not configured. Set GROQ_API_KEY in the bot's .env file.",
  });
  assert.equal(called, false);
});

test("AI channel typing is refreshed while waiting and stopped on success or failure", async (t) => {
  const directory = await mkdtemp(join(tmpdir(), "multibot-ai-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  await mkdir(join(directory, "src"));
  await copyFile(new URL("../src/ai.js", import.meta.url), join(directory, "src", "ai.mjs"));
  const { handleAiChannelMessage, setAiChannel } = await import(pathToFileURL(join(directory, "src", "ai.mjs")).href);
  await setAiChannel("typing-guild", "typing-channel");

  const originalApiKey = process.env.GROQ_API_KEY;
  t.after(() => {
    if (originalApiKey === undefined) delete process.env.GROQ_API_KEY;
    else process.env.GROQ_API_KEY = originalApiKey;
  });
  process.env.GROQ_API_KEY = "test-groq-key";

  let refresh;
  const timer = {};
  const setTimer = t.mock.method(globalThis, "setInterval", (callback, delay) => {
    refresh = callback;
    assert.equal(delay, 8_000);
    return timer;
  });
  const clearTimer = t.mock.method(globalThis, "clearInterval", () => {});
  let resolveFetch;
  let fetchStarted;
  const started = new Promise((resolve) => { fetchStarted = resolve; });
  t.mock.method(globalThis, "fetch", () => {
    fetchStarted();
    return new Promise((resolve) => { resolveFetch = resolve; });
  });
  let typingCount = 0;
  const message = {
    guildId: "typing-guild",
    channelId: "typing-channel",
    author: { id: "first-user" },
    content: "Hi",
    channel: { sendTyping: async () => { typingCount++; } },
  };

  assert.deepEqual(await handleAiChannelMessage({ ...message, channelId: "other-channel" }), { status: "inactive" });
  assert.equal(typingCount, 0);
  const pending = handleAiChannelMessage(message);
  await started;
  assert.equal(typingCount, 1);
  refresh();
  assert.equal(typingCount, 2);
  resolveFetch(Response.json({ choices: [{ message: { content: "Hello!" } }] }));
  assert.deepEqual(await pending, { status: "responded", text: "Hello!" });
  assert.equal(clearTimer.mock.callCount(), 1);
  assert.equal(clearTimer.mock.calls[0].arguments[0], timer);

  assert.deepEqual(await handleAiChannelMessage(message), { status: "cooldown" });
  assert.equal(typingCount, 2);

  const logError = t.mock.method(console, "error", () => {});
  globalThis.fetch.mock.mockImplementation(async () => Response.json({ choices: [{ message: { content: "Still works" } }] }));
  const typingFailure = {
    ...message,
    author: { id: "third-user" },
    channel: { sendTyping: async () => { throw new Error("Missing permission"); } },
  };
  assert.deepEqual(await handleAiChannelMessage(typingFailure), { status: "responded", text: "Still works" });
  assert.equal(logError.mock.callCount(), 1);

  globalThis.fetch.mock.mockImplementation(async () => Response.json({ error: { message: "Failed" } }, { status: 500 }));
  await assert.rejects(handleAiChannelMessage({ ...message, author: { id: "second-user" } }), /HTTP 500/);
  assert.equal(setTimer.mock.callCount(), 3);
  assert.equal(clearTimer.mock.callCount(), 3);
});
