import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";
import { createCommunityStore } from "../src/community.js";

async function createStore(t) {
  const directory = await mkdtemp(join(tmpdir(), "multibot-community-"));
  t.after(() => rm(directory, { recursive: true, force: true }));
  return createCommunityStore(join(directory, "community.json"));
}

test("welcome settings and automatic roles persist independently per guild", async (t) => {
  const store = await createStore(t);
  assert.deepEqual(await store.getGuildSettings("guild-a"), {
    welcomeChannelId: null,
    welcomeMessage: null,
    autoRoleId: null,
  });

  await store.setWelcomeSettings("guild-a", "channel-a", "Hello {user}", "role-a");
  await store.setWelcomeSettings("guild-b", "channel-b", "Welcome {server}");
  await store.setAutoRole("guild-a", null);

  assert.deepEqual(await store.getGuildSettings("guild-a"), {
    welcomeChannelId: "channel-a",
    welcomeMessage: "Hello {user}",
    autoRoleId: null,
  });
  assert.deepEqual(await store.getGuildSettings("guild-b"), {
    welcomeChannelId: "channel-b",
    welcomeMessage: "Welcome {server}",
    autoRoleId: null,
  });

  await store.disableWelcome("guild-a");
  assert.deepEqual(await store.getGuildSettings("guild-a"), {
    welcomeChannelId: null,
    welcomeMessage: null,
    autoRoleId: null,
  });
});

test("welcome message edits preserve the configured channel and automatic role", async (t) => {
  const store = await createStore(t);
  assert.equal(await store.updateWelcomeMessage("guild-a", "Updated {user}"), null);

  await store.setWelcomeSettings("guild-a", "channel-a", "Hello {user}", "role-a");
  assert.deepEqual(await store.updateWelcomeMessage("guild-a", "Welcome {user} to {server}"), {
    welcomeChannelId: "channel-a",
    welcomeMessage: "Welcome {user} to {server}",
    autoRoleId: "role-a",
  });
  assert.deepEqual(await store.getGuildSettings("guild-a"), {
    welcomeChannelId: "channel-a",
    welcomeMessage: "Welcome {user} to {server}",
    autoRoleId: "role-a",
  });
});

test("giveaway entries are unique and ending persists one winner selection", async (t) => {
  const store = await createStore(t);
  const now = Date.now();
  await store.createGiveaway({
    messageId: "message-a",
    guildId: "guild-a",
    channelId: "channel-a",
    prize: "A silly hat",
    winnerCount: 2,
    endsAt: now + 60_000,
  });

  const duplicateEntries = await Promise.all([
    store.joinGiveaway("message-a", "user-a", now),
    store.joinGiveaway("message-a", "user-a", now),
  ]);
  assert.deepEqual(duplicateEntries.map((entry) => entry.status).sort(), ["already_entered", "joined"]);
  await store.joinGiveaway("message-a", "user-b", now);
  assert.equal(await store.prepareGiveawayEnd("message-a", { now }), null);

  const ending = await store.prepareGiveawayEnd("message-a", { now: now + 120_000 });
  assert.equal(ending.status, "ending");
  assert.equal(ending.winnerIds.length, 2);
  assert.equal(new Set(ending.winnerIds).size, 2);
  assert.ok(ending.winnerIds.every((userId) => ["user-a", "user-b"].includes(userId)));
  assert.equal((await store.joinGiveaway("message-a", "user-c", now + 120_000)).status, "closed");

  const retry = await store.prepareGiveawayEnd("message-a", { now: now + 180_000 });
  assert.deepEqual(retry.winnerIds, ending.winnerIds);
  assert.deepEqual(
    (await store.getDueGiveaways(now + 180_000)).map((giveaway) => giveaway.messageId),
    ["message-a"]
  );
  assert.equal((await store.completeGiveaway("message-a")).status, "ended");
  assert.deepEqual(await store.getDueGiveaways(now + 180_000), []);
});
