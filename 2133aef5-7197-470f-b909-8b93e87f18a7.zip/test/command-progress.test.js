import assert from "node:assert/strict";
import test from "node:test";
import { MessageFlags } from "discord.js";
import { createCommandCooldown } from "../src/features/cooldown.js";
import { createCommandProgress, runCommand, withCommandThinking } from "../src/features/command-progress.js";
import { createSlotsCommand } from "../src/commands/legacy.js";

test("command load is isolated per server, counts concurrent users, and is capped at eight", () => {
  const cooldown = createCommandCooldown();
  const first = cooldown.claim("user-a", "guild-a");
  assert.equal(first.error, undefined);
  assert.equal(first.minimumTicks, 1);
  assert.match(cooldown.claim("user-a", "guild-a").error, /still running/);
  const other = cooldown.claim("other", "guild-b");
  assert.equal(other.minimumTicks, 1);
  const active = Array.from({ length: 9 }, (_, index) => cooldown.claim(`user-${index}`, "guild-a"));
  assert.equal(first.minimumTicks, 8);
  assert.equal(active.at(-1).minimumTicks, 8);
  assert.equal(other.minimumTicks, 1);
  first.release();
  for (const entry of active) entry.release();
  other.release();
  const next = cooldown.claim("user-a", "guild-a");
  assert.equal(next.minimumTicks, 1);
  next.release();
});

function mockProgress(t) {
  let tick;
  const timer = {};
  t.mock.method(globalThis, "setInterval", (callback, delay) => {
    assert.equal(delay, 1_000);
    tick = callback;
    return timer;
  });
  const clear = t.mock.method(globalThis, "clearInterval", () => {});
  const calls = [];
  const original = {
    commandName: "test",
    replied: false,
    deferred: false,
    reply: async (payload) => { original.replied = true; calls.push(["reply", payload]); },
    deferReply: async (payload) => { original.deferred = true; calls.push(["defer", payload]); },
    editReply: async (payload) => { calls.push(["edit", payload]); return payload; },
  };
  return {
    original, calls, clear, timer, progress: createCommandProgress(original, { minimumTicks: 3 }),
    tick: async () => { tick(); await new Promise((resolve) => setImmediate(resolve)); },
  };
}

test("public command replies retain embeds and components through their cooldown", async (t) => {
  const { progress, calls, tick, clear, timer } = mockProgress(t);
  const payload = { embeds: [{ title: "Result" }], components: [{ type: 1 }] };
  let finished = false;
  const result = progress.interaction.reply(payload).then(() => { finished = true; });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(calls[0][1].content, "⏳");
  assert.equal(calls[0][1].ephemeral, false);
  await tick();
  await tick();
  assert.equal(finished, false);
  await tick();
  await result;
  assert.deepEqual(calls.slice(1, 4).map((call) => call[1].content), ["⏳.", "⏳..", "⏳..."]);
  assert.deepEqual(calls.at(-1)[1], { ...payload, content: null });
  assert.equal(clear.mock.calls[0].arguments[0], timer);
  assert.equal(progress.pendingResponse, false);
});

test("private command replies stay private, including ephemeral flag replies", async (t) => {
  const { progress, calls, tick } = mockProgress(t);
  const result = progress.interaction.reply({ content: "Private", flags: MessageFlags.Ephemeral });
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(calls[0][1].ephemeral, true);
  await tick();
  await tick();
  await tick();
  await result;
  assert.equal(calls.at(-1)[1].content, "Private");
  assert.equal(calls.at(-1)[1].flags, undefined);
});

test("deferred commands start work while the hourglass runs and retain later edits", async (t) => {
  const { progress, calls, tick, clear } = mockProgress(t);
  await progress.interaction.deferReply({ ephemeral: true });
  assert.equal(calls[0][1].ephemeral, true);
  assert.equal(calls[1][1].content, "⏳");
  let finished = false;
  const first = progress.interaction.editReply({ embeds: [{ title: "First frame" }] }).then(() => { finished = true; });
  await tick();
  await tick();
  assert.equal(finished, false);
  await tick();
  await first;
  await progress.interaction.editReply({ content: "Second frame" });
  assert.equal(calls.at(-2)[1].content, null);
  assert.equal(calls.at(-2)[1].embeds[0].title, "First frame");
  assert.equal(calls.at(-1)[1].content, "Second frame");
  assert.equal(clear.mock.callCount(), 1);
});

test("the slots animation still takes five seconds after the first frame", async (t) => {
  let now = 0;
  t.mock.method(Date, "now", () => now);
  t.mock.method(globalThis, "setTimeout", (callback, delay) => {
    now += delay;
    queueMicrotask(callback);
    return {};
  });
  const frames = [];
  const command = createSlotsCommand(async () => ({
    reels: ["🍒", "🍒", "🍒", "🍒"], won: false, wager: 1, balance: 99, rtpTargetPercent: 95,
  }));
  await command.execute({
    guildId: "guild",
    user: { id: "user" },
    options: { getInteger: () => 1, getString: () => null },
    deferReply: async () => {},
    editReply: async () => {
      if (!frames.length) now = 3_000;
      frames.push(now);
    },
  });
  assert.deepEqual(frames, [3_000, 4_250, 5_500, 6_750, 8_000]);
});

test("failed deferred commands stop their progress timer and leave an editable response", async (t) => {
  const { progress, calls, clear } = mockProgress(t);
  await progress.interaction.deferReply({ ephemeral: true });
  assert.equal(progress.pendingResponse, true);
  await progress.stop();
  assert.equal(clear.mock.callCount(), 1);
  await progress.interaction.editReply({ content: "Command failed" });
  assert.equal(calls.at(-1)[1].content, "Command failed");
  assert.equal(progress.pendingResponse, false);
});

test("the command dispatcher blocks a second command while preserving the first response", async (t) => {
  const { original, calls, tick } = mockProgress(t);
  original.user = { id: "same-user" };
  const cooldown = createCommandCooldown();
  const first = runCommand(original, { execute: async (interaction) => interaction.reply("First") }, cooldown);
  await new Promise((resolve) => setImmediate(resolve));
  const denied = [];
  let executed = false;
  await runCommand(
    { user: original.user, commandName: "other", reply: async (payload) => denied.push(payload) },
    { execute: async () => { executed = true; } },
    cooldown
  );
  assert.equal(executed, false);
  assert.equal(denied[0].ephemeral, true);
  assert.match(denied[0].content, /still running/);
  await tick();
  await first;
  assert.equal(calls.at(-1)[1].content, "First");
});

test("the command dispatcher reports failures and releases its in-flight lock", async (t) => {
  const { original, calls, clear } = mockProgress(t);
  original.user = { id: "user" };
  const cooldown = createCommandCooldown();
  t.mock.method(console, "error", () => {});
  await runCommand(original, {
    execute: async (interaction) => {
      await interaction.deferReply({ ephemeral: true });
      throw new Error("failed");
    },
  }, cooldown);
  assert.match(calls.at(-1)[1].content, /command failed/i);
  assert.equal(clear.mock.callCount(), 1);
  const next = cooldown.claim("user");
  assert.equal(next.error, undefined);
  next.release();
});

test("overlapping slash and custom commands share an adaptive cooldown, but help bypasses it", async (t) => {
  const timers = [];
  t.mock.method(globalThis, "setInterval", (callback, delay) => {
    assert.equal(delay, 1_000);
    timers.push(callback);
    return timers.length;
  });
  t.mock.method(globalThis, "clearInterval", () => {});
  const cooldown = createCommandCooldown();
  const responses = [];
  const interaction = (id, commandName, guildId = "guild") => ({
    user: { id }, commandName, guildId,
    reply: async (payload) => responses.push([id, "reply", payload]),
    deferReply: async () => {},
    editReply: async (payload) => responses.push([id, "edit", payload]),
  });
  let finished = 0;
  const first = runCommand(interaction("one", "ping"), {
    execute: (command) => command.reply("First"),
  }, cooldown).then(() => { finished++; });
  const customAdmission = cooldown.claim("two", "guild");
  const customUpdates = [];
  const custom = withCommandThinking(async () => "Custom", async (content) => customUpdates.push(content), customAdmission, "!test")
    .finally(() => customAdmission.release()).then(() => { finished++; });
  const third = runCommand(interaction("three", "ping"), {
    execute: (command) => command.reply("Third"),
  }, cooldown).then(() => { finished++; });
  const help = interaction("one", "help");
  await runCommand(help, { execute: (command) => command.reply("Help") }, cooldown);
  assert.deepEqual(responses.find(([id, , payload]) => id === "one" && payload === "Help"), ["one", "reply", "Help"]);
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(timers.length, 3);
  for (let tick = 0; tick < 2; tick++) {
    for (const callback of timers) callback();
    await new Promise((resolve) => setImmediate(resolve));
    assert.equal(finished, 0);
  }
  for (const callback of timers) callback();
  await Promise.all([first, custom, third]);
  assert.deepEqual(customUpdates, ["⏳", "⏳.", "⏳..", "⏳..."]);
  assert.equal(responses.find(([id, kind, payload]) => id === "one" && kind === "edit" && payload.content === "First")[2].content, "First");
  assert.equal(finished, 3);
});

test("the hourglass stops at eight seconds even with more concurrent requests", async (t) => {
  let tick;
  t.mock.method(globalThis, "setInterval", (callback) => { tick = callback; return 42; });
  const clear = t.mock.method(globalThis, "clearInterval", () => {});
  const cooldown = createCommandCooldown();
  const admissions = Array.from({ length: 10 }, (_, index) => cooldown.claim(`user-${index}`, "guild"));
  const updates = [];
  let finished = false;
  const pending = withCommandThinking(async () => "done", async (content) => updates.push(content), admissions[0], "!test")
    .then(() => { finished = true; });
  await new Promise((resolve) => setImmediate(resolve));
  for (let index = 0; index < 7; index++) {
    tick();
    await new Promise((resolve) => setImmediate(resolve));
    assert.equal(finished, false);
  }
  tick();
  await pending;
  assert.equal(updates.at(-1), "⏳........");
  assert.equal(updates.length, 9);
  assert.equal(clear.mock.callCount(), 1);
  for (const admission of admissions) admission.release();
});

test("an overlapping request extends a command whose work is still running", async (t) => {
  let tick;
  t.mock.method(globalThis, "setInterval", (callback) => { tick = callback; return 42; });
  t.mock.method(globalThis, "clearInterval", () => {});
  const cooldown = createCommandCooldown();
  const first = cooldown.claim("one", "guild");
  let resolveWork;
  const work = new Promise((resolve) => { resolveWork = resolve; });
  let finished = false;
  const pending = withCommandThinking(() => work, async () => {}, first, "!test")
    .then(() => { finished = true; });
  await new Promise((resolve) => setImmediate(resolve));
  tick();
  await new Promise((resolve) => setImmediate(resolve));
  const second = cooldown.claim("two", "guild");
  resolveWork("done");
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(finished, false);
  tick();
  await pending;
  assert.equal(finished, true);
  first.release();
  second.release();
});
