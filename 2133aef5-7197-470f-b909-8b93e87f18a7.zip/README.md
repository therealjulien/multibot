# Multibot

An all-in-one discord.js bot with moderation, games, a virtual economy, and community tools.

## Requirements

- Node.js 20 or newer
- A Discord application and bot, created in the [Discord Developer Portal](https://discord.com/developers/applications)

## Setup

1. Copy `.env.example` to `.env`.
2. Set `DISCORD_TOKEN` to the bot token and `CLIENT_ID` to the application ID. Set `BOT_OWNER_ID` to your Discord user ID to enable the owner-only commands. Set `GROQ_API_KEY` to a GroqCloud API key for AI responses; optionally set `GROQ_MODEL` to a model available to your GroqCloud account (defaults to `openai/gpt-oss-20b`). On this MC-Node deployment, hosted-server restart uses `https://panel.mc-node.net` and server ID `9d912719` by default; set `PANEL_API_KEY` to a panel client API key with server power permission. Override `PANEL_API_URL` or `PANEL_SERVER_ID` only if the panel or server changes. Commands are registered globally.
3. Install dependencies with `npm install`.
4. Register slash commands with `npm run deploy`.
5. Start the bot with `npm start`.

Invite the bot to each server with the `bot` and `applications.commands` scopes. Grant only the permissions it needs: **Kick Members**, **Ban Members**, **Moderate Members**, **Manage Messages**, **Manage Channels**, **Manage Roles**, **View Channels**, **Read Message History**, **Send Messages**, **Embed Links**, and **Add Reactions**. The bot's role must be above the roles of members it moderates and assigns. Run `npm run deploy` to register commands globally and remove any older per-server command registrations from every server the bot has joined, preventing duplicate command suggestions. Global commands then become available in every server the bot has joined (subject to each bot invite having the `applications.commands` scope). Discord may take a little time to propagate global command updates.

For message-based levels and accurate leaderboards, enable the **Server Members Intent** in the Discord Developer Portal's Bot settings. Enable the privileged **Message Content Intent** for AI chat channels, automod, custom commands, message-based XP, and message-content audit logs. Invite tracking also needs the bot's **Manage Server** permission and the Guild Invites gateway intent.

## Commands

For `/warn`, `/purge`, `/ai-channel` link, `/giveaway start`, `/embed`, `/embed-edit`, `/poll`, `/suggest`, `/reaction-role add|post`, `/sticky set|clear`, and `/tickets panel`, omit `[channel]` to use the current channel. When choosing another channel, you must be able to view it and have the permissions needed for the action there; the bot also needs its corresponding channel permissions. Selectable targets are text or announcement channels, except AI linking, which uses a regular text channel.

### Moderation

- `/kick user reason` — remove a member from the server.
- `/ban user reason` — ban a member from the server.
- `/warn user reason [channel]` — post a warning and DM the member. Requires **Moderate Members**; if DMs are closed, the server warning is still posted and the command reports that the DM could not be delivered.
- `/hackban user_id reason` — ban by Discord user ID, including users who have not joined. If the user is in the server, normal role hierarchy checks apply.
- `/timeout user minutes reason` — timeout a member for 1 minute to 28 days. Requires **Moderate Members**.
- `/modlog user [limit]` — view recent bot-issued moderation cases privately.
- `/logs setup` — requires **Manage Server**. Select a private text channel from the menu to enable modlogs. Use **Use Full** for additional Discord audit entries, and **Disable modlogs** / **Enable modlogs** to toggle the module without losing the channel or mode. Full mode requires **View Audit Log** for both you and the bot. The bot also needs **View Channel**, **Send Messages**, and **Embed Links** in the selected channel.
- `/logs channel|mode|disable|status` — the original direct commands remain available. `/logs disable` now saves the channel and mode for later re-enabling via `/logs setup`. Modlogs cover moderation cases, joins/leaves, nickname/member-role/timeout changes, bans, message edits/deletes, emoji and role creation/updates/deletion, channel creation/updates/deletion (including permission overwrite changes), and selected server-setting changes. Full mode adds Discord audit events with available moderator, target, reason, and change details; some actions may appear twice. Logs can include content from private channels, so restrict access to the log channel. Uncached message content may be unavailable, sensitive audit values are redacted, large changes may be truncated, and events while the bot is offline are not recorded. Saved moderation cases remain available through `/modlog` even when the logging module is disabled.
- `/purge amount [channel]` — delete 1–100 recent channel messages. Discord skips messages older than 14 days.

Discord's default command permissions restrict these to members with the corresponding moderation permissions. The bot also checks role hierarchy before kick, ban, and timeout actions.

### Games

- `/8ball question` — ask the suspiciously confident magic 8-ball.
- `/coinflip` — free coin flip.
- `/rps choice` — play rock-paper-scissors against the bot.
- `/wyr` and `/truth-or-dare pick` — get a silly prompt.
- `/trivia answer` and `/emoji-quiz answer` — answer quick multiple-choice quizzes.
- `/number-guess guess` — try to guess the bot's number from 1 to 10.
- `/riddle` — solve a short riddle (the answer is spoiler-hidden).

### AI

- `/ai prompt` — ask the AI a question; the answer is public and mentions the requester. Discord's application-command permissions control who can use it.
- `/ai-channel action [channel]` — requires **Manage Server**. Admins can create and link a new `#ai-chat` channel (the user and bot also need **Manage Channels**), link a selected text channel, unlink the AI channel without deleting the Discord channel, or enable/disable AI for the server. The channel option is only used with the link action.
- In the linked AI channel, ordinary text messages receive public AI replies that mention the requester, and the bot shows a typing indicator while generating them. Prompts are limited to 1,500 characters and each user has a 5-second AI cooldown. Up to six recent exchanges are kept in memory per channel. Conversation history is not persisted and is cleared when AI is disabled or the channel is unlinked.

AI answers use Discord-friendly paragraphs and lists; Markdown tables and HTML line breaks are converted for readability.

Slash commands and configured `!` custom commands (except help) show `⏳`, adding one dot per second before the response replaces it. The minimum delay is based on the peak number of simultaneous command users in that server: one second for one user, two for two, and so on, capped at eight seconds. Requests in other servers are counted separately. A user must wait for their previous command to finish, but other users can still use the bot. Help and menu buttons are not subject to this cooldown; private command replies remain private.

Each server can run up to two AI prompts at once, shared between `/ai` and AI-channel messages. Additional prompts receive a busy message and can be retried when a slot is free. `/ai` uses the server's command cooldown; ordinary messages in an AI channel retain their separate five- or ten-second hourglass depending on AI load. Slow AI-channel requests continue after ten seconds with a waiting message instead of the hourglass. AI requests also have a separate five-second per-user cooldown, shared by `/ai` and AI-channel messages within a server.

The bot also attempts to show a channel typing indicator while processing slash and configured custom commands. Typing indicators are visible in the channel even when a command's response is private, may not appear for very fast commands, and do not prevent commands from working if unavailable.

AI requests and messages in linked AI channels are sent to GroqCloud using the configured model. Keep `GROQ_API_KEY` private. Do not send secrets or sensitive personal information.

Voice AI is deferred for the current 128 MB bot host. The linked Dansday project includes a larger web-and-bot platform; this lightweight implementation does not import its SvelteKit, MySQL, or Redis stack.

### Multicoins

- `/balance` — publicly check your server-specific multicoins balance (new players start with 100).
- `/daily` — publicly collect 50 multicoins once per UTC day.
- `/slots bet [machine]` — play a public, animated four-reel slot machine. Choose Classic, Treasure Hunt, Galaxy Quest, or Candy Rush; the three themed machines each have a bonus round. Bets are limited to 1–1,000 multicoins, require a sufficient balance, and have a five-second per-user cooldown.
- `/gamble game wager` — choose coin flip (wins on heads), dice (wins on 4–6), automatic blackjack, or roulette (automatically bets red).

Slot reels use independent weighted rolls, with themed symbols, WILDs, and distinct paytables on each machine. Three matching regular symbols pay the symbol's multiplier; four pay twice that amount. Three bonus icons trigger a bonus round that reveals a random multiplier, and four bonus icons double that bonus prize. WILDs substitute for regular symbols, not bonus icons. Each spin randomly selects an integer RTP target from 85% to 98% and scales the selected machine's paytable and bonus prizes to that target. The target is shown in the result embed; integer coin rounding can make the realized return approximate the target. Reels stop one at a time over five seconds. The bet is deducted before the roll and any payout is credited atomically with the balance update.

Gamble results are public embeds. `/gamble` wagers are limited to 1–1,000 multicoins and cannot exceed your balance. Blackjack automatically hits below 17 and pays 3:2 for a natural blackjack (rounded down for odd wagers). Roulette uses a single-zero wheel and automatically bets on red, paying 2×.

Multicoins are fictional, have no cash value, and cannot be purchased or redeemed for real-world prizes. Balances are stored locally in `data/economy.json`; back up that file if you want to preserve the economy.

### Levels

- Members earn 15–25 XP from one message per minute and receive a channel announcement when they level up.
- `/level user` — check your level or another member's level.
- `/leaderboard` — show the top 10 current server members. Departed members are removed on leave and stale records are pruned from the leaderboard.
- `/level-reward set|remove|list` — configure milestone roles; members keep the highest reached reward role.
- `/sync-check` — privately verify that the running bot has loaded the SFTP sync-check build marker and view its process start time.
- `/level-reset user` — reset a member's XP and level; requires **Administrator**.

Level data is stored locally in `data/levels.json`.

### Information and diagnostics

- `/version` — show only the current bot version.
- `/ping` — show interaction response time and Discord gateway latency.
- `/uptime` — show the current process uptime and start time.

### Versioning

The displayed bot version is `0.2611a`. A separate reboot counter increments on each process start up to `9999`, but is not included in the displayed version. The counter is persisted in `data/version.json`; keep `data` excluded from SFTP uploads so it survives code syncs.

### Bot presence

- `/bot-presence status [text] [server_count]` — set online, idle, Do Not Disturb, or invisible. Optional text is shown as “Playing”; enabling `server_count` instead shows “Watching … people in … servers”, with the optional text preceding the counts. People are the sum of server member counts (including bots and members in multiple servers), not unique users; counts of 1,000 or more are rounded to the nearest hundred and shown in thousands. Counts refresh on server and member changes and periodically; unavailable server counts are omitted with a warning in the bot logs. Omit text and leave server count off to clear the activity. Text may be shortened to fit Discord's activity limit. The setting persists in `data/presence.json`. Only the Discord user ID in `BOT_OWNER_ID` can use it.
- `/bot-maintenance action` — owner-only actions for deploying slash commands (`npm run deploy`), running `npm restart`, or directly requesting a hosted-server restart. Both restart choices use the panel API; keep the panel API key private and grant it only the required power permission.

Owner commands can only be run by the configured bot owner, but successful responses are public. Maintenance output and error details are not posted publicly; check the bot logs for failures.

### Community tools

- `/help` or explicitly @mention the bot — open a public interactive embed. Its dropdown lists the registered commands by category, with subcommands shown underneath; support and bot-invite links remain available in every category. The person who opened it can use **Cancel** to remove the menu. An explicit mention opens help instead of triggering an AI reply; replying without an explicit mention does not open help.
- `/welcome setup channel message [role]` — post a welcome message when a member joins. Message placeholders are `{user}`, `{server}`, and `{memberCount}`. An optional role is assigned to new members.
- `/welcome edit message` — update the welcome text without changing its channel or automatic role.
- `/welcome role [role]` — set the automatic role; omit the role to clear it.
- `/welcome disable` — turn off both welcome messages and automatic role assignment.
- `/giveaway start prize duration_hours winners [channel]` — create a public giveaway with an entry button. Giveaways run for 1–168 hours, support 1–10 winners, persist across restarts, and end automatically.
- `/giveaway end message_id` — end an active giveaway early. Its message ID is shown in the giveaway embed.
- `/embed title message [color] [footer] [channel]` — post a formatted announcement; requires **Manage Messages**.
- `/embed-edit message_id [title] [message] [color] [footer] [channel]` — update selected fields of one of the bot's embeds in the chosen channel; requires **Manage Messages**.
- `/poll question option1 option2 [option3] [option4] [option5] [channel]` — create a reaction-vote poll with 2–5 choices. The bot needs **Send Messages**, **Embed Links**, and **Add Reactions**.
- `/suggest idea [channel]` — post a community suggestion with 👍/👎 voting.
- `/server-info` and `/user-info [user]` — display server and member details.
- `/channel-info [channel]` and `/role-info role` — inspect a channel or role. These original Multibot commands were inspired by the guild-information category in [ALL-IN-ONE Discord Bot](https://github.com/Uo1428/ALL-IN-ONE-Discord-Bot-).

### Added community features

- `/afk [reason]` — mark yourself AFK; use it again without a reason to clear the status. Mentions receive an AFK notice.
- `/birthday set|remove|list` — save or view month-and-day birthdays. `/birthday channel [channel]` is Manage Server-only and sends one UTC daily announcement to the configured channel.
- `/profile set|show|clear` — store a short bio scoped to the current server.
- `/thanks give|top` — give a member a thank-you, with a one-minute per-user cooldown, or show the leaderboard.
- `/invites [user]` — show invite joins tracked since the bot started observing invite use. Invite attribution is best-effort and requires Manage Server permission; existing invite counts aren't retroactively available.
- `/custom-command add|edit|remove|list` — Manage Server-only `!name` responses. Up to 25 commands per server; `{user}`, `{server}`, `{channel}`, `{memberCount}`, and `{args}` placeholders are supported, and mentions from stored responses are suppressed.
- `/announcement post title message [channel]` — send a formatted announcement; requires Manage Messages.

### Server setup and tools

- `/automod enable|disable|links|word-add|word-remove|status` — configure removal of Discord invite links and up to 50 blocked words/phrases. Configure carefully; matching messages are deleted.
- `/autosetup preview|create` — create a `Multibot Community` category and missing `announcements`, `suggestions`, and `support` channels without changing existing channels.
- `/server-builder` — requires **Manage Channels**; use the category buttons (or Select all/Clear) to choose any combination of Gaming Server, Community Server, Tech Server, and Hangout Server, review the preview, and confirm creation. Each selected category adds 10 text channels and a `General` voice channel. Categories include the current server name. Existing matching categories and channels are reused, and other existing channels are never removed; a failed build reports partial progress and can be retried.
- `/messages send|lock|unlock` — send a non-pinging bot message or manage `@everyone` write access.
- `/reaction-role add message_id emoji role [channel]` — requires **Manage Roles**; add multiple emoji/role pairs by repeating the command for a message in the chosen channel. Members gain the role on reacting and lose it on removing their reaction. Changes made while the bot is offline are not synchronized, and existing reactions are not applied retroactively. Roles must be below both the bot's and the configurator's highest roles (server owners are exempt from the latter) and cannot have moderation or server-management permissions. The bot needs access to the message, **Read Message History**, **Add Reactions**, and **Manage Roles**. Use a Unicode emoji or a custom emoji the bot can use.
- `/reaction-role remove message_id [emoji]` — disable one emoji mapping, or omit the emoji to disable all mappings and any legacy button panel on that message. Existing member roles and reactions are not removed.
- `/reaction-role post role [label] [channel]` — post the existing single-role toggle button.
- `/sticky set message [channel]` and `/sticky clear [channel]` — repost one configured message at the bottom of the selected channel whenever a new message arrives, or clear it.
- `/tickets setup staff_role` and `/tickets panel [channel]` — configure a staff role and post a button for private tickets. Ticket owners and staff can close tickets with the ticket button.
- `/server-stats` — show member, channel, role, boost, and creation statistics.
- `/tools avatar|choose|timestamp` — show an avatar, choose from a list, or format a timezone-aware ISO date/time.

### Project structure and data

Slash commands are grouped under `src/commands/` by domain and combined through a central registry. Event handlers and feature-specific persistence live under `src/features/`; `src/index.js` wires them to the Discord client. The original commands remain in `src/commands/legacy.js`.

Community data is stored in `data/community.json`; the new features use `data/features.json`. Keep the entire `data` directory excluded from SFTP code uploads so birthdays, profiles, custom commands, moderation cases, audit-log settings, level rewards, tickets, sticky messages, and other settings survive syncs. These community feature adaptations were informed by [dansday-discord-bot](https://github.com/dansday-com/dansday-discord-bot) and [CorwinDev/Discord-Bot](https://github.com/CorwinDev/Discord-Bot); their source code was not copied into this lightweight bot.

The moderation, logging, role-reward, and custom-command feature set is informed by [YAGPDB](https://github.com/botlabs-gg/yagpdb), which is MIT-licensed. No YAGPDB source code was copied into this bot.
