import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";

export const releaseVersion = "0.2611a";
const rebootCounterPath = fileURLToPath(new URL("../data/version.json", import.meta.url));
let initializedVersionInfo;
let initializationPromise;

export function formatBotVersion(rebootCount) {
  if (!Number.isSafeInteger(rebootCount) || rebootCount < 0 || rebootCount > 9999) {
    throw new RangeError("The reboot count must be an integer between 0 and 9999.");
  }
  return releaseVersion;
}

export async function incrementRebootCounter(filePath = rebootCounterPath) {
  let rebootCount = 0;
  try {
    const savedState = JSON.parse(await readFile(filePath, "utf8"));
    if (
      !savedState ||
      typeof savedState !== "object" ||
      !Number.isSafeInteger(savedState.rebootCount) ||
      savedState.rebootCount < 0 ||
      savedState.rebootCount > 9999
    ) {
      throw new Error("The saved reboot counter must contain an integer from 0 to 9999.");
    }
    rebootCount = savedState.rebootCount;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }

  const nextCount = Math.min(rebootCount + 1, 9999);
  await mkdir(dirname(filePath), { recursive: true });
  const temporaryPath = `${filePath}.${process.pid}.tmp`;
  await writeFile(temporaryPath, `${JSON.stringify({ rebootCount: nextCount }, null, 2)}\n`, "utf8");
  await rename(temporaryPath, filePath);
  return nextCount;
}

export function initializeBotVersion() {
  if (!initializationPromise) {
    initializationPromise = incrementRebootCounter()
      .then((rebootCount) => {
        const [major, minor, patch] = releaseVersion.split(".").map(Number);
        initializedVersionInfo = Object.freeze({
          major,
          minor,
          patch,
          rebootCount,
          version: formatBotVersion(rebootCount),
        });
        return initializedVersionInfo;
      })
      .catch((error) => {
        initializationPromise = undefined;
        throw error;
      });
  }
  return initializationPromise;
}

export function getBotVersionInfo() {
  if (!initializedVersionInfo) {
    throw new Error("The bot version has not been initialized.");
  }
  return initializedVersionInfo;
}
