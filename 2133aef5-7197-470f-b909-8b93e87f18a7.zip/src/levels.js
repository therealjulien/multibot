import { randomInt } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const levelsPath = fileURLToPath(new URL("../data/levels.json", import.meta.url));
const xpCooldownMs = 60_000;
const xpCooldowns = new Map();
let queue = Promise.resolve();

async function updateLevels(update) {
  const task = queue.then(async () => {
    let levels;
    try {
      levels = JSON.parse(await readFile(levelsPath, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      levels = {};
    }

    const result = update(levels);
    await mkdir(new URL("../data/", import.meta.url), { recursive: true });
    const temporaryPath = `${levelsPath}.${process.pid}.tmp`;
    await writeFile(temporaryPath, `${JSON.stringify(levels, null, 2)}\n`, "utf8");
    await rename(temporaryPath, levelsPath);
    return result;
  });

  queue = task.catch(() => {});
  return task;
}

export function getLevelProgress(totalXp) {
  let level = 0;
  let currentXp = totalXp;
  let nextLevelXp = 100;

  while (currentXp >= nextLevelXp) {
    currentXp -= nextLevelXp;
    level += 1;
    nextLevelXp = (level + 1) * 100;
  }

  return { level, currentXp, nextLevelXp, totalXp };
}

export function awardMessageXp(guildId, userId) {
  const key = `${guildId}:${userId}`;
  const now = Date.now();
  if (xpCooldowns.size > 10_000) {
    for (const [cooldownKey, timestamp] of xpCooldowns) {
      if (now - timestamp >= xpCooldownMs) xpCooldowns.delete(cooldownKey);
    }
  }
  const lastAward = xpCooldowns.get(key) ?? 0;
  if (now - lastAward < xpCooldownMs) return Promise.resolve(null);
  xpCooldowns.set(key, now);

  return updateLevels((levels) => {
    levels[guildId] ??= {};
    const account = levels[guildId][userId] ??= { xp: 0 };
    const previousLevel = getLevelProgress(account.xp).level;
    account.xp += randomInt(15, 26);
    const progress = getLevelProgress(account.xp);

    return {
      ...progress,
      leveledUp: progress.level > previousLevel,
    };
  }).catch((error) => {
    if (xpCooldowns.get(key) === now) xpCooldowns.delete(key);
    throw error;
  });
}

export function getUserLevel(guildId, userId) {
  return updateLevels((levels) => getLevelProgress(levels[guildId]?.[userId]?.xp ?? 0));
}

export function getLeaderboard(guildId, activeUserIds, limit = 10) {
  const activeUsers = new Set(activeUserIds);
  return updateLevels((levels) => {
    const guildLevels = levels[guildId] ?? {};
    for (const userId of Object.keys(guildLevels)) {
      if (!activeUsers.has(userId)) delete guildLevels[userId];
    }
    levels[guildId] = guildLevels;

    return Object.entries(guildLevels)
      .map(([userId, account]) => ({
        userId,
        ...getLevelProgress(account.xp),
      }))
      .sort((left, right) => right.totalXp - left.totalXp)
      .slice(0, limit);
  });
}

export function resetUserLevel(guildId, userId) {
  return updateLevels((levels) => {
    if (levels[guildId]) delete levels[guildId][userId];
  });
}

export function removeMemberLevel(guildId, userId) {
  return updateLevels((levels) => {
    if (levels[guildId]) delete levels[guildId][userId];
  });
}
