import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} from "discord.js";
import {
  completeGiveaway,
  getDueGiveaways,
  getGiveaway,
  joinGiveaway,
  prepareGiveawayEnd,
} from "./community.js";

const giveawayButtonPrefix = "multibot:giveaway:enter:";

export function createGiveawayEmbed(giveaway, ended = false) {
  const embed = new EmbedBuilder()
    .setColor(ended ? 0x95a5a6 : 0x5865f2)
    .setTitle(ended ? "🎉 Giveaway ended" : "🎉 Giveaway")
    .setDescription(`**Prize**\n${giveaway.prize}`)
    .addFields(
      { name: "Winners", value: String(giveaway.winnerCount), inline: true },
      { name: "Entries", value: String(giveaway.entrants.length), inline: true },
      {
        name: ended ? "Ended" : "Ends",
        value: ended
          ? `<t:${Math.floor(giveaway.endedAt / 1000)}:F>`
          : `<t:${Math.floor(giveaway.endsAt / 1000)}:R>`,
        inline: true,
      }
    )
    .setFooter({ text: `Giveaway message ID: ${giveaway.messageId}` });

  if (ended) {
    embed.addFields({
      name: giveaway.winnerIds.length ? "Winner(s)" : "Result",
      value: giveaway.winnerIds.length
        ? giveaway.winnerIds.map((id) => `<@${id}>`).join(", ")
        : "No one entered this giveaway.",
    });
  }
  return embed;
}

export function createGiveawayComponents(messageId, disabled = false) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`${giveawayButtonPrefix}${messageId}`)
        .setLabel("Enter Giveaway 🎉")
        .setStyle(ButtonStyle.Primary)
        .setDisabled(disabled)
    ),
  ];
}

export async function handleGiveawayButton(interaction) {
  if (!interaction.isButton() || !interaction.customId.startsWith(giveawayButtonPrefix)) return false;

  const messageId = interaction.customId.slice(giveawayButtonPrefix.length);
  if (messageId !== interaction.message.id) {
    await interaction.reply({ content: "This giveaway button is invalid.", ephemeral: true });
    return true;
  }

  const result = await joinGiveaway(messageId, interaction.user.id);
  if (result.status === "not_found") {
    await interaction.reply({ content: "This giveaway is no longer available.", ephemeral: true });
  } else if (result.status === "closed") {
    await interaction.reply({ content: "This giveaway has ended.", ephemeral: true });
  } else if (result.status === "already_entered") {
    await interaction.reply({ content: "You're already entered in this giveaway.", ephemeral: true });
  } else {
    await interaction.reply({ content: "✅ You're entered in the giveaway!", ephemeral: true });
    try {
      const latestGiveaway = await getGiveaway(messageId);
      if (!latestGiveaway || latestGiveaway.status !== "active") return true;
      await interaction.message.edit({
        embeds: [createGiveawayEmbed(latestGiveaway)],
        components: createGiveawayComponents(messageId),
      });
    } catch (error) {
      console.error(`Could not update entry count for giveaway ${messageId}:`, error);
    }
  }
  return true;
}

export async function endGiveaway(client, messageId, options = {}) {
  const giveaway = await prepareGiveawayEnd(messageId, options);
  if (!giveaway) return { status: "not_found_or_not_due" };
  if (giveaway.status === "ended") return { status: "ended", giveaway, alreadyEnded: true };

  const channel = await client.channels.fetch(giveaway.channelId);
  if (!channel || !channel.isTextBased() || !("messages" in channel)) {
    throw new Error(`Giveaway channel ${giveaway.channelId} is unavailable.`);
  }
  const message = await channel.messages.fetch(giveaway.messageId);
  await message.edit({
    content: giveaway.winnerIds.length
      ? `🎉 Giveaway ended! Winner(s): ${giveaway.winnerIds.map((id) => `<@${id}>`).join(", ")}`
      : "🎉 Giveaway ended! No one entered.",
    embeds: [createGiveawayEmbed(giveaway, true)],
    components: createGiveawayComponents(giveaway.messageId, true),
    allowedMentions: { parse: [], users: giveaway.winnerIds },
  });

  const completedGiveaway = await completeGiveaway(messageId);
  return { status: "ended", giveaway: completedGiveaway ?? giveaway, alreadyEnded: false };
}

export function scheduleGiveawayChecks(client) {
  let checking = false;
  const checkDueGiveaways = async () => {
    const dueGiveaways = await getDueGiveaways();
    for (const giveaway of dueGiveaways) {
      try {
        await endGiveaway(client, giveaway.messageId);
      } catch (error) {
        console.error(`Could not end giveaway ${giveaway.messageId}; it will be retried:`, error);
      }
    }
  };

  const runCheck = () => {
    if (checking) return;
    checking = true;
    checkDueGiveaways().catch((error) => {
      console.error("Could not check for due giveaways:", error);
    }).finally(() => {
      checking = false;
    });
  };

  runCheck();
  const timer = setInterval(runCheck, 30_000);
  timer.unref();
  return timer;
}
