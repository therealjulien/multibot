import "dotenv/config";
import { requestServerRestart } from "./server-control.js";

try {
  await requestServerRestart();
  console.log("The panel accepted the server restart request.");
} catch (error) {
  console.error("Could not request a server restart:", error.message);
  process.exitCode = 1;
}
