import { randomInt } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";

const communityPath = fileURLToPath(new URL("../data/community.json", import.meta.url));

export function createCommunityStore(filePath = communityPath) {
  let queue = Promise.resolve();

  async function updateCommunity(update) {
    const task = queue.then(async () => {
      let community;
      try {
        community = JSON.parse(await readFile(filePath, "utf8"));
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
        community = { guilds: {}, giveaways: {} };
      }

      if (!community || typeof community !== "object" || Array.isArray(community)) {
        throw new Error("Community data must be a JSON object.");
      }
      community.guilds ??= {};
      community.giveaways ??= {};
      if (
        typeof community.guilds !== "object" || Array.isArray(community.guilds) ||
        typeof community.giveaways !== "object" || Array.isArray(community.giveaways)
      ) {
        throw new Error("Community data must contain guild and giveaway objects.");
      }

      const result = update(community);
      await mkdir(dirname(filePath), { recursive: true });
      const temporaryPath = `${filePath}.${process.pid}.tmp`;
      await writeFile(temporaryPath, `${JSON.stringify(community, null, 2)}\n`, "utf8");
      await rename(temporaryPath, filePath);
      return result;
    });

    queue = task.catch(() => {});
    return task;
  }

  return {
    getGuildSettings(guildId) {
      return updateCommunity((community) => ({
        welcomeChannelId: community.guilds[guildId]?.welcomeChannelId ?? null,
        welcomeMessage: community.guilds[guildId]?.welcomeMessage ?? null,
        autoRoleId: community.guilds[guildId]?.autoRoleId ?? null,
      }));
    },

    setWelcomeSettings(guildId, channelId, message, roleId = undefined) {
      return updateCommunity((community) => {
        const settings = community.guilds[guildId] ??= {};
        settings.welcomeChannelId = channelId;
        settings.welcomeMessage = message;
        if (roleId !== undefined) settings.autoRoleId = roleId;
        return {
          welcomeChannelId: settings.welcomeChannelId,
          welcomeMessage: settings.welcomeMessage,
          autoRoleId: settings.autoRoleId ?? null,
        };
      });
    },

    updateWelcomeMessage(guildId, message) {
      return updateCommunity((community) => {
        const settings = community.guilds[guildId];
        if (!settings?.welcomeChannelId) return null;

        settings.welcomeMessage = message;
        return {
          welcomeChannelId: settings.welcomeChannelId,
          welcomeMessage: settings.welcomeMessage,
          autoRoleId: settings.autoRoleId ?? null,
        };
      });
    },

    setAutoRole(guildId, roleId) {
      return updateCommunity((community) => {
        const settings = community.guilds[guildId] ??= {};
        settings.autoRoleId = roleId;
        return settings.autoRoleId;
      });
    },

    disableWelcome(guildId) {
      return updateCommunity((community) => {
        const settings = community.guilds[guildId] ??= {};
        settings.welcomeChannelId = null;
        settings.welcomeMessage = null;
        settings.autoRoleId = null;
      });
    },

    createGiveaway(giveaway) {
      return updateCommunity((community) => {
        if (
          !giveaway.messageId ||
          !giveaway.guildId ||
          !giveaway.channelId ||
          !Number.isSafeInteger(giveaway.endsAt) ||
          !Number.isInteger(giveaway.winnerCount) ||
          giveaway.winnerCount < 1 ||
          typeof giveaway.prize !== "string"
        ) {
          throw new TypeError("Giveaway details are invalid.");
        }
        if (community.giveaways[giveaway.messageId]) {
          throw new Error(`Giveaway ${giveaway.messageId} already exists.`);
        }

        const saved = {
          ...giveaway,
          entrants: [],
          winnerIds: [],
          status: "active",
        };
        community.giveaways[giveaway.messageId] = saved;
        return structuredClone(saved);
      });
    },

    deleteGiveaway(messageId) {
      return updateCommunity((community) => {
        delete community.giveaways[messageId];
      });
    },

    getGiveaway(messageId) {
      return updateCommunity((community) => {
        const giveaway = community.giveaways[messageId];
        return giveaway ? structuredClone(giveaway) : null;
      });
    },

    getDueGiveaways(now = Date.now()) {
      return updateCommunity((community) =>
        Object.values(community.giveaways)
          .filter((giveaway) =>
            giveaway.status === "ending" ||
            (giveaway.status === "active" && giveaway.endsAt <= now)
          )
          .map((giveaway) => structuredClone(giveaway))
      );
    },

    joinGiveaway(messageId, userId, now = Date.now()) {
      return updateCommunity((community) => {
        const giveaway = community.giveaways[messageId];
        if (!giveaway) return { status: "not_found" };
        if (giveaway.status !== "active" || giveaway.endsAt <= now) {
          return { status: "closed", giveaway: structuredClone(giveaway) };
        }
        if (giveaway.entrants.includes(userId)) {
          return { status: "already_entered", giveaway: structuredClone(giveaway) };
        }

        giveaway.entrants.push(userId);
        return { status: "joined", giveaway: structuredClone(giveaway) };
      });
    },

    prepareGiveawayEnd(messageId, { now = Date.now(), force = false } = {}) {
      return updateCommunity((community) => {
        const giveaway = community.giveaways[messageId];
        if (!giveaway) return null;
        if (giveaway.status === "ended") return structuredClone(giveaway);
        if (giveaway.status === "active") {
          if (!force && giveaway.endsAt > now) return null;

          const entrants = [...giveaway.entrants];
          const winnerCount = Math.min(giveaway.winnerCount, entrants.length);
          const winners = [];
          for (let index = 0; index < winnerCount; index += 1) {
            const winnerIndex = randomInt(index, entrants.length);
            [entrants[index], entrants[winnerIndex]] = [entrants[winnerIndex], entrants[index]];
            winners.push(entrants[index]);
          }

          giveaway.status = "ending";
          giveaway.winnerIds = winners;
          giveaway.endedAt = now;
        }
        return structuredClone(giveaway);
      });
    },

    completeGiveaway(messageId) {
      return updateCommunity((community) => {
        const giveaway = community.giveaways[messageId];
        if (!giveaway) return null;
        if (giveaway.status === "ending") {
          giveaway.status = "ended";
          giveaway.endedAt ??= Date.now();
        }
        return structuredClone(giveaway);
      });
    },
  };
}

const communityStore = createCommunityStore();

export const getGuildCommunitySettings = communityStore.getGuildSettings;
export const setWelcomeSettings = communityStore.setWelcomeSettings;
export const updateWelcomeMessage = communityStore.updateWelcomeMessage;
export const setAutoRole = communityStore.setAutoRole;
export const disableWelcome = communityStore.disableWelcome;
export const createGiveaway = communityStore.createGiveaway;
export const deleteGiveaway = communityStore.deleteGiveaway;
export const getGiveaway = communityStore.getGiveaway;
export const getDueGiveaways = communityStore.getDueGiveaways;
export const joinGiveaway = communityStore.joinGiveaway;
export const prepareGiveawayEnd = communityStore.prepareGiveawayEnd;
export const completeGiveaway = communityStore.completeGiveaway;
