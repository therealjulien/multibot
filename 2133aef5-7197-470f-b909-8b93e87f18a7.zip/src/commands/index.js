import { commands as legacyCommands, configureHelpCommands, handleHelpCancel, handleHelpMention, handleHelpSelect, helpCancelCustomId, helpSelectCustomId } from "./legacy.js";
import { commands as communityCommands } from "./community.js";
import { commands as serverToolCommands } from "./server-tools.js";
import { commands as ownerCommands } from "./owner.js";

export const commands = [
  ...legacyCommands,
  ...communityCommands,
  ...serverToolCommands,
  ...ownerCommands,
];

const commandNames = new Set();
for (const command of commands) {
  const name = command.data.name;
  if (commandNames.has(name)) throw new Error(`Duplicate slash command registration: /${name}`);
  commandNames.add(name);
}

configureHelpCommands(commands);

export { handleHelpCancel, handleHelpMention, handleHelpSelect, helpCancelCustomId, helpSelectCustomId };
