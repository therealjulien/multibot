import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
} from "discord.js";
import {
  askAi,
  aiReplyOptions,
  getAiSettings,
  setAiChannel,
  setAiEnabled,
  unlinkAiChannel,
} from "../ai.js";
import { waitForCommandCooldown } from "../features/command-progress.js";
import {
  claimDaily,
  getBalance,
  placeBet,
  placeSlotBet,
  randomSlotSymbol,
  slotMachines,
  slotRtpMaxPercent,
  slotRtpMinPercent,
  slotReelCount,
} from "../economy.js";
import {
  createGiveaway,
  deleteGiveaway,
  disableWelcome,
  getGiveaway,
  getGuildCommunitySettings,
  setAutoRole,
  setWelcomeSettings,
  updateWelcomeMessage,
} from "../community.js";
import {
  createGiveawayComponents,
  createGiveawayEmbed,
  endGiveaway,
} from "../giveaways.js";
import { getLeaderboard, getUserLevel, resetUserLevel } from "../levels.js";
import { setBotPresence } from "../features/presence.js";
import {
  createModerationCase,
  getModerationCases,
  sendAuditLog,
} from "../features/moderation.js";
import { getBotVersionInfo } from "../version.js";
import { resolveTargetChannel, targetChannelOption } from "./channels.js";

const economyGuildId = (interaction) => {
  if (interaction.guildId) return interaction.guildId;
  throw new Error("The economy commands can only be used in a server.");
};

const reasonOption = (builder) =>
  builder
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Why this moderation action is being taken")
        .setMaxLength(400)
    );

const moderationTargetProblem = (interaction, target, actor) => {
  if (target.id === interaction.user.id) return "You can't moderate yourself.";
  if (target.id === interaction.guild.ownerId) return "The server owner can't be moderated by a bot.";

  const botMember = interaction.guild.members.me;
  if (
    actor.id !== interaction.guild.ownerId &&
    target.roles.highest.comparePositionTo(actor.roles.highest) >= 0
  ) {
    return "That member's highest role must be below your highest role.";
  }
  if (!botMember) return "I couldn't verify the bot's role hierarchy. Please try again.";
  if (target.roles.highest.comparePositionTo(botMember.roles.highest) >= 0) {
    return "That member's highest role must be below the bot's highest role.";
  }
  return null;
};

async function recordModerationAction(interaction, action, target, reason, durationMs = undefined) {
  let record;
  try {
    record = await createModerationCase(interaction.guild.id, {
      action,
      targetId: target.id,
      targetTag: target.user?.tag ?? target.tag ?? target.id,
      moderatorId: interaction.user.id,
      moderatorTag: interaction.user.tag,
      reason,
      durationMs,
    });
  } catch (error) {
    console.error(`Moderation action ${action} succeeded, but its case could not be saved:`, error);
    return { caseNumber: null, auditFailed: false };
  }

  let auditFailed = false;
  try {
    const embed = new EmbedBuilder()
      .setColor(action === "warn" ? 0xf1c40f : 0xed4245)
      .setTitle(`Case #${record.caseNumber} · ${action}`)
      .addFields(
        { name: "Target", value: `${record.targetTag} (<@${record.targetId}>)` },
        { name: "Moderator", value: `${record.moderatorTag} (<@${record.moderatorId}>)` },
        { name: "Reason", value: record.reason }
      )
      .setTimestamp(record.createdAt);
    if (durationMs) embed.addFields({ name: "Duration", value: `${Math.round(durationMs / 60_000)} minute(s)` });
    await sendAuditLog(interaction.guild, embed);
  } catch (error) {
    auditFailed = true;
    console.error(`Could not send moderation case #${record.caseNumber} to the audit channel:`, error);
  }

  return { caseNumber: record.caseNumber, auditFailed };
}

function moderationCaseNotice(result) {
  if (!result.caseNumber) return " The action succeeded, but its case could not be saved; check the bot logs.";
  if (result.auditFailed) return ` Case #${result.caseNumber} was saved, but its audit log could not be sent.`;
  return ` Case #${result.caseNumber}.`;
}

const memberOption = (builder) =>
  builder.addUserOption((option) =>
    option.setName("user").setDescription("The member to target").setRequired(true)
  );

const kick = {
  data: reasonOption(
    memberOption(
      new SlashCommandBuilder()
        .setName("kick")
        .setDescription("Remove a member from the server")
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    )
  ),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const user = interaction.options.getUser("user", true);
    const target = await interaction.guild.members.fetch(user.id);
    const actor = await interaction.guild.members.fetch(interaction.user.id);
    const problem = moderationTargetProblem(interaction, target, actor);
    if (problem) return interaction.editReply(problem);

    const reason = interaction.options.getString("reason") ?? `Kicked by ${interaction.user.tag}`;
    await target.kick(reason);
    const result = await recordModerationAction(interaction, "kick", target, reason);
    return interaction.editReply(`👢 ${user.tag} has been kicked.${moderationCaseNotice(result)}`);
  },
};

const ban = {
  data: reasonOption(
    memberOption(
      new SlashCommandBuilder()
        .setName("ban")
        .setDescription("Ban a member from the server")
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    )
  ),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const user = interaction.options.getUser("user", true);
    const target = await interaction.guild.members.fetch(user.id);
    const actor = await interaction.guild.members.fetch(interaction.user.id);
    const problem = moderationTargetProblem(interaction, target, actor);
    if (problem) return interaction.editReply(problem);

    const reason = interaction.options.getString("reason") ?? `Banned by ${interaction.user.tag}`;
    await target.ban({ reason });
    const result = await recordModerationAction(interaction, "ban", target, reason);
    return interaction.editReply(`🔨 ${user.tag} has been banned.${moderationCaseNotice(result)}`);
  },
};

const warn = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a server member publicly and by direct message")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((option) =>
      option.setName("user").setDescription("Member to warn").setRequired(true)
    )
    .addStringOption((option) =>
      option.setName("reason").setDescription("Reason for the warning").setRequired(true).setMaxLength(400)
    )
    .addChannelOption(targetChannelOption),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server channel where I can post.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    const destination = await resolveTargetChannel(interaction, {
      memberPermissions: [PermissionFlagsBits.ModerateMembers, PermissionFlagsBits.SendMessages],
      botPermissions: [PermissionFlagsBits.SendMessages],
    });
    if (destination.error) return interaction.editReply(destination.error);
    if (!destination.channel || !("send" in destination.channel)) {
      return interaction.editReply("Choose a channel where I can post.");
    }
    const user = interaction.options.getUser("user", true);
    const target = await interaction.guild.members.fetch(user.id);
    const actor = await interaction.guild.members.fetch(interaction.user.id);
    if (target.id === interaction.user.id) return interaction.editReply("You can't warn yourself.");
    if (target.id === interaction.guild.ownerId) return interaction.editReply("The server owner can't be warned.");
    if (
      actor.id !== interaction.guild.ownerId &&
      target.roles.highest.comparePositionTo(actor.roles.highest) >= 0
    ) {
      return interaction.editReply("That member's highest role must be below your highest role.");
    }

    const reason = interaction.options.getString("reason", true);
    await destination.channel.send({
      content: `⚠️ <@${user.id}> has received a moderator warning. **Reason:** ${reason}`,
      allowedMentions: { users: [user.id] },
    });

    const warningEmbed = new EmbedBuilder()
      .setColor(0xed4245)
      .setTitle(`Warning in ${interaction.guild.name}`)
      .setDescription(reason)
      .addFields({ name: "Moderator", value: interaction.user.tag });
    let dmDelivered = true;
    try {
      await user.send({ embeds: [warningEmbed] });
    } catch (error) {
      if (error.code !== 50007) throw error;
      dmDelivered = false;
    }

    const result = await recordModerationAction(interaction, "warn", user, reason);
    return interaction.editReply(
      `${dmDelivered
        ? `⚠️ Warning posted in this server and sent to ${user.tag} by DM.`
        : `⚠️ Warning posted in this server, but I couldn't DM ${user.tag}; they may have DMs disabled.`}${moderationCaseNotice(result)}`
    );
  },
};

const hackban = {
  data: new SlashCommandBuilder()
    .setName("hackban")
    .setDescription("Ban a user by ID, even if they have not joined this server")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption((option) =>
      option.setName("user_id").setDescription("The user's Discord ID").setRequired(true).setMaxLength(20)
    )
    .addStringOption((option) =>
      option.setName("reason").setDescription("Reason for the ban").setMaxLength(400)
    ),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const userId = interaction.options.getString("user_id", true);
    if (!/^\d{17,20}$/.test(userId)) {
      return interaction.editReply("Enter a valid Discord user ID (17–20 digits).");
    }

    const reason = interaction.options.getString("reason") ?? `Hackbanned by ${interaction.user.tag}`;
    let target;
    try {
      target = await interaction.guild.members.fetch(userId);
    } catch (error) {
      if (error.code !== 10007) throw error;
    }

    if (target) {
      const actor = await interaction.guild.members.fetch(interaction.user.id);
      const problem = moderationTargetProblem(interaction, target, actor);
      if (problem) return interaction.editReply(problem);
      await target.ban({ reason });
    } else {
      await interaction.guild.bans.create(userId, { reason });
    }

    const result = await recordModerationAction(interaction, "hackban", target ?? { id: userId }, reason);
    return interaction.editReply(`🔨 User ID ${userId} has been banned.${moderationCaseNotice(result)}`);
  },
};

const timeout = {
  data: reasonOption(
    memberOption(
      new SlashCommandBuilder()
        .setName("timeout")
        .setDescription("Give a member a timeout (up to 28 days)")
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .addIntegerOption((option) =>
          option
            .setName("minutes")
            .setDescription("Timeout length in minutes")
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(40320)
        )
    )
  ),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const user = interaction.options.getUser("user", true);
    const target = await interaction.guild.members.fetch(user.id);
    const actor = await interaction.guild.members.fetch(interaction.user.id);
    const problem = moderationTargetProblem(interaction, target, actor);
    if (problem) return interaction.editReply(problem);

    const minutes = interaction.options.getInteger("minutes", true);
    const reason = interaction.options.getString("reason") ?? `Timed out by ${interaction.user.tag}`;
    const durationMs = minutes * 60 * 1000;
    await target.timeout(durationMs, reason);
    const result = await recordModerationAction(interaction, "timeout", target, reason, durationMs);
    return interaction.editReply(`🔇 ${user.tag} has a ${minutes}-minute timeout.${moderationCaseNotice(result)}`);
  },
};

const purge = {
  data: new SlashCommandBuilder()
    .setName("purge")
    .setDescription("Delete up to 100 recent messages in a channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption((option) =>
      option
        .setName("amount")
        .setDescription("Number of messages to delete")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100)
    )
    .addChannelOption(targetChannelOption),
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const target = await resolveTargetChannel(interaction, {
      memberPermissions: [PermissionFlagsBits.ManageMessages, PermissionFlagsBits.ReadMessageHistory],
      botPermissions: [PermissionFlagsBits.ManageMessages, PermissionFlagsBits.ReadMessageHistory],
    });
    if (target.error) return interaction.editReply(target.error);
    if (!target.channel || !("bulkDelete" in target.channel)) {
      return interaction.editReply("Choose a text channel.");
    }
    const amount = interaction.options.getInteger("amount", true);
    const deleted = await target.channel.bulkDelete(amount, true);
    return interaction.editReply(
      `🧹 Deleted ${deleted.size} message${deleted.size === 1 ? "" : "s"}. Messages older than 14 days are skipped by Discord.`
    );
  },
};

const modlog = {
  data: new SlashCommandBuilder()
    .setName("modlog")
    .setDescription("Show recent moderation cases for a member")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addUserOption((option) =>
      option.setName("user").setDescription("Member whose cases to view").setRequired(true)
    )
    .addIntegerOption((option) =>
      option.setName("limit").setDescription("Number of cases to show (1–10)").setMinValue(1).setMaxValue(10)
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    const user = interaction.options.getUser("user", true);
    const limit = interaction.options.getInteger("limit") ?? 10;
    const cases = await getModerationCases(interaction.guild.id, user.id, limit);
    if (!cases.length) {
      return interaction.reply({ content: `No moderation cases found for ${user.tag}.`, ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`Moderation history · ${user.tag}`)
      .addFields(cases.map((entry) => ({
        name: `#${entry.caseNumber} · ${entry.action} · ${new Date(entry.createdAt).toLocaleDateString()}`,
        value: `Moderator: ${entry.moderatorTag}\nReason: ${entry.reason}`.slice(0, 1024),
      })));
    return interaction.reply({ embeds: [embed], allowedMentions: { parse: [] }, ephemeral: true });
  },
};

const eightBallAnswers = [
  "Absolutely. The crystal ball has spoken.",
  "Nope. The crystal ball is being dramatic.",
  "The vibes say: probably.",
  "Ask again after the snack break.",
  "Outlook unclear. Try turning the question off and on again.",
  "The prophecy says yes, but in a silly hat.",
  "Not a chance. Even the magic 8-ball is concerned.",
];

const eightBall = {
  data: new SlashCommandBuilder()
    .setName("8ball")
    .setDescription("Ask the suspiciously confident magic 8-ball")
    .addStringOption((option) =>
      option.setName("question").setDescription("What do you want to know?").setRequired(true).setMaxLength(300)
    ),
  async execute(interaction) {
    const answer = eightBallAnswers[Math.floor(Math.random() * eightBallAnswers.length)];
    return interaction.reply(`🎱 **${interaction.options.getString("question", true)}**\n${answer}`);
  },
};

const coinflip = {
  data: new SlashCommandBuilder().setName("coinflip").setDescription("Flip a coin; blame the coin either way"),
  async execute(interaction) {
    const result = Math.random() < 0.5 ? "Heads" : "Tails";
    return interaction.reply(`🪙 **${result}!** The coin accepts no appeals.`);
  },
};

const rps = {
  data: new SlashCommandBuilder()
    .setName("rps")
    .setDescription("Challenge the bot to rock-paper-scissors")
    .addStringOption((option) =>
      option
        .setName("choice")
        .setDescription("Your move")
        .setRequired(true)
        .addChoices(
          { name: "Rock 🪨", value: "rock" },
          { name: "Paper 📄", value: "paper" },
          { name: "Scissors ✂️", value: "scissors" }
        )
    ),
  async execute(interaction) {
    const icons = { rock: "🪨", paper: "📄", scissors: "✂️" };
    const yours = interaction.options.getString("choice", true);
    const theirs = ["rock", "paper", "scissors"][Math.floor(Math.random() * 3)];
    const winsAgainst = { rock: "scissors", paper: "rock", scissors: "paper" };
    const result = yours === theirs ? "It's a draw. The bot calls for a rematch." :
      winsAgainst[yours] === theirs ? "You win! The bot claims it was lag." : "The bot wins. It has been training.";
    return interaction.reply(`${icons[yours]} **You** vs **Bot** ${icons[theirs]}\n${result}`);
  },
};

const wouldYouRather = {
  data: new SlashCommandBuilder().setName("wyr").setDescription("Get a ridiculous would-you-rather dilemma"),
  async execute(interaction) {
    const dilemmas = [
      "Would you rather have a tiny marching band announce every time you enter a room, or a goose narrate your day?",
      "Would you rather fight one horse-sized duck or ten duck-sized horses, but they all know your search history?",
      "Would you rather have spaghetti for hair or sneeze glitter exactly once a week?",
      "Would you rather only communicate through dramatic movie quotes or through interpretive dance?",
      "Would you rather be followed everywhere by elevator music or have a laugh track after every sentence?",
      "Would you rather have a personal theme song that changes with your mood or a tiny wizard who gives unsolicited advice?",
      "Would you rather have to hop everywhere on one foot or walk everywhere backward?",
      "Would you rather have a rewind button for awkward moments or a pause button for busy days?",
      "Would you rather understand every animal but never speak to people, or speak every language but never understand animals?",
      "Would you rather have a pet dragon the size of a cat or a pet cat the size of a dragon?",
      "Would you rather have pancakes for hands or waffles for feet?",
      "Would you rather always arrive 10 minutes early or always arrive 10 minutes late?",
      "Would you rather have to sing everything you say or rhyme everything you say?",
      "Would you rather be able to teleport only to places you've visited or fly but only as fast as you can jog?",
      "Would you rather have a tiny rain cloud follow you or a tiny sunbeam follow you?",
      "Would you rather eat only crunchy foods or only soft foods for a week?",
      "Would you rather have a robot do your chores or a robot do your homework?",
      "Would you rather always know when someone is joking or always know when someone needs cheering up?",
      "Would you rather have a friendly ghost as a roommate or a very polite alien as a neighbor?",
      "Would you rather have to wear a cape every day or a crown every day?",
      "Would you rather be able to make any plant grow instantly or make any meal taste perfect?",
      "Would you rather have a library that never runs out of books or a fridge that never runs out of snacks?",
      "Would you rather have your own theme music or your own dramatic entrance smoke?",
      "Would you rather be able to talk to your past self for one minute or your future self for one minute?",
      "Would you rather have a trampoline floor at home or a slide instead of stairs?",
      "Would you rather have to use a fork for every meal or a spoon for every meal?",
      "Would you rather have a personal chef who makes surprises or a personal DJ who picks your music?",
      "Would you rather be famous for inventing a silly dance or for making the world's best sandwich?",
      "Would you rather have a magic backpack that holds anything or shoes that never get dirty?",
      "Would you rather have a day that lasts 30 hours or a weekend that lasts four days?",
      "Would you rather be able to find anything you've lost or always pick the fastest checkout line?",
      "Would you rather live in a treehouse with every comfort or a cozy houseboat that travels slowly?",
      "Would you rather have a friendly penguin deliver your mail or a tiny turtle carry your keys?",
      "Would you rather be able to change your hairstyle with a thought or change your outfit with a snap?",
      "Would you rather have a never-ending bowl of your favorite soup or a never-ending plate of your favorite dessert?",
      "Would you rather have a very enthusiastic personal cheer squad or a very calm personal life coach?",
      "Would you rather be able to see one day into the future or relive one day from the past?",
      "Would you rather have to wear socks on your hands or mittens on your feet?",
      "Would you rather have a door in your room that opens to a beach or one that opens to a mountain cabin?",
      "Would you rather have every dog greet you like an old friend or every bird sing when you walk by?",
      "Would you rather be able to make any boring task fun or make any long trip feel short?",
      "Would you rather have a personal mini-fridge that follows you or a personal fan that follows you?",
      "Would you rather be excellent at every board game or instantly learn any new card game?",
      "Would you rather have a voice that sounds like a movie narrator or a laugh that makes everyone else laugh?",
      "Would you rather have a button that tidies one room or a button that washes all your dishes?",
      "Would you rather spend a day exploring a giant candy shop or a giant toy shop?",
      "Would you rather have a friendly talking backpack or a friendly talking bicycle?",
      "Would you rather always find a perfect parking spot or never have to wait in a queue?",
      "Would you rather have a snow day whenever you want or a sunny picnic day whenever you want?",
      "Would you rather be able to make anyone smile with a joke or help anyone relax with a story?",
      "Would you rather have a tiny parade follow you on your birthday or fireworks appear over your house?",
      "Would you rather be able to instantly learn any instrument or instantly learn any dance?",
    ];
    const dilemma = dilemmas[Math.floor(Math.random() * dilemmas.length)];
    return interaction.reply(`🤔 ${dilemma}`);
  },
};

const truthOrDare = {
  data: new SlashCommandBuilder()
    .setName("truth-or-dare")
    .setDescription("Get a harmless truth question or a goofy dare")
    .addStringOption((option) =>
      option
        .setName("pick")
        .setDescription("Truth or dare?")
        .setRequired(true)
        .addChoices(
          { name: "Truth", value: "truth" },
          { name: "Dare", value: "dare" }
        )
    ),
  async execute(interaction) {
    const truths = [
      "What is the silliest thing you believed as a kid?",
      "What song do you secretly know every word to?",
      "What is your most oddly specific pet peeve?",
      "If your pet (or a pigeon) could review you, what would it say?",
    ];
    const dares = [
      "Speak like a pirate for your next three messages.",
      "Invent a new holiday and explain its extremely weird tradition.",
      "Give your current snack a dramatic movie-review score.",
      "Send a sentence where every word starts with the same letter.",
    ];
    const list = interaction.options.getString("pick", true) === "truth" ? truths : dares;
    const prompt = list[Math.floor(Math.random() * list.length)];
    return interaction.reply(`🎭 **${interaction.options.getString("pick", true)}!** ${prompt}`);
  },
};

const trivia = {
  data: new SlashCommandBuilder()
    .setName("trivia")
    .setDescription("What is a group of flamingos called?")
    .addStringOption((option) =>
      option
        .setName("answer")
        .setDescription("Pick your answer")
        .setRequired(true)
        .addChoices(
          { name: "A) A group of flamingos", value: "flamingos" },
          { name: "B) A group of cats", value: "cats" },
          { name: "C) A group of frogs", value: "frogs" }
        )
    ),
  async execute(interaction) {
    const answer = interaction.options.getString("answer", true);
    return interaction.reply(
      `🧠 What is the collective noun for flamingos? You picked **${answer}**. ${answer === "flamingos" ? "Correct! It's a flamboyance. Fancy birds, fancy name." : "Not quite! The answer is a flamboyance. The frogs are forming a committee about this."}`
    );
  },
};

const numberGuess = {
  data: new SlashCommandBuilder()
    .setName("number-guess")
    .setDescription("Guess the bot's number from 1 to 10")
    .addIntegerOption((option) =>
      option.setName("guess").setDescription("Your guess").setRequired(true).setMinValue(1).setMaxValue(10)
    ),
  async execute(interaction) {
    const guess = interaction.options.getInteger("guess", true);
    const answer = Math.floor(Math.random() * 10) + 1;
    const result = guess === answer
      ? "Bullseye! The number-guessing goblin respects you."
      : guess < answer
        ? "Too low! The number has gone to live on a taller shelf."
        : "Too high! The number has requested you calm down.";
    return interaction.reply(`🔢 The number was **${answer}**. ${result}`);
  },
};

const riddle = {
  data: new SlashCommandBuilder().setName("riddle").setDescription("Try a tiny riddle (the answer is spoiler-hidden)"),
  async execute(interaction) {
    const riddles = [
      ["What has keys but can't open locks?", "A piano."],
      ["What gets wetter the more it dries?", "A towel."],
      ["What has a face and two hands but no arms or legs?", "A clock."],
      ["What has one eye but cannot see?", "A needle."],
    ];
    const [question, answer] = riddles[Math.floor(Math.random() * riddles.length)];
    return interaction.reply(`🧩 ${question}\n||${answer}||`);
  },
};

const emojiQuiz = {
  data: new SlashCommandBuilder()
    .setName("emoji-quiz")
    .setDescription("Decode this phrase: a pig plus a flying plane")
    .addStringOption((option) =>
      option
        .setName("answer")
        .setDescription("What do the emojis mean?")
        .setRequired(true)
        .addChoices(
          { name: "A) When pigs fly", value: "pigs" },
          { name: "B) A piece of cake", value: "cake" },
          { name: "C) Let the cat out of the bag", value: "cat" }
        )
    ),
  async execute(interaction) {
    const answer = interaction.options.getString("answer", true);
    return interaction.reply(
      `🐷✈️ Decode this: You picked **${answer}**. ${answer === "pigs" ? "Correct! When pigs fly!" : "Close, but it's **when pigs fly**. The pigs have excellent air miles."}`
    );
  },
};

export function createAiCommand(ask = askAi) {
  return {
    data: new SlashCommandBuilder()
      .setName("ai")
      .setDescription("Ask AI a question")
      .addStringOption((option) =>
        option
          .setName("prompt")
          .setDescription("What would you like to ask?")
          .setRequired(true)
          .setMinLength(1)
          .setMaxLength(1500)
      ),
    async execute(interaction) {
      if (!interaction.guildId) {
        return interaction.reply({ content: "AI can only be used in a server.", ephemeral: true });
      }

      await interaction.deferReply();
      try {
        const result = await ask(
          interaction.guildId,
          interaction.user.id,
          interaction.options.getString("prompt", true),
          async (operation) => {
            const text = await operation();
            await interaction[waitForCommandCooldown]?.();
            return text;
          }
        );
        return interaction.editReply(aiReplyOptions(interaction.user.id, result.error ?? result.text));
      } catch (error) {
        console.error("AI request failed for /ai:", error);
        return interaction.editReply(aiReplyOptions(interaction.user.id, "The AI couldn't answer right now. Please try again later."));
      }
    },
  };
}

const ai = createAiCommand();

const aiChannel = {
  data: new SlashCommandBuilder()
    .setName("ai-channel")
    .setDescription("Configure this server's AI chat channel (Manage Server required)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((option) =>
      option
        .setName("action")
        .setDescription("Choose how to configure AI")
        .setRequired(true)
        .addChoices(
          { name: "Setup a new #ai-chat channel", value: "setup" },
          { name: "Link an existing channel", value: "link" },
          { name: "Unlink the AI channel (keeps the channel)", value: "unlink" },
          { name: "Enable AI for this server", value: "enable" },
          { name: "Disable AI for this server", value: "disable" }
        )
    )
    .addChannelOption((option) =>
      option.setName("channel").setDescription("Channel for the link action; defaults to this channel").addChannelTypes(ChannelType.GuildText)
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      return interaction.reply({ content: "Manage Server permission is required.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    const action = interaction.options.getString("action", true);
    if (action !== "link" && interaction.options.getChannel("channel")) {
      return interaction.editReply("The channel option is only used with the link action.");
    }
    if (action === "disable" || action === "enable") {
      const settings = await setAiEnabled(interaction.guildId, action === "enable");
      return interaction.editReply(`AI is now **${settings.enabled ? "enabled" : "disabled"}** for this server.`);
    }

    if (action === "unlink") {
      const previousSettings = await getAiSettings(interaction.guildId);
      await unlinkAiChannel(interaction.guildId);
      return interaction.editReply(
        previousSettings.channelId
          ? "The AI channel link was removed. The Discord channel itself was not deleted."
          : "No AI channel was linked. No Discord channel was deleted."
      );
    }

    if (action === "setup") {
      const existingSettings = await getAiSettings(interaction.guildId);
      if (existingSettings.channelId) {
        return interaction.editReply("An AI channel is already linked. Unlink it first, or use the link action to connect a different channel.");
      }
      if (!interaction.memberPermissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.editReply("Manage Channels permission is required to create an AI chat channel.");
      }

      const botMember = interaction.guild.members.me;
      if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.editReply("I need the Manage Channels permission to create an AI chat channel.");
      }

      const channel = await interaction.guild.channels.create({
        name: "ai-chat",
        type: ChannelType.GuildText,
        topic: "Chat with AI. Messages here are sent to GroqCloud.",
        permissionOverwrites: [{
          id: interaction.client.user.id,
          allow: [
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.ReadMessageHistory,
          ],
        }],
      });
      await setAiChannel(interaction.guildId, channel.id);
      return interaction.editReply(`Created and linked ${channel}. Messages there will receive AI replies.`);
    }

    const target = await resolveTargetChannel(interaction, {
      memberPermissions: [PermissionFlagsBits.ManageGuild],
      botPermissions: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
    if (target.error) return interaction.editReply(target.error);
    const channel = target.channel;
    if (channel?.type !== ChannelType.GuildText) {
      return interaction.editReply("Choose a regular text channel to link for AI chat.");
    }

    const botMember = interaction.guild.members.me;
    const permissions = botMember && channel.permissionsFor(botMember);
    if (!permissions?.has([
      PermissionFlagsBits.ViewChannel,
      PermissionFlagsBits.SendMessages,
      PermissionFlagsBits.ReadMessageHistory,
    ])) {
      return interaction.editReply("I need View Channel, Send Messages, and Read Message History permissions there.");
    }

    await setAiChannel(interaction.guildId, channel.id);
    return interaction.editReply(`Linked ${channel} as this server's AI chat channel.`);
  },
};

function getAutoRoleProblem(interaction, role) {
  if (!role) return null;
  const botMember = interaction.guild.members.me;
  if (!botMember?.permissions.has(PermissionFlagsBits.ManageRoles)) {
    return "I need the Manage Roles permission to assign an automatic role.";
  }
  if (role.id === interaction.guild.id || !role.editable) {
    return "I can't assign that role. Make sure it isn't managed and is below my highest role.";
  }
  return null;
}

const welcome = {
  data: new SlashCommandBuilder()
    .setName("welcome")
    .setDescription("Configure welcome messages and an automatic member role")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((subcommand) =>
      subcommand
        .setName("setup")
        .setDescription("Set the welcome channel and message")
        .addChannelOption((option) =>
          option
            .setName("channel")
            .setDescription("Where welcome messages should be posted")
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("message")
            .setDescription("Use {user}, {server}, and {memberCount} as placeholders")
            .setMaxLength(1000)
            .setRequired(true)
        )
        .addRoleOption((option) =>
          option.setName("role").setDescription("Optional role to assign to new members")
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("edit")
        .setDescription("Edit the welcome message without changing its channel or role")
        .addStringOption((option) =>
          option
            .setName("message")
            .setDescription("Use {user}, {server}, and {memberCount} as placeholders")
            .setMaxLength(1000)
            .setRequired(true)
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("role")
        .setDescription("Set or clear the automatic role for new members")
        .addRoleOption((option) =>
          option.setName("role").setDescription("Omit this option to clear the automatic role")
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("disable")
        .setDescription("Turn off welcome messages and the automatic role")
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    const subcommand = interaction.options.getSubcommand();
    if (subcommand === "setup") {
      const channel = interaction.options.getChannel("channel", true);
      const message = interaction.options.getString("message", true).trim();
      const role = interaction.options.getRole("role");
      if (!message) return interaction.editReply("Enter a non-empty welcome message.");

      const botMember = interaction.guild.members.me;
      const permissions = botMember && channel.permissionsFor(botMember);
      if (!permissions?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages])) {
        return interaction.editReply("I need View Channel and Send Messages permissions in the welcome channel.");
      }

      const roleProblem = getAutoRoleProblem(interaction, role);
      if (roleProblem) return interaction.editReply(roleProblem);

      const settings = await setWelcomeSettings(
        interaction.guild.id,
        channel.id,
        message,
        role?.id
      );
      return interaction.editReply(
        `✅ Welcome messages are set for ${channel}.${settings.autoRoleId ? ` New members will also receive <@&${settings.autoRoleId}>.` : ""}`
      );
    }

    if (subcommand === "edit") {
      const message = interaction.options.getString("message", true).trim();
      if (!message) return interaction.editReply("Enter a non-empty welcome message.");

      const settings = await updateWelcomeMessage(interaction.guild.id, message);
      if (!settings) {
        return interaction.editReply("Set up welcome messages first with `/welcome setup`.");
      }
      return interaction.editReply("✅ The welcome message has been updated.");
    }

    if (subcommand === "role") {
      const role = interaction.options.getRole("role");
      const roleProblem = getAutoRoleProblem(interaction, role);
      if (roleProblem) return interaction.editReply(roleProblem);

      await setAutoRole(interaction.guild.id, role?.id ?? null);
      return interaction.editReply(
        role
          ? `✅ New members will receive ${role}.`
          : "✅ The automatic role has been cleared."
      );
    }

    await disableWelcome(interaction.guild.id);
    return interaction.editReply("✅ Welcome messages and automatic role assignment are disabled.");
  },
};

const giveaway = {
  data: new SlashCommandBuilder()
    .setName("giveaway")
    .setDescription("Create or end a community giveaway")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((subcommand) =>
      subcommand
        .setName("start")
        .setDescription("Start a giveaway in a channel")
        .addStringOption((option) =>
          option
            .setName("prize")
            .setDescription("What members can win")
            .setMaxLength(100)
            .setRequired(true)
        )
        .addIntegerOption((option) =>
          option
            .setName("duration_hours")
            .setDescription("How many hours the giveaway should run (1–168)")
            .setMinValue(1)
            .setMaxValue(168)
            .setRequired(true)
        )
        .addIntegerOption((option) =>
          option
            .setName("winners")
            .setDescription("Number of winners (1–10)")
            .setMinValue(1)
            .setMaxValue(10)
            .setRequired(true)
        )
        .addChannelOption(targetChannelOption)
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("end")
        .setDescription("End a giveaway early using its message ID")
        .addStringOption((option) =>
          option
            .setName("message_id")
            .setDescription("Message ID shown at the bottom of the giveaway")
            .setMinLength(17)
            .setMaxLength(20)
            .setRequired(true)
        )
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    if (interaction.options.getSubcommand() === "start") {
      const target = await resolveTargetChannel(interaction, {
        memberPermissions: [PermissionFlagsBits.ManageGuild, PermissionFlagsBits.SendMessages],
        botPermissions: [
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.EmbedLinks,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      });
      if (target.error) return interaction.editReply(target.error);
      const channel = target.channel;
      if (
        !channel ||
        ![ChannelType.GuildText, ChannelType.GuildAnnouncement].includes(channel.type)
      ) {
        return interaction.editReply("Start giveaways in a regular text or announcement channel.");
      }

      const botMember = interaction.guild.members.me;
      const permissions = botMember && channel.permissionsFor(botMember);
      if (!permissions?.has([
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.EmbedLinks,
        PermissionFlagsBits.ReadMessageHistory,
      ])) {
        return interaction.editReply("I need View Channel, Send Messages, Embed Links, and Read Message History permissions in that channel.");
      }

      const prize = interaction.options.getString("prize", true).trim();
      if (!prize) return interaction.editReply("Enter a non-empty prize.");
      const durationHours = interaction.options.getInteger("duration_hours", true);
      const initialGiveaway = {
        messageId: "",
        guildId: interaction.guild.id,
        channelId: channel.id,
        prize,
        winnerCount: interaction.options.getInteger("winners", true),
        endsAt: Date.now() + durationHours * 3_600_000,
        entrants: [],
        winnerIds: [],
      };
      const message = await channel.send({ embeds: [createGiveawayEmbed(initialGiveaway)] });
      initialGiveaway.messageId = message.id;

      try {
        const savedGiveaway = await createGiveaway(initialGiveaway);
        await message.edit({
          embeds: [createGiveawayEmbed(savedGiveaway)],
          components: createGiveawayComponents(message.id),
        });
      } catch (error) {
        try {
          await deleteGiveaway(message.id);
        } catch (cleanupError) {
          console.error(`Could not remove incomplete giveaway data for ${message.id}:`, cleanupError);
        }
        try {
          await message.delete();
        } catch (cleanupError) {
          console.error(`Could not remove incomplete giveaway message ${message.id}:`, cleanupError);
        }
        throw error;
      }

      return interaction.editReply(
        `✅ Giveaway started in ${channel}. It ends <t:${Math.floor(initialGiveaway.endsAt / 1000)}:R>.`
      );
    }

    const messageId = interaction.options.getString("message_id", true);
    if (!/^\d{17,20}$/.test(messageId)) {
      return interaction.editReply("Enter a valid Discord message ID.");
    }
    const savedGiveaway = await getGiveaway(messageId);
    if (!savedGiveaway || savedGiveaway.guildId !== interaction.guild.id) {
      return interaction.editReply("I couldn't find that giveaway in this server.");
    }
    if (savedGiveaway.status === "ended") {
      return interaction.editReply("That giveaway has already ended.");
    }

    const result = await endGiveaway(interaction.client, messageId, { force: true });
    return interaction.editReply(
      result.alreadyEnded
        ? "That giveaway has already ended."
        : "✅ The giveaway has ended and its winners have been selected."
    );
  },
};

const balance = {
  data: new SlashCommandBuilder().setName("balance").setDescription("Check your multicoins balance"),
  async execute(interaction) {
    const coins = await getBalance(economyGuildId(interaction), interaction.user.id);
    return interaction.reply(`🪙 You have **${coins} multicoins**.`);
  },
};

const daily = {
  data: new SlashCommandBuilder().setName("daily").setDescription("Collect your once-a-day multicoins allowance"),
  async execute(interaction) {
    const result = await claimDaily(economyGuildId(interaction), interaction.user.id);
    const message = result.claimed
      ? `🎁 Daily allowance claimed: **+${result.reward} multicoins**. New balance: **${result.balance} multicoins**.`
      : `⏰ You already collected today's allowance. Your balance is **${result.balance} multicoins**.`;
    return interaction.reply(message);
  },
};

const gambleTitles = {
  coinflip: "🪙 Coin Flip",
  dice: "🎲 Dice",
  slots: "🎰 Slots",
  blackjack: "🃏 Blackjack",
  roulette: "🎡 Roulette — Red",
};

const createGambleEmbed = (game, result, frameReels, lockedReels = 0) => {
  const isSpinning = Boolean(frameReels);
  const embed = new EmbedBuilder()
    .setColor(isSpinning ? 0x5865f2 : result.jackpot ? 0xf1c40f : result.won ? 0x57f287 : result.push ? 0x95a5a6 : 0xed4245)
    .setTitle(game === "slots" && result.machineName
      ? `${result.machineEmoji} ${result.machineName}`
      : gambleTitles[game]);

  if (isSpinning) {
    return embed
      .setDescription(`[ ${frameReels.join(" │ ")} ]`)
      .setFooter({ text: `Spinning… ${lockedReels}/${slotReelCount} reels stopped` });
  }

  const outcome = game === "slots"
    ? result.won
      ? `${result.jackpot ? "JACKPOT! " : ""}${result.detail} ${result.payoutPercent}% payout (${result.payout} multicoins).`
      : `No 3+ match — lost ${result.wager} multicoins.`
    : result.push
      ? `Push — your ${result.wager} multicoins were returned.`
      : result.won
        ? `${result.jackpot ? "JACKPOT! " : ""}Won ${result.payout - result.wager} multicoins.`
        : `Lost ${result.wager} multicoins.`;
  const description = game === "slots"
    ? `[ ${result.reels.join(" │ ")} ]`
    : result.detail;

  const fields = [
    { name: "Result", value: outcome, inline: true },
    { name: "Balance", value: `${result.balance} multicoins`, inline: true },
  ];
  if (game === "slots") {
    fields.push({ name: "RTP target", value: `${result.rtpTargetPercent}% this spin`, inline: true });
  }

  return embed
    .setDescription(description)
    .addFields(fields)
    .setFooter({ text: "Multicoins are virtual and have no cash value." });
};

const gamble = {
  data: new SlashCommandBuilder()
    .setName("gamble")
    .setDescription("Bet multicoins on a game (no real money or prizes)")
    .addStringOption((option) =>
      option
        .setName("game")
        .setDescription("Choose a game; roulette automatically bets red")
        .setRequired(true)
        .addChoices(
          { name: "Coin flip (win on heads)", value: "coinflip" },
          { name: "Dice (win on 4–6)", value: "dice" },
          { name: "Blackjack (automatic play)", value: "blackjack" },
          { name: "Roulette (auto-bet red)", value: "roulette" }
        )
    )
    .addIntegerOption((option) =>
      option.setName("wager").setDescription("Multicoins to wager (1–1000)").setRequired(true).setMinValue(1).setMaxValue(1000)
    ),
  async execute(interaction) {
    const game = interaction.options.getString("game", true);
    const wager = interaction.options.getInteger("wager", true);

    await interaction.deferReply();
    const result = await placeBet(economyGuildId(interaction), interaction.user.id, game, wager);
    if (result.error) {
      const errorEmbed = new EmbedBuilder()
        .setColor(0xed4245)
        .setTitle("Not enough multicoins")
        .setDescription(`${result.error} Balance: **${result.balance} multicoins**.`);
      return interaction.editReply({ embeds: [errorEmbed] });
    }
    return interaction.editReply({ embeds: [createGambleEmbed(game, result)] });
  },
};

export function createSlotsCommand(placeSlots = placeSlotBet) {
  return {
    data: new SlashCommandBuilder()
      .setName("slots")
      .setDescription(`Play themed four-reel slots with bonus rounds and ${slotRtpMinPercent}–${slotRtpMaxPercent}% per-spin RTP`)
      .addIntegerOption((option) =>
        option
          .setName("bet")
          .setDescription("Multicoins to wager (1–1000)")
          .setRequired(true)
          .setMinValue(1)
          .setMaxValue(1000)
      )
      .addStringOption((option) =>
        option
          .setName("machine")
          .setDescription("Choose a slot machine (Classic is the default)")
          .addChoices(...slotMachines.map((machine) => ({
            name: `${machine.emoji} ${machine.name}`,
            value: machine.id,
          })))
      ),
    async execute(interaction) {
      if (!interaction.guildId) {
        return interaction.reply({ content: "Slots can only be played in a server.", ephemeral: true });
      }

      const wager = interaction.options.getInteger("bet", true);
      const machineId = interaction.options.getString("machine") ?? "classic";
      const result = await placeSlots(interaction.guildId, interaction.user.id, wager, machineId);
      if (result.error) {
        return interaction.reply({
          content: `${result.error} Balance: **${result.balance} multicoins**.`,
          ephemeral: true,
        });
      }

      await interaction.deferReply();
      const makeFrame = (lockedReels) =>
        Array.from({ length: slotReelCount }, (_, index) =>
          index < lockedReels ? result.reels[index] : randomSlotSymbol(machineId)
        );

      await interaction.editReply({ embeds: [createGambleEmbed("slots", result, makeFrame(0))] });
      const spinStartedAt = Date.now();
      for (let lockedReels = 1; lockedReels <= slotReelCount; lockedReels += 1) {
        const nextStopAt = spinStartedAt + Math.round(lockedReels * 5000 / slotReelCount);
        await new Promise((resolve) => setTimeout(resolve, Math.max(0, nextStopAt - Date.now())));
        if (lockedReels === slotReelCount) {
          return interaction.editReply({ embeds: [createGambleEmbed("slots", result)] });
        }
        await interaction.editReply({
          embeds: [createGambleEmbed("slots", result, makeFrame(lockedReels), lockedReels)],
        });
      }
    },
  };
}

const slots = createSlotsCommand();

const postEmbed = {
  data: new SlashCommandBuilder()
    .setName("embed")
    .setDescription("Post a formatted announcement embed")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption((option) =>
      option.setName("title").setDescription("Embed heading").setRequired(true).setMaxLength(256)
    )
    .addStringOption((option) =>
      option.setName("message").setDescription("Embed text").setRequired(true).setMaxLength(4000)
    )
    .addStringOption((option) =>
      option
        .setName("color")
        .setDescription("Embed accent color")
        .addChoices(
          { name: "Discord blue", value: "blue" },
          { name: "Green", value: "green" },
          { name: "Purple", value: "purple" },
          { name: "Orange", value: "orange" },
          { name: "Red", value: "red" }
        )
    )
    .addStringOption((option) =>
      option.setName("footer").setDescription("Optional small footer text").setMaxLength(2048)
    )
    .addChannelOption(targetChannelOption),
  async execute(interaction) {
    const target = await resolveTargetChannel(interaction, {
      memberPermissions: [PermissionFlagsBits.ManageMessages, PermissionFlagsBits.SendMessages],
      botPermissions: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks],
    });
    if (target.error) return interaction.reply({ content: target.error, ephemeral: true });
    if (!target.channel || !("send" in target.channel)) {
      return interaction.reply({ content: "This command only works in a channel where I can post.", ephemeral: true });
    }

    const colorValues = embedColorValues;
    const color = interaction.options.getString("color") ?? "blue";
    const embed = new EmbedBuilder()
      .setColor(colorValues[color])
      .setTitle(interaction.options.getString("title", true))
      .setDescription(interaction.options.getString("message", true));
    const footer = interaction.options.getString("footer");
    if (footer) embed.setFooter({ text: footer });

    await interaction.deferReply({ ephemeral: true });
    await target.channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    return interaction.editReply(`📣 Embed posted in ${target.channel}.`);
  },
};

const embedColorValues = {
  blue: 0x5865f2,
  green: 0x57f287,
  purple: 0x9b59b6,
  orange: 0xe67e22,
  red: 0xed4245,
};

const editEmbed = {
  data: new SlashCommandBuilder()
    .setName("embed-edit")
    .setDescription("Edit an embed posted by this bot")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption((option) =>
      option.setName("message_id").setDescription("ID of the bot's embed message").setRequired(true)
    )
    .addStringOption((option) =>
      option.setName("title").setDescription("New embed heading").setMaxLength(256)
    )
    .addStringOption((option) =>
      option.setName("message").setDescription("New embed text").setMaxLength(4000)
    )
    .addStringOption((option) =>
      option
        .setName("color")
        .setDescription("New embed accent color")
        .addChoices(
          { name: "Discord blue", value: "blue" },
          { name: "Green", value: "green" },
          { name: "Purple", value: "purple" },
          { name: "Orange", value: "orange" },
          { name: "Red", value: "red" }
        )
    )
    .addStringOption((option) =>
      option.setName("footer").setDescription("New footer text").setMaxLength(2048)
    )
    .addChannelOption(targetChannelOption),
  async execute(interaction) {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages)) {
      return interaction.reply({ content: "You need Manage Messages to edit embeds.", ephemeral: true });
    }
    const target = await resolveTargetChannel(interaction, {
      memberPermissions: [PermissionFlagsBits.ManageMessages, PermissionFlagsBits.ReadMessageHistory],
      botPermissions: [PermissionFlagsBits.ReadMessageHistory],
    });
    if (target.error) return interaction.reply({ content: target.error, ephemeral: true });
    if (!target.channel || !("messages" in target.channel)) {
      return interaction.reply({ content: "This command only works in a channel with message history.", ephemeral: true });
    }

    const title = interaction.options.getString("title")?.trim() ?? null;
    const description = interaction.options.getString("message")?.trim() ?? null;
    const color = interaction.options.getString("color");
    const footer = interaction.options.getString("footer")?.trim() ?? null;
    if (title === null && description === null && color === null && footer === null) {
      return interaction.reply({
        content: "Choose at least one embed field to update.",
        ephemeral: true,
      });
    }
    if (title === "" || description === "" || footer === "") {
      return interaction.reply({
        content: "Embed fields cannot be blank.",
        ephemeral: true,
      });
    }

    await interaction.deferReply({ ephemeral: true });
    const message = await target.channel.messages.fetch(
      interaction.options.getString("message_id", true)
    );
    if (message.author.id !== interaction.client.user.id) {
      return interaction.editReply("I can only edit messages posted by this bot.");
    }
    if (!message.embeds.length) {
      return interaction.editReply("That message does not contain an embed to edit.");
    }

    const embeds = message.embeds.map((existing) => EmbedBuilder.from(existing));
    const embed = embeds[0];
    if (title !== null) embed.setTitle(title);
    if (description !== null) embed.setDescription(description);
    if (color !== null) embed.setColor(embedColorValues[color]);
    if (footer !== null) embed.setFooter({ text: footer });

    embeds[0] = embed;
    await message.edit({ embeds });
    return interaction.editReply("✅ Embed updated.");
  },
};

const poll = {
  data: new SlashCommandBuilder()
    .setName("poll")
    .setDescription("Start a reaction-vote poll with 2–5 choices")
    .addStringOption((option) =>
      option.setName("question").setDescription("What are you asking?").setRequired(true).setMaxLength(256)
    )
    .addStringOption((option) =>
      option.setName("option1").setDescription("First choice").setRequired(true).setMaxLength(80)
    )
    .addStringOption((option) =>
      option.setName("option2").setDescription("Second choice").setRequired(true).setMaxLength(80)
    )
    .addStringOption((option) =>
      option.setName("option3").setDescription("Optional third choice").setMaxLength(80)
    )
    .addStringOption((option) =>
      option.setName("option4").setDescription("Optional fourth choice").setMaxLength(80)
    )
    .addStringOption((option) =>
      option.setName("option5").setDescription("Optional fifth choice").setMaxLength(80)
    )
    .addChannelOption(targetChannelOption),
  async execute(interaction) {
    const target = await resolveTargetChannel(interaction, {
      memberPermissions: [PermissionFlagsBits.SendMessages],
      botPermissions: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.AddReactions, PermissionFlagsBits.ReadMessageHistory],
    });
    if (target.error) return interaction.reply({ content: target.error, ephemeral: true });
    if (!target.channel || !("send" in target.channel)) {
      return interaction.reply({ content: "This command only works in a channel where I can post.", ephemeral: true });
    }

    const options = [1, 2, 3, 4, 5]
      .map((number) => interaction.options.getString(`option${number}`))
      .filter(Boolean);
    const emojis = ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣"];
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(interaction.options.getString("question", true))
      .setDescription(options.map((text, index) => `${emojis[index]} ${text}`).join("\n"))
      .setFooter({ text: `Poll by ${interaction.user.tag} · react to vote` });

    await interaction.deferReply({ ephemeral: true });
    const message = await target.channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    for (let index = 0; index < options.length; index += 1) {
      await message.react(emojis[index]);
    }
    return interaction.editReply(`📊 Poll posted in <#${target.channel.id}>.`);
  },
};

const suggest = {
  data: new SlashCommandBuilder()
    .setName("suggest")
    .setDescription("Post a community suggestion for members to vote on")
    .addStringOption((option) =>
      option.setName("idea").setDescription("Your suggestion").setRequired(true).setMaxLength(1000)
    )
    .addChannelOption(targetChannelOption),
  async execute(interaction) {
    const target = await resolveTargetChannel(interaction, {
      memberPermissions: [PermissionFlagsBits.SendMessages],
      botPermissions: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.AddReactions, PermissionFlagsBits.ReadMessageHistory],
    });
    if (target.error) return interaction.reply({ content: target.error, ephemeral: true });
    if (!target.channel || !("send" in target.channel)) {
      return interaction.reply({ content: "This command only works in a channel where I can post.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x57f287)
      .setTitle("💡 Community suggestion")
      .setDescription(interaction.options.getString("idea", true))
      .setFooter({ text: `Suggested by ${interaction.user.tag}` });

    await interaction.deferReply({ ephemeral: true });
    const message = await target.channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    await message.react("👍");
    await message.react("👎");
    return interaction.editReply(`💡 Suggestion posted in <#${target.channel.id}> for the community to vote on.`);
  },
};

const serverInfo = {
  data: new SlashCommandBuilder().setName("server-info").setDescription("Show details about this server"),
  async execute(interaction) {
    const guild = interaction.guild;
    if (!guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`🏠 ${guild.name}`)
      .addFields(
        { name: "Members", value: String(guild.memberCount), inline: true },
        { name: "Channels", value: String(guild.channels.cache.size), inline: true },
        { name: "Created", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
        { name: "Server ID", value: guild.id }
      );
    const icon = guild.iconURL();
    if (icon) embed.setThumbnail(icon);
    return interaction.reply({ embeds: [embed] });
  },
};

const userInfo = {
  data: new SlashCommandBuilder()
    .setName("user-info")
    .setDescription("Show your details or another server member's details")
    .addUserOption((option) =>
      option.setName("user").setDescription("Member to look up (defaults to you)")
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    const user = interaction.options.getUser("user") ?? interaction.user;
    const member = await interaction.guild.members.fetch(user.id);
    const embed = new EmbedBuilder()
      .setColor(member.displayColor || 0x5865f2)
      .setTitle(`👤 ${user.tag}`)
      .addFields(
        { name: "Joined server", value: member.joinedAt ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>` : "Unknown", inline: true },
        { name: "Account created", value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true },
        { name: "Roles", value: String(Math.max(0, member.roles.cache.size - 1)), inline: true },
        { name: "User ID", value: user.id }
      )
      .setThumbnail(user.displayAvatarURL());
    return interaction.reply({ embeds: [embed] });
  },
};

const channelInfo = {
  data: new SlashCommandBuilder()
    .setName("channel-info")
    .setDescription("Show details about a server channel")
    .addChannelOption((option) =>
      option.setName("channel").setDescription("Channel to inspect (defaults to this channel)")
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    const channel = interaction.options.getChannel("channel") ?? interaction.channel;
    if (!channel || !("guildId" in channel) || channel.guildId !== interaction.guildId) {
      return interaction.reply({ content: "I couldn't find that server channel.", ephemeral: true });
    }

    const channelType = ChannelType[channel.type] ?? `Type ${channel.type}`;
    const topic = "topic" in channel && typeof channel.topic === "string" && channel.topic
      ? channel.topic.length > 1000 ? `${channel.topic.slice(0, 997)}...` : channel.topic
      : "None";
    const parentName = "parent" in channel && channel.parent ? channel.parent.name : "None";
    const nsfw = "nsfw" in channel ? (channel.nsfw ? "Yes" : "No") : "Not applicable";
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`📍 ${channel.name ?? "Server channel"}`)
      .addFields(
        { name: "Type", value: channelType, inline: true },
        { name: "Created", value: `<t:${Math.floor(channel.createdTimestamp / 1000)}:D>`, inline: true },
        { name: "Category", value: parentName, inline: true },
        { name: "NSFW", value: nsfw, inline: true },
        { name: "Channel ID", value: channel.id },
        { name: "Topic", value: topic }
      );
    return interaction.reply({ embeds: [embed] });
  },
};

const roleInfo = {
  data: new SlashCommandBuilder()
    .setName("role-info")
    .setDescription("Show details about a server role")
    .addRoleOption((option) =>
      option.setName("role").setDescription("Role to inspect").setRequired(true)
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    const role = interaction.options.getRole("role", true);
    const permissionNames = role.permissions.toArray()
      .map((permission) => permission.replace(/([a-z])([A-Z])/g, "$1 $2"));
    const permissions = permissionNames.length
      ? permissionNames.join(", ")
      : "No explicit permissions";
    const embed = new EmbedBuilder()
      .setColor(role.color || 0x5865f2)
      .setTitle(`🎭 ${role.name}`)
      .addFields(
        { name: "Role ID", value: role.id, inline: true },
        { name: "Position", value: String(role.position), inline: true },
        { name: "Created", value: `<t:${Math.floor(role.createdTimestamp / 1000)}:D>`, inline: true },
        { name: "Mentionable", value: role.mentionable ? "Yes" : "No", inline: true },
        { name: "Shown separately", value: role.hoist ? "Yes" : "No", inline: true },
        { name: "Managed by an integration", value: role.managed ? "Yes" : "No", inline: true },
        { name: "Permissions", value: permissions.length > 1024 ? `${permissions.slice(0, 1021)}...` : permissions }
      );
    const icon = interaction.guild.iconURL();
    if (icon) embed.setThumbnail(icon);
    return interaction.reply({ embeds: [embed] });
  },
};

export const helpSelectCustomId = "multicoins-help-category";
export const helpCancelCustomId = "multibot:help:cancel:";

const helpCategories = {
  economy: { label: "Economy", emoji: "🪙", commands: ["balance", "daily", "gamble", "slots"] },
  games: { label: "Games", emoji: "🎮", commands: ["8ball", "coinflip", "rps", "wyr", "truth-or-dare", "trivia", "emoji-quiz", "number-guess", "riddle"] },
  information: { label: "Information", emoji: "📊", commands: ["help", "level", "leaderboard", "server-stats", "version", "ping", "uptime", "sync-check", "server-info", "user-info", "channel-info", "role-info"] },
  ai: { label: "AI", emoji: "🤖", commands: ["ai", "ai-channel"] },
  moderation: { label: "Moderation", emoji: "🛡️", commands: ["warn", "kick", "ban", "hackban", "timeout", "modlog", "purge", "logs", "level-reset"] },
  community: { label: "Community", emoji: "🧰", commands: ["afk", "birthday", "profile", "thanks", "invites", "custom-command", "welcome", "giveaway", "announcement", "embed", "embed-edit", "poll", "suggest"] },
  setup: { label: "Server setup", emoji: "🛠️", commands: ["automod", "level-reward", "autosetup", "server-builder", "messages", "reaction-role", "sticky", "tickets"] },
  tools: { label: "Utilities", emoji: "🔧", commands: ["tools"] },
  owner: { label: "Bot owner", emoji: "⚙️", commands: ["bot-presence", "bot-maintenance"] },
};

let helpCommands = [];

export function configureHelpCommands(commands) {
  helpCommands = commands;
}

function getHelpCategories() {
  const assigned = new Set(Object.values(helpCategories).flatMap((category) => category.commands));
  const other = helpCommands.filter((command) => !assigned.has(command.data.name)).map((command) => command.data.name);
  return other.length
    ? { ...helpCategories, other: { label: "Other", emoji: "📁", commands: other } }
    : helpCategories;
}

const helpSupportUrl = "https://discord.gg/rkER55w7m6";

function getBotInviteUrl() {
  const clientId = process.env.CLIENT_ID;
  if (!clientId) return null;
  const query = new URLSearchParams({
    client_id: clientId,
    scope: "bot applications.commands",
  });
  return `https://discord.com/oauth2/authorize?${query}`;
}

function createHelpLinks() {
  const inviteUrl = getBotInviteUrl();
  return [
    `[Support Server](${helpSupportUrl})`,
    inviteUrl ? `[Invite the bot](${inviteUrl})` : null,
  ].filter(Boolean).join("\n");
}

export function createHelpEmbed(category) {
  const selected = getHelpCategories()[category];
  const definitions = new Map(helpCommands.map((command) => [command.data.name, command.data.toJSON()]));
  const lines = selected?.commands.filter((name) => definitions.has(name)).map((name) => {
    const definition = definitions.get(name);
    const subcommands = (definition.options ?? []).filter((option) => option.type === 1 || option.type === 2);
    const choices = subcommands.length ? `\n  ↳ ${subcommands.map((option) => `\`${option.name}\``).join(" · ")}` : "";
    return `\`/${name}\` — ${definition.description}${choices}`;
  });
  const embed = new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle(selected ? `${selected.emoji} ${selected.label}` : "Multibot Help")
    .setDescription(selected ? lines.join("\n\n") || "No commands in this category." : "Choose a category below to see its commands.")
    .addFields({ name: "Links", value: createHelpLinks() })
    .setFooter({ text: "Choose another category from the menu at any time." });
  return embed;
}

export function createHelpComponents(ownerId) {
  if (typeof ownerId !== "string" || !ownerId) throw new TypeError("A help menu owner is required.");
  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId(helpSelectCustomId)
    .setPlaceholder("Select a category")
    .addOptions(
      ...Object.entries(getHelpCategories()).map(([value, category]) => ({
        label: category.label,
        value,
        emoji: category.emoji,
      }))
    );
  const buttons = [
    new ButtonBuilder()
      .setLabel("Support")
      .setStyle(ButtonStyle.Link)
      .setURL(helpSupportUrl),
  ];
  const inviteUrl = getBotInviteUrl();
  if (inviteUrl) {
    buttons.push(
      new ButtonBuilder()
        .setLabel("Invite Bot")
        .setStyle(ButtonStyle.Link)
        .setURL(inviteUrl)
    );
  }
  buttons.push(
    new ButtonBuilder()
      .setCustomId(`${helpCancelCustomId}${ownerId}`)
      .setLabel("Cancel")
      .setStyle(ButtonStyle.Danger)
  );
  return [
    new ActionRowBuilder().addComponents(selectMenu),
    new ActionRowBuilder().addComponents(buttons),
  ];
}

const help = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("Browse Multibot commands by category"),
  async execute(interaction) {
    return interaction.reply({
      embeds: [createHelpEmbed()],
      components: createHelpComponents(interaction.user.id),
      ephemeral: false,
    });
  },
};

export async function handleHelpSelect(interaction) {
  const category = interaction.values[0];
  if (!Object.hasOwn(getHelpCategories(), category)) {
    return interaction.reply({ content: "That help category is not available.", ephemeral: false });
  }
  const cancelButton = interaction.message.components
    .flatMap((row) => row.components)
    .find((component) => component.customId?.startsWith(helpCancelCustomId));
  const ownerId = cancelButton?.customId.slice(helpCancelCustomId.length) ||
    interaction.message.interactionMetadata?.user?.id ||
    interaction.message.interaction?.user?.id ||
    interaction.user.id;
  return interaction.update({
    embeds: [createHelpEmbed(category)],
    components: createHelpComponents(ownerId),
  });
}

export async function handleHelpCancel(interaction) {
  const ownerId = interaction.customId.slice(helpCancelCustomId.length);
  if (!ownerId || interaction.user.id !== ownerId) {
    return interaction.reply({ content: "Only the person who opened this help menu can cancel it.", ephemeral: true });
  }
  await interaction.deferUpdate();
  await interaction.message.delete();
}

export async function handleHelpMention(message, botId) {
  if (!message.guild || message.author.bot || !message.mentions.users.has(botId) ||
      (!message.content.includes(`<@${botId}>`) && !message.content.includes(`<@!${botId}>`))) return false;
  await message.reply({
    embeds: [createHelpEmbed()],
    components: createHelpComponents(message.author.id),
    allowedMentions: { parse: [], repliedUser: false },
  });
  return true;
}

const level = {
  data: new SlashCommandBuilder()
    .setName("level")
    .setDescription("Check your level or another member's level")
    .addUserOption((option) =>
      option.setName("user").setDescription("Member to check (defaults to you)")
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    const user = interaction.options.getUser("user") ?? interaction.user;
    const progress = await getUserLevel(interaction.guild.id, user.id);
    return interaction.reply(
      `📈 **${user.username} — Level ${progress.level}**\n${progress.currentXp}/${progress.nextLevelXp} XP to level ${progress.level + 1} (${progress.totalXp} total XP).`
    );
  },
};

const leaderboard = {
  data: new SlashCommandBuilder().setName("leaderboard").setDescription("Show the top 10 active members by level"),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }

    await interaction.deferReply();
    const activeUserIds = new Set();
    let after;
    while (true) {
      const members = await interaction.guild.members.list({ limit: 1000, after });
      for (const [userId] of members) activeUserIds.add(userId);
      if (members.size < 1000) break;
      after = members.last().id;
    }

    const entries = await getLeaderboard(interaction.guild.id, activeUserIds, 10);
    if (entries.length === 0) {
      return interaction.editReply("📈 No levels yet. Send messages to start earning XP!");
    }

    const rows = entries.map((entry, index) =>
      `**${index + 1}.** <@${entry.userId}> — Level **${entry.level}** (${entry.totalXp} XP)`
    );
    return interaction.editReply({
      content: `🏆 **${interaction.guild.name} Level Leaderboard**\n${rows.join("\n")}`,
      allowedMentions: { parse: [] },
    });
  },
};

const syncCheck = {
  data: new SlashCommandBuilder()
    .setName("sync-check")
    .setDescription("Verify the bot is running the SFTP sync-check build"),
  async execute(interaction) {
    const processStartedAt = new Date(Date.now() - process.uptime() * 1000);
    const embed = new EmbedBuilder()
      .setColor(0x57f287)
      .setTitle("SFTP Sync Check")
      .setDescription("✅ This server is running the sync-check build.")
      .addFields(
        { name: "Build marker", value: "`mc-sftp-sync-check-20261114-a7f3`", inline: true },
        { name: "Bot process started", value: `<t:${Math.floor(processStartedAt.getTime() / 1000)}:F>`, inline: true },
        { name: "Checked at", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
      )
      .setFooter({ text: `Runtime ${process.version}` });
    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

function formatUptime(totalSeconds) {
  let remaining = Math.floor(totalSeconds);
  const days = Math.floor(remaining / 86_400);
  remaining %= 86_400;
  const hours = Math.floor(remaining / 3_600);
  remaining %= 3_600;
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;

  return [
    days ? `${days}d` : null,
    hours ? `${hours}h` : null,
    minutes ? `${minutes}m` : null,
    `${seconds}s`,
  ].filter(Boolean).join(" ");
}

const version = {
  data: new SlashCommandBuilder()
    .setName("version")
    .setDescription("Show the bot version"),
  async execute(interaction) {
    const { version: fullVersion } = getBotVersionInfo();
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle("Bot Version")
      .setDescription(`**${fullVersion}**`);
    return interaction.reply({ embeds: [embed] });
  },
};

const ping = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Check the bot response time and Discord gateway latency"),
  async execute(interaction) {
    const responseMs = Math.max(0, Date.now() - interaction.createdTimestamp);
    const gatewayPing = interaction.client.ws.ping;
    const gatewayValue = Number.isFinite(gatewayPing) && gatewayPing >= 0
      ? `${Math.round(gatewayPing)} ms`
      : "Unavailable";
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle("🏓 Pong!")
      .addFields(
        { name: "Response time", value: `${responseMs} ms`, inline: true },
        { name: "Discord gateway", value: gatewayValue, inline: true }
      );
    return interaction.reply({ embeds: [embed] });
  },
};

const uptime = {
  data: new SlashCommandBuilder()
    .setName("uptime")
    .setDescription("Show how long the bot has been running"),
  async execute(interaction) {
    const startedAt = Math.floor(Date.now() / 1000 - process.uptime());
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle("Bot uptime")
      .setDescription(`⏱️ **${formatUptime(process.uptime())}**`)
      .addFields({ name: "Started", value: `<t:${startedAt}:F> (<t:${startedAt}:R>)` });
    return interaction.reply({ embeds: [embed] });
  },
};

const levelReset = {
  data: new SlashCommandBuilder()
    .setName("level-reset")
    .setDescription("Reset a member's level and XP (administrator only)")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addUserOption((option) =>
      option.setName("user").setDescription("Member whose level to reset").setRequired(true)
    ),
  async execute(interaction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command only works in a server.", ephemeral: true });
    }
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: "Only server administrators can reset levels.", ephemeral: true });
    }

    const user = interaction.options.getUser("user", true);
    await resetUserLevel(interaction.guild.id, user.id);
    return interaction.reply({ content: `✅ Reset <@${user.id}>'s level and XP.`, allowedMentions: { parse: [] } });
  },
};

export function createBotPresenceCommand(updatePresence = setBotPresence) {
  return {
    data: new SlashCommandBuilder()
      .setName("bot-presence")
      .setDescription("Set the bot's visible status and activity text (bot owner only)")
      .addStringOption((option) =>
        option
          .setName("status")
          .setDescription("The status to show")
          .setRequired(true)
          .addChoices(
            { name: "Online", value: "online" },
            { name: "Idle", value: "idle" },
            { name: "Do Not Disturb", value: "dnd" },
            { name: "Invisible", value: "invisible" }
          )
      )
      .addStringOption((option) =>
        option
          .setName("text")
          .setDescription("Optional activity text; Watching when counts are enabled")
          .setMaxLength(128)
      )
      .addBooleanOption((option) =>
        option
          .setName("server_count")
          .setDescription("Show people and server counts in a Watching activity")
      ),
    async execute(interaction) {
      const ownerId = process.env.BOT_OWNER_ID;
      if (!ownerId) throw new Error("Set BOT_OWNER_ID in .env to enable the owner-only presence command.");
      if (interaction.user.id !== ownerId) {
        return interaction.reply({ content: "Only the configured bot owner can change my presence.", ephemeral: true });
      }

      const status = interaction.options.getString("status", true);
      const text = interaction.options.getString("text")?.trim() ?? "";
      const serverCount = interaction.options.getBoolean("server_count") ?? false;
      const activity = await updatePresence(interaction.client, { status, text, serverCount });
      return interaction.reply({
        content: `✅ Bot presence set to **${status}**${activity ? ` · ${serverCount ? "Watching" : "Playing"} **${activity}**` : " · No activity"}.`,
        allowedMentions: { parse: [] },
      });
    },
  };
}

const botPresence = createBotPresenceCommand();

export const commands = [
  kick, ban, warn, hackban, timeout, purge,
  modlog,
  eightBall, coinflip, rps, wouldYouRather, truthOrDare,
  trivia, numberGuess, riddle, emojiQuiz, ai, aiChannel,
  welcome, giveaway,
  balance, daily, gamble, slots,
  level, leaderboard, syncCheck, version, ping, uptime, levelReset,
  postEmbed, editEmbed, poll, suggest, serverInfo, userInfo, channelInfo, roleInfo, help, botPresence,
];
