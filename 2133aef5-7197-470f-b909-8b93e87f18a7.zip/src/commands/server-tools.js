import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
} from "discord.js";
import {
  addBlockedWord,
  getAutomodConfig,
  removeBlockedWord,
  updateAutomodConfig,
} from "../features/automod.js";
import {
  reactionRoleCustomId,
  isSafeReactionRole,
  removeReactionRole,
  saveReactionRole,
  setTicketStaffRole,
  ticketOpenCustomId,
} from "../features/interactive.js";
import {
  clearStickyMessage,
  setStickyMessage,
  setStickyMessageId,
} from "../features/sticky.js";
import {
  getAuditLogSettings,
  setAuditLogChannel,
  setAuditLogEnabled,
  setAuditLogMode,
} from "../features/moderation.js";
import { logsSetupMenu } from "../features/logs-menu.js";
import {
  getLevelRoleRewards,
  removeLevelRoleReward,
  setLevelRoleReward,
} from "../features/level-rewards.js";
import { addReactionRole, emojiKey, removeReactionAssignments } from "../features/reaction-roles.js";
import { builderMenu } from "../features/server-builder.js";
import { resolveTargetChannel, targetChannelOption } from "./channels.js";

function requireGuild(interaction) {
  if (!interaction.guild) throw new Error("This command can only be used in a server.");
  return interaction.guild;
}

function isSendableTextChannel(channel) {
  return channel?.isTextBased() && typeof channel.send === "function";
}

const announcementCommand = {
  data: new SlashCommandBuilder()
    .setName("announcement")
    .setDescription("Post a formatted server announcement")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addSubcommand((subcommand) =>
      subcommand
        .setName("post")
        .setDescription("Post an announcement embed")
        .addStringOption((option) => option.setName("title").setDescription("Announcement title").setMaxLength(200).setRequired(true))
        .addStringOption((option) => option.setName("message").setDescription("Announcement text").setMaxLength(3500).setRequired(true))
        .addChannelOption((option) =>
          option
            .setName("channel")
            .setDescription("Where to post; defaults to this channel")
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        )
    ),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages)) {
      await interaction.reply({ content: "You need Manage Messages to post announcements.", ephemeral: true });
      return;
    }
    const channel = interaction.options.getChannel("channel") ?? interaction.channel;
    if (!isSendableTextChannel(channel)) {
      await interaction.reply({ content: "Choose a text or announcement channel.", ephemeral: true });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(interaction.options.getString("title", true))
      .setDescription(interaction.options.getString("message", true))
      .setFooter({ text: `Announcement · ${guild.name}` })
      .setTimestamp();
    await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
    await interaction.reply({ content: `Announcement posted in ${channel}.`, ephemeral: true });
  },
};

const automodCommand = {
  data: new SlashCommandBuilder()
    .setName("automod")
    .setDescription("Configure automatic removal of invite links and blocked words")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((subcommand) => subcommand.setName("enable").setDescription("Enable automatic moderation"))
    .addSubcommand((subcommand) => subcommand.setName("disable").setDescription("Disable automatic moderation"))
    .addSubcommand((subcommand) =>
      subcommand
        .setName("links")
        .setDescription("Choose whether invite links are blocked")
        .addStringOption((option) =>
          option
            .setName("action")
            .setDescription("Allow or block Discord invite links")
            .setRequired(true)
            .addChoices(
              { name: "Block", value: "block" },
              { name: "Allow", value: "allow" }
            )
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("word-add")
        .setDescription("Add a blocked word")
        .addStringOption((option) => option.setName("word").setDescription("Word or phrase to block").setMinLength(1).setMaxLength(50).setRequired(true))
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("word-remove")
        .setDescription("Remove a blocked word")
        .addStringOption((option) => option.setName("word").setDescription("Word or phrase to remove").setMinLength(1).setMaxLength(50).setRequired(true))
    )
    .addSubcommand((subcommand) => subcommand.setName("status").setDescription("Show the current automod configuration")),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      await interaction.reply({ content: "You need Manage Server to configure automod.", ephemeral: true });
      return;
    }
    const action = interaction.options.getSubcommand();
    if (action === "enable" || action === "disable") {
      await updateAutomodConfig(guild.id, { enabled: action === "enable" });
      await interaction.reply({ content: `Automatic moderation is now **${action === "enable" ? "enabled" : "disabled"}**.`, ephemeral: true });
      return;
    }

    if (action === "links") {
      const blockInvites = interaction.options.getString("action", true) === "block";
      await updateAutomodConfig(guild.id, { blockInvites });
      await interaction.reply({ content: `Discord invite links will be **${blockInvites ? "blocked" : "allowed"}**.`, ephemeral: true });
      return;
    }

    if (action === "word-add") {
      const word = interaction.options.getString("word", true).trim();
      if (!word) {
        await interaction.reply({ content: "Enter a non-empty word or phrase.", ephemeral: true });
        return;
      }
      const added = await addBlockedWord(guild.id, word);
      await interaction.reply({
        content: added ? "Blocked word added." : "That word is already blocked or the 50-word limit has been reached.",
        ephemeral: true,
      });
      return;
    }

    if (action === "word-remove") {
      const word = interaction.options.getString("word", true).trim();
      if (!word) {
        await interaction.reply({ content: "Enter the word or phrase to remove.", ephemeral: true });
        return;
      }
      const removed = await removeBlockedWord(guild.id, word);
      await interaction.reply({ content: removed ? "Blocked word removed." : "That word wasn't in the block list.", ephemeral: true });
      return;
    }

    const config = await getAutomodConfig(guild.id);
    const words = config.blockedWords.length
      ? `${config.blockedWords.slice(0, 20).join(", ")}${config.blockedWords.length > 20 ? `, and ${config.blockedWords.length - 20} more` : ""}`
      : "none";
    await interaction.reply({
      content: `**Automod:** ${config.enabled ? "enabled" : "disabled"}\n**Invite links:** ${config.blockInvites ? "blocked" : "allowed"}\n**Blocked words:** ${words}`,
      ephemeral: true,
    });
  },
};

export function createLogsCommand(logStore = {
  getAuditLogSettings,
  setAuditLogChannel,
  setAuditLogEnabled,
  setAuditLogMode,
}) {
  return {
    data: new SlashCommandBuilder()
      .setName("logs")
      .setDescription("Configure the server's moderation and event log channel")
      .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
      .addSubcommand((subcommand) =>
        subcommand.setName("setup").setDescription("Open the modlogs setup and module toggle")
      )
      .addSubcommand((subcommand) =>
        subcommand
          .setName("channel")
          .setDescription("Set the channel where moderation and server events are logged")
          .addChannelOption((option) =>
            option
              .setName("channel")
              .setDescription("Text channel for audit logs")
              .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
              .setRequired(true)
          )
      )
      .addSubcommand((subcommand) =>
        subcommand.setName("disable").setDescription("Disable automatic audit logging")
      )
      .addSubcommand((subcommand) =>
        subcommand
          .setName("mode")
          .setDescription("Choose standard logs or full Discord audit-log events")
          .addStringOption((option) =>
            option.setName("level").setDescription("Logging detail").setRequired(true)
              .addChoices({ name: "Standard", value: "standard" }, { name: "Full", value: "full" })
          )
      )
      .addSubcommand((subcommand) =>
        subcommand.setName("status").setDescription("Show the current audit-log channel")
      ),
    async execute(interaction) {
      const guild = requireGuild(interaction);
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
        await interaction.reply({ content: "You need Manage Server to configure audit logging.", ephemeral: true });
        return;
      }

      const action = interaction.options.getSubcommand();
      if (action === "setup") {
        const settings = await logStore.getAuditLogSettings(guild.id);
        await interaction.reply({ ...logsSetupMenu(interaction.user.id, settings), ephemeral: true });
        return;
      }
      if (action === "channel") {
        const channel = interaction.options.getChannel("channel", true);
        const settings = await logStore.getAuditLogSettings(guild.id);
        if (settings.mode === "full" && !interaction.memberPermissions.has(PermissionFlagsBits.ViewAuditLog)) {
          await interaction.reply({ content: "You also need View Audit Log to change the channel while full logging is enabled.", ephemeral: true });
          return;
        }
        const botMember = guild.members.me;
        if (settings.mode === "full" && !botMember?.permissions.has(PermissionFlagsBits.ViewAuditLog)) {
          await interaction.reply({ content: "I need View Audit Log to use the channel in full mode. Grant it or switch to Standard in `/logs setup`.", ephemeral: true });
          return;
        }
        const permissions = botMember && channel.permissionsFor(botMember);
        if (!permissions?.has([
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.EmbedLinks,
        ])) {
          await interaction.reply({
            content: "I need View Channel, Send Messages, and Embed Links permissions in that channel.",
            ephemeral: true,
          });
          return;
        }

        await logStore.setAuditLogChannel(guild.id, channel.id);
        await interaction.reply({ content: `Audit logs will be sent to ${channel}. Use a private channel: logs can contain messages from private channels.`, ephemeral: true });
        return;
      }

      if (action === "mode") {
        const mode = interaction.options.getString("level", true);
        if (!["standard", "full"].includes(mode)) {
          await interaction.reply({ content: "Choose standard or full logging.", ephemeral: true });
          return;
        }
        if (mode === "full") {
          if (!interaction.memberPermissions.has(PermissionFlagsBits.ViewAuditLog)) {
            await interaction.reply({ content: "You also need View Audit Log to enable full logging.", ephemeral: true });
            return;
          }
          if (!guild.members.me?.permissions.has(PermissionFlagsBits.ViewAuditLog)) {
            await interaction.reply({ content: "I need the View Audit Log permission to enable full logging.", ephemeral: true });
            return;
          }
          if (!(await logStore.getAuditLogSettings(guild.id)).channelId) {
            await interaction.reply({ content: "First choose a private log channel with `/logs channel`.", ephemeral: true });
            return;
          }
        }
        await logStore.setAuditLogMode(guild.id, mode);
        const settings = await logStore.getAuditLogSettings(guild.id);
        await interaction.reply({
          content: !settings.enabled
            ? `${mode === "full" ? "Full" : "Standard"} mode saved. Modlogs are disabled; use \`/logs setup\` to enable them.`
            : mode === "full"
              ? "Full logging enabled. Discord audit events will be logged alongside standard events; some actions may appear twice."
              : "Standard logging enabled. Discord audit-entry details are no longer logged.",
          ephemeral: true,
        });
        return;
      }

      if (action === "disable") {
        await logStore.setAuditLogEnabled(guild.id, false);
        await interaction.reply({ content: "Modlogs are disabled. The channel and mode are saved; use `/logs setup` to enable them again.", ephemeral: true });
        return;
      }

      const { channelId, mode, enabled } = await logStore.getAuditLogSettings(guild.id);
      const missingAuditPermission = mode === "full" && !guild.members.me?.permissions.has(PermissionFlagsBits.ViewAuditLog);
      await interaction.reply({
        content: enabled
          ? `Audit logs are enabled in <#${channelId}>. Mode: **${mode}**.${missingAuditPermission ? " I need View Audit Log to receive full audit events." : ""}`
          : `Audit logging is disabled. Saved channel: ${channelId ? `<#${channelId}>` : "none"}. Saved mode: **${mode}**. Use \`/logs setup\` to configure or enable it.`,
        ephemeral: true,
      });
    },
  };
}

const logsCommand = createLogsCommand();

const levelRewardCommand = {
  data: new SlashCommandBuilder()
    .setName("level-reward")
    .setDescription("Configure roles awarded at level milestones")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand((subcommand) =>
      subcommand
        .setName("set")
        .setDescription("Set the role awarded when a member reaches a level")
        .addIntegerOption((option) =>
          option.setName("level").setDescription("Level milestone").setMinValue(1).setMaxValue(1000).setRequired(true)
        )
        .addRoleOption((option) =>
          option.setName("role").setDescription("Role awarded at this milestone").setRequired(true)
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("remove")
        .setDescription("Remove a level milestone reward")
        .addIntegerOption((option) =>
          option.setName("level").setDescription("Milestone to remove").setMinValue(1).setMaxValue(1000).setRequired(true)
        )
    )
    .addSubcommand((subcommand) =>
      subcommand.setName("list").setDescription("List configured level rewards")
    ),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageRoles)) {
      await interaction.reply({ content: "You need Manage Roles to configure level rewards.", ephemeral: true });
      return;
    }
    const action = interaction.options.getSubcommand();
    if (action === "set") {
      const level = interaction.options.getInteger("level", true);
      const role = interaction.options.getRole("role", true);
      if (!role.editable) {
        await interaction.reply({
          content: "I can't assign that role. Make sure it isn't managed and is below my highest role.",
          ephemeral: true,
        });
        return;
      }
      await setLevelRoleReward(guild.id, level, role.id);
      await interaction.reply({
        content: `Members who reach level **${level}** will receive ${role}. Reaching a later milestone replaces the previous reward role.`,
        ephemeral: true,
      });
      return;
    }

    if (action === "remove") {
      const level = interaction.options.getInteger("level", true);
      const removed = await removeLevelRoleReward(guild.id, level);
      await interaction.reply({
        content: removed ? `Removed the level ${level} reward.` : `No reward is configured for level ${level}.`,
        ephemeral: true,
      });
      return;
    }

    const rewards = await getLevelRoleRewards(guild.id);
    await interaction.reply({
      content: rewards.length
        ? rewards.map(({ level, roleId }) => `Level **${level}** → <@&${roleId}>`).join("\n")
        : "No level rewards are configured yet.",
      allowedMentions: { parse: [] },
      ephemeral: true,
    });
  },
};

const autosetupCommand = {
  data: new SlashCommandBuilder()
    .setName("autosetup")
    .setDescription("Create a starter set of public community channels")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand((subcommand) => subcommand.setName("preview").setDescription("Preview the channels that will be created"))
    .addSubcommand((subcommand) => subcommand.setName("create").setDescription("Create missing starter channels")),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    const names = ["announcements", "suggestions", "support"];
    if (interaction.options.getSubcommand() === "preview") {
      await interaction.reply({
        content: `Autosetup will create a **Multibot Community** category with: ${names.map((name) => `#${name}`).join(", ")}. Existing channels with those names under the category are kept.`,
        ephemeral: true,
      });
      return;
    }

    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) {
      await interaction.reply({ content: "You need Manage Channels to create the starter channels.", ephemeral: true });
      return;
    }
    const botMember = guild.members.me;
    if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      await interaction.reply({ content: "I need Manage Channels to create the starter channels.", ephemeral: true });
      return;
    }
    let category = guild.channels.cache.find(
      (channel) => channel.type === ChannelType.GuildCategory && channel.name === "Multibot Community"
    );
    if (!category) {
      category = await guild.channels.create({
        name: "Multibot Community",
        type: ChannelType.GuildCategory,
        reason: `Community setup requested by ${interaction.user.tag}`,
      });
    }

    const created = [];
    for (const name of names) {
      const exists = guild.channels.cache.some(
        (channel) => channel.parentId === category.id && channel.name === name
      );
      if (exists) continue;
      const channel = await guild.channels.create({
        name,
        type: ChannelType.GuildText,
        parent: category.id,
        reason: `Community setup requested by ${interaction.user.tag}`,
      });
      created.push(channel.name);
    }
    const summary = created.length ? `Created: ${created.map((name) => `#${name}`).join(", ")}.` : "All starter channels already exist.";
    await interaction.reply({ content: summary, ephemeral: true });
  },
};

const serverBuilderCommand = {
  data: new SlashCommandBuilder()
    .setName("server-builder")
    .setDescription("Choose server categories and channels to create")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) {
      await interaction.reply({ content: "You need Manage Channels to use the server builder.", ephemeral: true });
      return;
    }
    await interaction.reply({
      content: `Choose categories for **${guild.name}** using the buttons below. Each adds 10 text channels and one general voice channel.`,
      components: builderMenu(interaction.user.id),
      allowedMentions: { parse: [] },
      ephemeral: true,
    });
  },
};

const messagesCommand = {
  data: new SlashCommandBuilder()
    .setName("messages")
    .setDescription("Send a bot message or lock and unlock a text channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages | PermissionFlagsBits.ManageChannels)
    .addSubcommand((subcommand) =>
      subcommand
        .setName("send")
        .setDescription("Send a message as the bot")
        .addStringOption((option) => option.setName("text").setDescription("Message to send").setMaxLength(1800).setRequired(true))
        .addChannelOption((option) =>
          option.setName("channel").setDescription("Target channel; defaults to this channel")
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("lock")
        .setDescription("Prevent @everyone from sending messages")
        .addChannelOption((option) =>
          option.setName("channel").setDescription("Channel to lock; defaults to this channel")
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("unlock")
        .setDescription("Remove the explicit @everyone send-message restriction")
        .addChannelOption((option) =>
          option.setName("channel").setDescription("Channel to unlock; defaults to this channel")
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        )
    ),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    const action = interaction.options.getSubcommand();
    const channel = interaction.options.getChannel("channel") ?? interaction.channel;
    if (!channel) throw new Error("The current channel is unavailable.");

    if (action === "send") {
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages)) {
        await interaction.reply({ content: "You need Manage Messages to send a bot message.", ephemeral: true });
        return;
      }
      if (!isSendableTextChannel(channel)) {
        await interaction.reply({ content: "Choose a text or announcement channel.", ephemeral: true });
        return;
      }
      await channel.send({
        content: interaction.options.getString("text", true),
        allowedMentions: { parse: [] },
      });
      await interaction.reply({ content: `Message sent in ${channel}.`, ephemeral: true });
      return;
    }

    if (![ChannelType.GuildText, ChannelType.GuildAnnouncement].includes(channel.type)) {
      await interaction.reply({ content: "Choose a standard text or announcement channel.", ephemeral: true });
      return;
    }
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) {
      await interaction.reply({ content: "You need Manage Channels to lock or unlock a channel.", ephemeral: true });
      return;
    }
    await channel.permissionOverwrites.edit(
      guild.roles.everyone,
      { SendMessages: action === "lock" ? false : null },
      { reason: `${action === "lock" ? "Locked" : "Unlocked"} by ${interaction.user.tag}` }
    );
    await interaction.reply({
      content: action === "lock" ? `Locked ${channel}.` : `Unlocked ${channel}.`,
      ephemeral: true,
    });
  },
};

export function createReactionRoleCommand(reactionStore = {
  addReactionRole, removeReactionAssignments, removeReactionRole, saveReactionRole,
}) {
  return {
  data: new SlashCommandBuilder()
    .setName("reaction-role")
    .setDescription("Configure reaction roles or a role-toggle button")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand((subcommand) =>
      subcommand
        .setName("post")
        .setDescription("Post a self-assignable role button")
        .addRoleOption((option) => option.setName("role").setDescription("Role members can toggle").setRequired(true))
        .addStringOption((option) => option.setName("label").setDescription("Button label").setMaxLength(80))
        .addChannelOption(targetChannelOption)
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("add")
        .setDescription("Add an emoji and role to a message")
        .addStringOption((option) => option.setName("message_id").setDescription("Message ID in the selected channel").setRequired(true))
        .addStringOption((option) => option.setName("emoji").setDescription("Unicode or custom Discord emoji").setRequired(true))
        .addRoleOption((option) => option.setName("role").setDescription("Role granted by this reaction").setRequired(true))
        .addChannelOption(targetChannelOption)
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("remove")
        .setDescription("Remove reaction roles or disable a role button")
        .addStringOption((option) => option.setName("message_id").setDescription("Message ID of the role panel").setRequired(true))
        .addStringOption((option) => option.setName("emoji").setDescription("Remove only this emoji mapping; omit to disable the whole panel"))
    ),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageRoles)) {
      await interaction.reply({ content: "You need Manage Roles to configure role panels.", ephemeral: true });
      return;
    }
    const action = interaction.options.getSubcommand();
    if (action === "remove") {
      const messageId = interaction.options.getString("message_id", true);
      if (!/^\d{17,20}$/.test(messageId)) {
        await interaction.reply({ content: "Enter a valid Discord message ID.", ephemeral: true });
        return;
      }
      const emojiInput = interaction.options.getString("emoji");
      const emoji = emojiInput ? emojiKey(emojiInput) : null;
      if (emojiInput && !emoji) {
        await interaction.reply({ content: "Enter a valid Unicode or custom Discord emoji.", ephemeral: true });
        return;
      }
      const reactions = await reactionStore.removeReactionAssignments(guild.id, messageId, emoji);
      const panel = emoji ? null : await reactionStore.removeReactionRole(guild.id, messageId);
      let response = panel || reactions ? "The selected role configuration has been disabled." : "No matching role configuration was found.";
      if (panel?.channelId) {
        const channel = guild.channels.cache.get(panel.channelId);
        if (!isSendableTextChannel(channel)) {
          response = "The role button is disabled, but its original channel is unavailable so I couldn't remove the button.";
        } else {
          try {
            const message = await channel.messages.fetch(messageId);
            await message.edit({ components: [] });
          } catch (error) {
            console.error(`Could not remove disabled role-panel button ${messageId}:`, error);
            response = "The role button is disabled, but I couldn't remove it from the original message. Check my channel permissions.";
          }
        }
      }
      await interaction.reply({ content: response, ephemeral: true });
      return;
    }

    const role = interaction.options.getRole("role", true);
    const target = await resolveTargetChannel(interaction, {
      memberPermissions: action === "add"
        ? [PermissionFlagsBits.ManageRoles, PermissionFlagsBits.ReadMessageHistory]
        : [PermissionFlagsBits.ManageRoles, PermissionFlagsBits.SendMessages],
      botPermissions: action === "add"
        ? [PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AddReactions]
        : [PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks],
    });
    if (target.error) {
      await interaction.reply({ content: target.error, ephemeral: true });
      return;
    }
    const channel = target.channel;
    if (action === "add") {
      const messageId = interaction.options.getString("message_id", true);
      const input = interaction.options.getString("emoji", true);
      const emoji = emojiKey(input);
      if (!/^\d{17,20}$/.test(messageId) || !emoji) {
        await interaction.reply({ content: "Enter a valid message ID and Unicode or custom Discord emoji.", ephemeral: true });
        return;
      }
      if (!channel?.messages || !role.editable || !isSafeReactionRole(role)) {
        await interaction.reply({ content: "Choose an accessible message and a role I can assign without server-management or moderation permissions.", ephemeral: true });
        return;
      }
      const member = await guild.members.fetch(interaction.user.id);
      if (guild.ownerId !== interaction.user.id && member.roles.highest.comparePositionTo(role) <= 0) {
        await interaction.reply({ content: "The role must be below your highest role.", ephemeral: true });
        return;
      }
      await interaction.deferReply({ ephemeral: true });
      const message = await channel.messages.fetch(messageId);
      const conflict = await reactionStore.addReactionRole(guild.id, messageId, channel.id, emoji, role.id);
      if (conflict) {
        await interaction.editReply(conflict === "emoji" ? "That emoji already has a role on this message. Remove it first." : "That role already has an emoji on this message.");
        return;
      }
      try {
        await message.react(input);
      } catch (error) {
        try {
          await reactionStore.removeReactionAssignments(guild.id, messageId, emoji);
        } catch (cleanupError) {
          console.error(`Could not remove failed reaction-role configuration ${messageId}:`, cleanupError);
        }
        throw error;
      }
      await interaction.editReply({ content: `Reaction role added to ${message.url}. Members can add or remove the reaction to toggle the role.`, allowedMentions: { parse: [] } });
      return;
    }
    if (!isSendableTextChannel(channel)) {
      await interaction.reply({ content: "Run this command in a text channel where I can post.", ephemeral: true });
      return;
    }
    if (!role.editable) {
      await interaction.reply({ content: "I can't assign that role. Move my role above it and enable Manage Roles.", ephemeral: true });
      return;
    }
    if (!isSafeReactionRole(role)) {
      await interaction.reply({
        content: "Self-assignable panels can't grant roles with server-management or moderation permissions.",
        ephemeral: true,
      });
      return;
    }

    const message = await channel.send({
      embeds: [new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle("Choose a role")
        .setDescription(`Press the button below to toggle the **${role.name}** role.`)],
      allowedMentions: { parse: [] },
    });
    try {
      await reactionStore.saveReactionRole(guild.id, message.id, role.id, channel.id);
      await message.edit({
        components: [new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId(reactionRoleCustomId(message.id))
            .setLabel(interaction.options.getString("label") ?? role.name)
            .setStyle(ButtonStyle.Primary)
        )],
      });
    } catch (error) {
      try {
        await reactionStore.removeReactionRole(guild.id, message.id);
      } catch (cleanupError) {
        console.error(`Could not remove failed role-panel configuration ${message.id}:`, cleanupError);
      }
      try {
        await message.delete();
      } catch (cleanupError) {
        console.error(`Could not delete failed role-panel message ${message.id}:`, cleanupError);
      }
      throw error;
    }
    await interaction.reply({ content: `Role panel posted: ${message.url}`, ephemeral: true });
  },
  };
}

const reactionRoleCommand = createReactionRoleCommand();

const serverStatsCommand = {
  data: new SlashCommandBuilder()
    .setName("server-stats")
    .setDescription("Show member, channel, and role counts for this server"),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    const textChannels = guild.channels.cache.filter((channel) =>
      [ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildForum].includes(channel.type)
    ).size;
    const voiceChannels = guild.channels.cache.filter((channel) =>
      [ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)
    ).size;
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle(`${guild.name} · Server stats`)
      .addFields(
        { name: "Members", value: String(guild.memberCount), inline: true },
        { name: "Text channels", value: String(textChannels), inline: true },
        { name: "Voice channels", value: String(voiceChannels), inline: true },
        { name: "Roles", value: String(guild.roles.cache.size), inline: true },
        { name: "Boost level", value: String(guild.premiumTier), inline: true },
        { name: "Created", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true }
      );
    const iconUrl = guild.iconURL({ size: 256 });
    if (iconUrl) embed.setThumbnail(iconUrl);
    await interaction.reply({ embeds: [embed] });
  },
};

export function createStickyCommand(stickyStore = { setStickyMessage, setStickyMessageId, clearStickyMessage }) {
  return {
  data: new SlashCommandBuilder()
    .setName("sticky")
    .setDescription("Keep a message pinned to the bottom of a text channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addSubcommand((subcommand) =>
      subcommand
        .setName("set")
        .setDescription("Set or replace the channel's sticky message")
        .addStringOption((option) => option.setName("message").setDescription("Sticky text").setMaxLength(1800).setRequired(true))
        .addChannelOption(targetChannelOption)
    )
    .addSubcommand((subcommand) =>
      subcommand.setName("clear").setDescription("Remove a channel's sticky message").addChannelOption(targetChannelOption)
    ),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageMessages)) {
      await interaction.reply({ content: "You need Manage Messages to configure sticky messages.", ephemeral: true });
      return;
    }
    const action = interaction.options.getSubcommand();
    const target = await resolveTargetChannel(interaction, {
      memberPermissions: [
        PermissionFlagsBits.ManageMessages,
        ...(action === "set" ? [PermissionFlagsBits.SendMessages] : []),
      ],
      botPermissions: [
        PermissionFlagsBits.ReadMessageHistory,
        ...(action === "set" ? [PermissionFlagsBits.SendMessages] : []),
      ],
    });
    if (target.error) {
      await interaction.reply({ content: target.error, ephemeral: true });
      return;
    }
    const channel = target.channel;
    if (!isSendableTextChannel(channel)) {
      await interaction.reply({ content: "Choose a text channel.", ephemeral: true });
      return;
    }
    if (action === "set") {
      const content = interaction.options.getString("message", true).trim();
      if (!content) {
        await interaction.reply({ content: "The sticky message can't be empty.", ephemeral: true });
        return;
      }
      const previous = await stickyStore.setStickyMessage(guild.id, channel.id, content);
      let posted;
      if (previous?.messageId) {
        try {
          posted = await channel.messages.fetch(previous.messageId);
          await posted.edit({ content, allowedMentions: { parse: [] } });
        } catch (error) {
          if (error.code !== 10008) throw error;
        }
      }
      if (!posted) {
        posted = await channel.send({ content, allowedMentions: { parse: [] } });
      }
      await stickyStore.setStickyMessageId(guild.id, channel.id, posted.id);
      await interaction.reply({ content: `Sticky message saved in ${channel}. It will move to the bottom when new messages arrive.`, ephemeral: true });
      return;
    }

    const cleared = await stickyStore.clearStickyMessage(guild.id, channel.id);
    let response = cleared ? "Sticky message cleared." : "There isn't a sticky message in that channel.";
    if (cleared?.messageId) {
      try {
        await channel.messages.delete(cleared.messageId);
      } catch (error) {
        if (error.code !== 10008) {
          console.error(`Could not delete cleared sticky message ${cleared.messageId}:`, error);
          response = "Sticky settings were cleared, but I couldn't remove the old message. Check my channel permissions.";
        }
      }
    }
    await interaction.reply({
      content: response,
      ephemeral: true,
    });
  },
  };
}

const stickyCommand = createStickyCommand();

const ticketsCommand = {
  data: new SlashCommandBuilder()
    .setName("tickets")
    .setDescription("Set up private support tickets and post the ticket button")
    .addSubcommand((subcommand) =>
      subcommand
        .setName("setup")
        .setDescription("Choose the staff role that can view tickets")
        .addRoleOption((option) => option.setName("staff_role").setDescription("Role allowed into support tickets").setRequired(true))
    )
    .addSubcommand((subcommand) =>
      subcommand.setName("panel").setDescription("Post a button to open a support ticket").addChannelOption(targetChannelOption)
    ),
  async execute(interaction) {
    const guild = requireGuild(interaction);
    const action = interaction.options.getSubcommand();
    if (action === "setup") {
      if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) {
        await interaction.reply({ content: "You need Manage Channels to configure tickets.", ephemeral: true });
        return;
      }
      const role = interaction.options.getRole("staff_role", true);
      if (role.id === guild.id) {
        await interaction.reply({ content: "The @everyone role can't be used as the ticket staff role.", ephemeral: true });
        return;
      }
      await setTicketStaffRole(guild.id, role.id);
      await interaction.reply({ content: `Ticket staff role set to **${role.name}**.`, ephemeral: true });
      return;
    }

    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) {
      await interaction.reply({ content: "You need Manage Channels to post a ticket panel.", ephemeral: true });
      return;
    }
    const target = await resolveTargetChannel(interaction, {
      memberPermissions: [PermissionFlagsBits.ManageChannels],
      botPermissions: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks],
    });
    if (target.error) {
      await interaction.reply({ content: target.error, ephemeral: true });
      return;
    }
    const channel = target.channel;
    if (!isSendableTextChannel(channel)) {
      await interaction.reply({ content: "Choose a text channel where I can post.", ephemeral: true });
      return;
    }
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(ticketOpenCustomId)
        .setLabel("Open a support ticket")
        .setStyle(ButtonStyle.Primary)
    );
    await channel.send({
      embeds: [new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle("Need help?")
        .setDescription("Press the button to open a private support ticket.")],
      components: [row],
      allowedMentions: { parse: [] },
    });
    await interaction.reply({ content: `Ticket panel posted in ${channel}.`, ephemeral: true });
  },
};

const toolsCommand = {
  data: new SlashCommandBuilder()
    .setName("tools")
    .setDescription("Small server utilities")
    .addSubcommand((subcommand) =>
      subcommand
        .setName("avatar")
        .setDescription("Show a member's avatar")
        .addUserOption((option) => option.setName("user").setDescription("Member; defaults to you"))
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("choose")
        .setDescription("Pick one of several options at random")
        .addStringOption((option) => option.setName("options").setDescription("Separate 2–20 choices with | or commas").setMaxLength(1000).setRequired(true))
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("timestamp")
        .setDescription("Format a date as Discord timestamps")
        .addStringOption((option) => option.setName("date").setDescription("ISO date/time with timezone, such as 2025-01-30T18:00:00Z").setMaxLength(40).setRequired(true))
    ),
  async execute(interaction) {
    const action = interaction.options.getSubcommand();
    if (action === "avatar") {
      const user = interaction.options.getUser("user") ?? interaction.user;
      const embed = new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle(`${user.username}'s avatar`)
        .setImage(user.displayAvatarURL({ size: 1024 }));
      await interaction.reply({ embeds: [embed] });
      return;
    }

    if (action === "choose") {
      const choices = interaction.options.getString("options", true)
        .split(/\s*[|,]\s*/)
        .map((choice) => choice.trim())
        .filter(Boolean);
      if (choices.length < 2 || choices.length > 20) {
        await interaction.reply({ content: "Enter 2–20 non-empty choices separated by `|` or commas.", ephemeral: true });
        return;
      }
      const choice = choices[Math.floor(Math.random() * choices.length)];
      await interaction.reply({ content: `I choose: **${choice}**`, allowedMentions: { parse: [] } });
      return;
    }

    const input = interaction.options.getString("date", true);
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2})$/i.test(input)) {
      await interaction.reply({ content: "Include a timezone offset, for example `2025-01-30T18:00:00Z`.", ephemeral: true });
      return;
    }
    const calendarDate = new Date(`${input.slice(0, 10)}T00:00:00Z`);
    if (!Number.isFinite(calendarDate.getTime()) || calendarDate.toISOString().slice(0, 10) !== input.slice(0, 10)) {
      await interaction.reply({ content: "That isn't a valid calendar date.", ephemeral: true });
      return;
    }
    const timestamp = Date.parse(input);
    if (!Number.isFinite(timestamp)) {
      await interaction.reply({ content: "That isn't a valid date and time.", ephemeral: true });
      return;
    }
    const unix = Math.floor(timestamp / 1000);
    await interaction.reply({
      content: [
        `Short time: <t:${unix}:t>`,
        `Long time: <t:${unix}:T>`,
        `Short date: <t:${unix}:d>`,
        `Long date: <t:${unix}:D>`,
        `Date and time: <t:${unix}:f>`,
        `Relative: <t:${unix}:R>`,
      ].join("\n"),
      allowedMentions: { parse: [] },
    });
  },
};

export const commands = [
  announcementCommand,
  automodCommand,
  logsCommand,
  levelRewardCommand,
  autosetupCommand,
  serverBuilderCommand,
  messagesCommand,
  reactionRoleCommand,
  serverStatsCommand,
  stickyCommand,
  ticketsCommand,
  toolsCommand,
];
