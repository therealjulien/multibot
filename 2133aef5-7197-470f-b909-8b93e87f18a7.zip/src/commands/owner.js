import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";
import { SlashCommandBuilder } from "discord.js";
import { requestServerRestart } from "../server-control.js";

const execFileAsync = promisify(execFile);
const projectRoot = fileURLToPath(new URL("../../", import.meta.url));

async function runNpm(args) {
  const npmExecutable = process.platform === "win32" ? "npm.cmd" : "npm";
  return execFileAsync(npmExecutable, args, {
    cwd: projectRoot,
    maxBuffer: 1024 * 1024,
    shell: process.platform === "win32",
    timeout: 120_000,
    windowsHide: true,
  });
}

const actionLabels = {
  deploy: "npm run deploy",
  "npm-restart": "npm restart",
  "server-restart": "server restart",
};

export const botMaintenance = {
  data: new SlashCommandBuilder()
    .setName("bot-maintenance")
    .setDescription("Run a fixed bot maintenance action (bot owner only)")
    .addStringOption((option) =>
      option
        .setName("action")
        .setDescription("The maintenance action to run")
        .setRequired(true)
        .addChoices(
          { name: "Deploy slash commands", value: "deploy" },
          { name: "Run npm restart", value: "npm-restart" },
          { name: "Restart the hosted server", value: "server-restart" }
        )
    ),
  async execute(interaction) {
    const ownerId = process.env.BOT_OWNER_ID;
    if (!ownerId) {
      return interaction.reply({
        content: "BOT_OWNER_ID is not configured; owner maintenance actions are disabled.",
        ephemeral: true,
      });
    }
    if (interaction.user.id !== ownerId) {
      return interaction.reply({ content: "Only the configured bot owner can run maintenance actions.", ephemeral: true });
    }

    const action = interaction.options.getString("action", true);
    if (!Object.hasOwn(actionLabels, action)) {
      return interaction.reply({ content: "That maintenance action is not supported.", ephemeral: true });
    }

    await interaction.deferReply();
    try {
      if (action === "deploy") {
        await runNpm(["run", "deploy"]);
        return interaction.editReply({
          content: `✅ \`${actionLabels[action]}\` completed successfully.`,
          allowedMentions: { parse: [] },
        });
      }

      if (action === "npm-restart") {
        await interaction.editReply({ content: "Requesting the server restart..." });
        await runNpm(["restart"]);
        return interaction.editReply({
          content: `✅ \`${actionLabels[action]}\` completed successfully.`,
          allowedMentions: { parse: [] },
        });
      }

      await interaction.editReply({ content: "Requesting the server restart..." });
      await requestServerRestart();
      return interaction.editReply({
        content: "✅ The hosting panel accepted the server restart request.",
        allowedMentions: { parse: [] },
      });
    } catch (error) {
      console.error(`Bot maintenance action "${action}" failed:`, error);
      return interaction.editReply({
        content: `❌ \`${actionLabels[action]}\` failed. Check the bot logs for details.`,
        allowedMentions: { parse: [] },
      });
    }
  },
};

export const commands = [botMaintenance];
