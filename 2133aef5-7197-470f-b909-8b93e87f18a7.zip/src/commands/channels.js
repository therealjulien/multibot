import { ChannelType, PermissionFlagsBits, PermissionsBitField } from "discord.js";

export function targetChannelOption(option) {
  return option
    .setName("channel")
    .setDescription("Target channel; defaults to this channel")
    .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement);
}

export async function resolveTargetChannel(interaction, { memberPermissions = [], botPermissions = [] } = {}) {
  const selected = interaction.options.getChannel("channel");
  if (!selected) return { channel: interaction.channel };
  if (selected.id === interaction.channelId) return { channel: interaction.channel ?? selected };
  if (!interaction.guild) return { error: "Choose a channel in this server." };

  const channel = typeof selected.permissionsFor === "function"
    ? selected
    : await interaction.guild.channels.fetch(selected.id);
  if (!channel || ![ChannelType.GuildText, ChannelType.GuildAnnouncement].includes(channel.type)) {
    return { error: "Choose an accessible text or announcement channel in this server." };
  }

  const member = interaction.guild.members.resolve(interaction.user.id) ??
    await interaction.guild.members.fetch(interaction.user.id);
  const requiredMember = [PermissionFlagsBits.ViewChannel, ...memberPermissions];
  if (!channel.permissionsFor(member)?.has(requiredMember)) {
    return { error: `You need ${new PermissionsBitField(requiredMember).toArray().join(", ")} in the selected channel.` };
  }
  const botMember = interaction.guild.members.me;
  const requiredBot = [PermissionFlagsBits.ViewChannel, ...botPermissions];
  if (!botMember || !channel.permissionsFor(botMember)?.has(requiredBot)) {
    return { error: `I need ${new PermissionsBitField(requiredBot).toArray().join(", ")} in the selected channel.` };
  }
  return { channel };
}
