import { ChannelType, PermissionFlagsBits, SlashCommandBuilder } from "discord.js";
import {
  addCustomCommand,
  clearAfk,
  getBirthdays,
  getProfile,
  getThanksLeaderboard,
  listCustomCommands,
  recordThanks,
  removeBirthday,
  removeCustomCommand,
  setAfk,
  setBirthday,
  setBirthdayChannel,
  setProfile,
  updateCustomCommand,
} from "../features/social.js";
import { getInviteCount } from "../features/invites.js";

function requireGuildId(interaction) {
  if (!interaction.guildId) throw new Error("This command can only be used in a server.");
  return interaction.guildId;
}

const afkCommand = {
  data: new SlashCommandBuilder()
    .setName("afk")
    .setDescription("Set an AFK status or clear your existing status")
    .addStringOption((option) =>
      option.setName("reason").setDescription("Optional reason for being away").setMaxLength(200)
    ),
  async execute(interaction) {
    const guildId = requireGuildId(interaction);
    const reason = interaction.options.getString("reason")?.trim() ?? "";
    if (!reason) {
      const cleared = await clearAfk(guildId, interaction.user.id);
      await interaction.reply({
        content: cleared ? "Your AFK status has been cleared." : "You weren't marked as AFK.",
        ephemeral: true,
      });
      return;
    }

    await setAfk(guildId, interaction.user.id, reason);
    await interaction.reply({ content: `You're now marked as AFK: ${reason}`, ephemeral: true });
  },
};

const birthdayCommand = {
  data: new SlashCommandBuilder()
    .setName("birthday")
    .setDescription("Set or view birthdays for this server")
    .addSubcommand((subcommand) =>
      subcommand
        .setName("set")
        .setDescription("Save your birthday month and day")
        .addIntegerOption((option) => option.setName("month").setDescription("Month, 1–12").setMinValue(1).setMaxValue(12).setRequired(true))
        .addIntegerOption((option) => option.setName("day").setDescription("Day of the month").setMinValue(1).setMaxValue(31).setRequired(true))
    )
    .addSubcommand((subcommand) =>
      subcommand.setName("remove").setDescription("Remove your saved birthday")
    )
    .addSubcommand((subcommand) =>
      subcommand.setName("list").setDescription("List saved birthdays")
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("channel")
        .setDescription("Set or clear the birthday announcement channel")
        .addChannelOption((option) =>
          option
            .setName("channel")
            .setDescription("Text channel; omit to disable announcements")
            .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        )
    ),
  async execute(interaction) {
    const guildId = requireGuildId(interaction);
    const action = interaction.options.getSubcommand();

    if (action === "set") {
      const month = interaction.options.getInteger("month", true);
      const day = interaction.options.getInteger("day", true);
      try {
        const birthday = await setBirthday(guildId, interaction.user.id, month, day);
        await interaction.reply({ content: `Your birthday is saved as **${birthday}** (month-day).`, ephemeral: true });
      } catch (error) {
        if (!(error instanceof RangeError)) throw error;
        await interaction.reply({ content: "That isn't a valid calendar date. Please try again.", ephemeral: true });
      }
      return;
    }

    if (action === "remove") {
      const removed = await removeBirthday(guildId, interaction.user.id);
      await interaction.reply({
        content: removed ? "Your saved birthday was removed." : "You don't have a saved birthday.",
        ephemeral: true,
      });
      return;
    }

    if (action === "list") {
      const { birthdays } = await getBirthdays(guildId);
      const rows = birthdays.slice(0, 25).map(({ userId, date }) => `<@${userId}> — ${date}`);
      await interaction.reply({
        content: rows.length ? rows.join("\n") : "No birthdays have been added yet.",
        allowedMentions: { parse: [] },
        ephemeral: true,
      });
      return;
    }

    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      await interaction.reply({ content: "You need Manage Server to configure birthday announcements.", ephemeral: true });
      return;
    }
    const channel = interaction.options.getChannel("channel");
    await setBirthdayChannel(guildId, channel?.id ?? null);
    await interaction.reply({
      content: channel ? `Birthday announcements will be posted in ${channel}.` : "Birthday announcements are disabled.",
      ephemeral: true,
    });
  },
};

const customCommand = {
  data: new SlashCommandBuilder()
    .setName("custom-command")
    .setDescription("Create, remove, or list simple server commands")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((subcommand) =>
      subcommand
        .setName("add")
        .setDescription("Create a command users can run with !name")
        .addStringOption((option) =>
          option.setName("name").setDescription("Lowercase command name").setMinLength(2).setMaxLength(32).setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("response")
            .setDescription("Text; placeholders: {user}, {server}, {channel}, {memberCount}, {args}")
            .setMaxLength(1800)
            .setRequired(true)
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("edit")
        .setDescription("Edit an existing !name command")
        .addStringOption((option) =>
          option.setName("name").setDescription("Command name").setMinLength(2).setMaxLength(32).setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("response")
            .setDescription("Text; placeholders: {user}, {server}, {channel}, {memberCount}, {args}")
            .setMaxLength(1800)
            .setRequired(true)
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("remove")
        .setDescription("Remove a custom command")
        .addStringOption((option) => option.setName("name").setDescription("Command name").setMinLength(2).setMaxLength(32).setRequired(true))
    )
    .addSubcommand((subcommand) =>
      subcommand.setName("list").setDescription("List custom command names")
    ),
  async execute(interaction) {
    const guildId = requireGuildId(interaction);
    const action = interaction.options.getSubcommand();

    if (action === "add") {
      const name = interaction.options.getString("name", true).toLowerCase();
      const response = interaction.options.getString("response", true).trim();
      if (
        !/^[a-z0-9_-]{2,32}$/.test(name) ||
        ["__proto__", "constructor", "prototype"].includes(name) ||
        !response
      ) {
        await interaction.reply({ content: "Use a command name with 2–32 letters, numbers, underscores, or hyphens, and a non-empty response.", ephemeral: true });
        return;
      }
      const result = await addCustomCommand(guildId, name, response);
      const messages = {
        limit: "This server already has the maximum of 25 custom commands.",
        exists: `The \`!${name}\` command already exists.`,
        invalid: "That command name is reserved and can't be used.",
      };
      await interaction.reply({
        content: result.added ? `Added \`!${name}\`.` : messages[result.reason],
        ephemeral: true,
      });
      return;
    }

    if (action === "edit") {
      const name = interaction.options.getString("name", true).toLowerCase();
      const response = interaction.options.getString("response", true).trim();
      if (!/^[a-z0-9_-]{2,32}$/.test(name) || !response) {
        await interaction.reply({
          content: "Use a command name with 2–32 letters, numbers, underscores, or hyphens, and a non-empty response.",
          ephemeral: true,
        });
        return;
      }
      const updated = await updateCustomCommand(guildId, name, response);
      await interaction.reply({
        content: updated ? `Updated \`!${name}\`.` : `There is no \`!${name}\` command to edit.`,
        ephemeral: true,
      });
      return;
    }

    if (action === "remove") {
      const name = interaction.options.getString("name", true).toLowerCase();
      const removed = await removeCustomCommand(guildId, name);
      await interaction.reply({
        content: removed ? `Removed \`!${name}\`.` : `There is no \`!${name}\` command.`,
        ephemeral: true,
      });
      return;
    }

    const names = await listCustomCommands(guildId);
    await interaction.reply({
      content: names.length ? names.map((name) => `\`!${name}\``).join(", ") : "No custom commands are set up.",
      ephemeral: true,
    });
  },
};

const profileCommand = {
  data: new SlashCommandBuilder()
    .setName("profile")
    .setDescription("Set or view a short server profile")
    .addSubcommand((subcommand) =>
      subcommand
        .setName("set")
        .setDescription("Set your profile bio")
        .addStringOption((option) => option.setName("bio").setDescription("A short bio").setMaxLength(160).setRequired(true))
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("show")
        .setDescription("Show a member's profile")
        .addUserOption((option) => option.setName("user").setDescription("Member to view"))
    )
    .addSubcommand((subcommand) =>
      subcommand.setName("clear").setDescription("Clear your profile bio")
    ),
  async execute(interaction) {
    const guildId = requireGuildId(interaction);
    const action = interaction.options.getSubcommand();
    if (action === "set") {
      const bio = interaction.options.getString("bio", true).trim();
      if (!bio) {
        await interaction.reply({ content: "Your bio can't be empty.", ephemeral: true });
        return;
      }
      await setProfile(guildId, interaction.user.id, bio);
      await interaction.reply({ content: "Your profile bio has been updated.", ephemeral: true });
      return;
    }

    const user = action === "show"
      ? interaction.options.getUser("user") ?? interaction.user
      : interaction.user;
    if (action === "clear") {
      await setProfile(guildId, interaction.user.id, "");
      await interaction.reply({ content: "Your profile bio has been cleared.", ephemeral: true });
      return;
    }

    const profile = await getProfile(guildId, user.id);
    await interaction.reply({
      content: `**${user.username}'s profile**\n${profile?.bio || "No bio set yet."}`,
      allowedMentions: { parse: [] },
    });
  },
};

const thanksCommand = {
  data: new SlashCommandBuilder()
    .setName("thanks")
    .setDescription("Thank a server member or view the appreciation leaderboard")
    .addSubcommand((subcommand) =>
      subcommand
        .setName("give")
        .setDescription("Give a member a thank-you")
        .addUserOption((option) => option.setName("user").setDescription("Member to thank").setRequired(true))
    )
    .addSubcommand((subcommand) =>
      subcommand.setName("top").setDescription("Show the most thanked members")
    ),
  async execute(interaction) {
    const guildId = requireGuildId(interaction);
    if (interaction.options.getSubcommand() === "give") {
      const recipient = interaction.options.getUser("user", true);
      const result = await recordThanks(guildId, interaction.user.id, recipient.id);
      const response = result.recorded
        ? `Thanks to <@${recipient.id}>! They've received ${result.count} thank-you${result.count === 1 ? "" : "s"}.`
        : result.reason === "self"
          ? "You can't thank yourself."
          : "Please wait a minute before giving another thank-you.";
      await interaction.reply({ content: response, allowedMentions: { users: [recipient.id] } });
      return;
    }

    const rows = await getThanksLeaderboard(guildId);
    const lines = rows.map((row, index) => `**${index + 1}.** <@${row.userId}> — ${row.count}`);
    await interaction.reply({
      content: lines.length ? lines.join("\n") : "Nobody has received a thank-you yet.",
      allowedMentions: { parse: [] },
    });
  },
};

const invitesCommand = {
  data: new SlashCommandBuilder()
    .setName("invites")
    .setDescription("Show tracked invite joins for a member")
    .addUserOption((option) => option.setName("user").setDescription("Member to check")),
  async execute(interaction) {
    const guildId = requireGuildId(interaction);
    const user = interaction.options.getUser("user") ?? interaction.user;
    const count = await getInviteCount(guildId, user.id);
    await interaction.reply({
      content: `<@${user.id}> has **${count}** tracked invite join${count === 1 ? "" : "s"} since Multibot started tracking.`,
      allowedMentions: { users: [user.id] },
    });
  },
};

export const commands = [
  afkCommand,
  birthdayCommand,
  customCommand,
  profileCommand,
  thanksCommand,
  invitesCommand,
];
