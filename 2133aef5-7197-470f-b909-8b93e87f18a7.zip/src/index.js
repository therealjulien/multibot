import "dotenv/config";
import { Client, Events, GatewayIntentBits, Partials } from "discord.js";
import { commands, handleHelpCancel, handleHelpMention, handleHelpSelect, helpCancelCustomId, helpSelectCustomId } from "./commands.js";
import { replyToAiChannelMessage } from "./ai.js";
import { getGuildCommunitySettings } from "./community.js";
import { handleGiveawayButton, scheduleGiveawayChecks } from "./giveaways.js";
import { applyLevelRoleReward } from "./features/level-rewards.js";
import { awardMessageXp, removeMemberLevel } from "./levels.js";
import { initializeBotVersion } from "./version.js";
import { handleFeatureMessage, registerFeatureEvents } from "./features/runtime.js";
import { registerPresenceEvents } from "./features/presence.js";
import { runCommand } from "./features/command-progress.js";

const token = process.env.DISCORD_TOKEN;

if (!token) {
  throw new Error("Set DISCORD_TOKEN in your .env file before starting the bot.");
}

const botVersion = await initializeBotVersion();
const commandMap = new Map(commands.map((command) => [command.data.name, command]));
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildExpressions,
    GatewayIntentBits.GuildModeration,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User],
});

registerFeatureEvents(client);
registerPresenceEvents(client);

client.once(Events.ClientReady, (readyClient) => {
  console.log(`Ready as ${readyClient.user.tag} · Version ${botVersion.version}`);
  scheduleGiveawayChecks(readyClient);
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (interaction.isStringSelectMenu() && interaction.customId === helpSelectCustomId) {
    try {
      await handleHelpSelect(interaction);
    } catch (error) {
      console.error("Help category selection failed:", error);
      const response = { content: "I couldn't update the help menu. Please try again.", ephemeral: false };
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp(response);
      } else {
        await interaction.reply(response);
      }
    }
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith(helpCancelCustomId)) {
    try {
      await handleHelpCancel(interaction);
    } catch (error) {
      console.error("Help menu cancellation failed:", error);
      const response = { content: "I couldn't close the help menu. Please try again.", ephemeral: true };
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp(response);
      } else {
        await interaction.reply(response);
      }
    }
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith("multibot:giveaway:enter:")) {
    try {
      await handleGiveawayButton(interaction);
    } catch (error) {
      console.error(`Giveaway entry failed for message ${interaction.message.id}:`, error);
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: "I couldn't process your entry. Please try again.", ephemeral: true });
      }
    }
    return;
  }

  if (!interaction.isChatInputCommand()) return;

  const command = commandMap.get(interaction.commandName);
  if (!command) return;

  await runCommand(interaction, command);
});

client.on(Events.MessageCreate, async (message) => {
  if (!message.guild || message.author.bot) return;

  if (await handleFeatureMessage(message)) return;

  try {
    if (await handleHelpMention(message, client.user.id)) return;
  } catch (error) {
    console.error(`Could not send help for mention in ${message.guildId}/${message.channelId}:`, error);
    return;
  }

  await replyToAiChannelMessage(message);
});

client.on(Events.MessageCreate, async (message) => {
  if (!message.guild || message.author.bot) return;

  if (await handleFeatureMessage(message)) return;

  let progress;
  try {
    progress = await awardMessageXp(message.guild.id, message.author.id);
  } catch (error) {
    console.error("Could not award message XP:", error);
    return;
  }

  if (progress?.leveledUp) {
    let rewardRole = null;
    try {
      const member = message.member ?? await message.guild.members.fetch(message.author.id);
      rewardRole = await applyLevelRoleReward(member, progress.level);
    } catch (error) {
      console.error(`Could not assign level ${progress.level} reward to member ${message.author.id}:`, error);
    }

    try {
      await message.channel.send({
        content: `🎉 <@${message.author.id}> reached **level ${progress.level}**!${rewardRole ? ` Reward role: **${rewardRole.name}**.` : ""}`,
        allowedMentions: { users: [message.author.id] },
      });
    } catch (error) {
      console.error("Could not announce a level-up:", error);
    }
  }
});

client.on(Events.GuildMemberRemove, async (member) => {
  try {
    await removeMemberLevel(member.guild.id, member.id);
  } catch (error) {
    console.error(`Could not remove level data for departed member ${member.id}:`, error);
  }
});

client.on(Events.GuildMemberAdd, async (member) => {
  let settings;
  try {
    settings = await getGuildCommunitySettings(member.guild.id);
  } catch (error) {
    console.error(`Could not load welcome settings for guild ${member.guild.id}:`, error);
    return;
  }

  if (settings.welcomeChannelId && settings.welcomeMessage) {
    try {
      const channel = await member.guild.channels.fetch(settings.welcomeChannelId);
      if (!channel || !channel.isTextBased() || !("send" in channel)) {
        throw new Error(`Configured welcome channel ${settings.welcomeChannelId} is unavailable.`);
      }
      const content = settings.welcomeMessage
        .replaceAll("{user}", `<@${member.id}>`)
        .replaceAll("{server}", member.guild.name)
        .replaceAll("{memberCount}", String(member.guild.memberCount));
      await channel.send({
        content,
        allowedMentions: { parse: [], users: [member.id] },
      });
    } catch (error) {
      console.error(`Could not send a welcome message for member ${member.id}:`, error);
    }
  }

  if (settings.autoRoleId) {
    try {
      const role = await member.guild.roles.fetch(settings.autoRoleId);
      if (!role) throw new Error(`Configured auto-role ${settings.autoRoleId} no longer exists.`);
      if (!role.editable) {
        throw new Error(`Configured auto-role ${role.id} is not below the bot's highest role.`);
      }
      await member.roles.add(role, "Configured Multibot automatic member role");
    } catch (error) {
      console.error(`Could not assign the automatic role to member ${member.id}:`, error);
    }
  }
});

client.login(token);
