import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const settingsPath = fileURLToPath(new URL("../data/ai-settings.json", import.meta.url));
export const aiCooldownSeconds = 5;
const cooldownMs = aiCooldownSeconds * 1_000;
const typingRefreshMs = 8_000;
const thinkingIntervalMs = 1_000;
const maxPromptLength = 1500;
const maxHistoryEntries = 12;
const maxActivePrompts = 2;
const maxThinkingTicks = 10;
const stillWorkingMessage = "The AI is still working. Please wait...";
const busyMessage = "This server already has two AI prompts running. Please try again when one finishes.";
const userCooldowns = new Map();
const channelHistories = new Map();
const activePrompts = new Map();
let settingsQueue = Promise.resolve();
const defaultGroqModel = "openai/gpt-oss-20b";
const groqEndpoint = "https://api.groq.com/openai/v1/chat/completions";
const missingGroqKeyError = "AI is not configured. Set GROQ_API_KEY in the bot's .env file.";

async function updateSettings(update, persist = true) {
  const task = settingsQueue.then(async () => {
    let settings;
    try {
      settings = JSON.parse(await readFile(settingsPath, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      settings = {};
    }

    const result = update(settings);
    if (persist) {
      await mkdir(new URL("../data/", import.meta.url), { recursive: true });
      const temporaryPath = `${settingsPath}.${process.pid}.tmp`;
      await writeFile(temporaryPath, `${JSON.stringify(settings, null, 2)}\n`, "utf8");
      await rename(temporaryPath, settingsPath);
    }
    return result;
  });

  settingsQueue = task.catch(() => {});
  return task;
}

function getGuildSettings(settings, guildId) {
  const saved = settings[guildId] ?? {};
  return {
    enabled: saved.enabled !== false,
    channelId: saved.channelId ?? null,
  };
}

function clearGuildHistory(guildId) {
  for (const key of channelHistories.keys()) {
    if (key.startsWith(`${guildId}:`)) channelHistories.delete(key);
  }
}

export function getAiSettings(guildId) {
  return updateSettings((settings) => getGuildSettings(settings, guildId), false);
}

export function setAiChannel(guildId, channelId) {
  clearGuildHistory(guildId);
  return updateSettings((settings) => {
    const guildSettings = settings[guildId] ??= {};
    guildSettings.channelId = channelId;
    return getGuildSettings(settings, guildId);
  });
}

export function unlinkAiChannel(guildId) {
  clearGuildHistory(guildId);
  return updateSettings((settings) => {
    const guildSettings = settings[guildId] ??= {};
    guildSettings.channelId = null;
    return getGuildSettings(settings, guildId);
  });
}

export function setAiEnabled(guildId, enabled) {
  if (!enabled) clearGuildHistory(guildId);
  return updateSettings((settings) => {
    const guildSettings = settings[guildId] ??= {};
    guildSettings.enabled = enabled;
    return getGuildSettings(settings, guildId);
  });
}

function claimAiCooldown(guildId, userId) {
  const key = `${guildId}:${userId}`;
  const now = Date.now();
  if (userCooldowns.size > 10_000) {
    for (const [cooldownKey, timestamp] of userCooldowns) {
      if (now - timestamp >= cooldownMs) userCooldowns.delete(cooldownKey);
    }
  }

  const previous = userCooldowns.get(key) ?? 0;
  const userWaitMs = cooldownMs - (now - previous);
  if (userWaitMs > 0) {
    return {
      error: `Please wait ${Math.ceil(userWaitMs / 1000)} seconds before asking again.`,
    };
  }

  userCooldowns.set(key, now);
  return null;
}

function claimAiSlot(guildId) {
  const active = activePrompts.get(guildId) ?? 0;
  if (active >= maxActivePrompts) return null;
  activePrompts.set(guildId, active + 1);
  return {
    thinkingTicks: active === 0 ? aiCooldownSeconds : maxThinkingTicks,
    release() {
      const remaining = activePrompts.get(guildId) - 1;
      if (remaining === 0) activePrompts.delete(guildId);
      else activePrompts.set(guildId, remaining);
    },
  };
}

async function requestAi(contents) {
  const apiKey = process.env.GROQ_API_KEY?.trim();
  if (!apiKey) throw new Error(missingGroqKeyError);

  let response;
  try {
    response = await fetch(groqEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: process.env.GROQ_MODEL?.trim() || defaultGroqModel,
        messages: [
          {
            role: "system",
            content: "You are a helpful assistant chatting in a Discord community. Be clear, friendly, and concise. Format responses for Discord using short paragraphs and bullet lists. Do not use Markdown tables or HTML; use lists instead.",
          },
          ...contents.map(({ role, parts }) => ({
            role: role === "model" ? "assistant" : role,
            content: parts.map((part) => part.text ?? "").join(""),
          })),
        ],
        max_tokens: 900,
        temperature: 0.7,
      }),
      signal: AbortSignal.timeout(30_000),
    });
  } catch (error) {
    if (error.name === "TimeoutError") throw new Error("The AI did not respond within 30 seconds.", { cause: error });
    throw new Error("Could not reach the AI service.", { cause: error });
  }

  let payload;
  try {
    payload = await response.json();
  } catch (error) {
    throw new Error("The AI service returned an unreadable response.", { cause: error });
  }
  if (!response.ok) {
    const detail = payload.error?.message;
    throw new Error(`AI service returned HTTP ${response.status}${detail ? `: ${detail}` : "."}`);
  }

  const text = payload.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error("The AI service returned no text for this request.");
  return text;
}

export async function askAi(guildId, userId, prompt, withThinking = (operation) => operation()) {
  const settings = await getAiSettings(guildId);
  if (!settings.enabled) return { error: "AI is disabled by this server's admins." };
  if (!prompt.trim()) return { error: "Enter a question for the AI." };
  if (prompt.length > maxPromptLength) return { error: `Questions must be ${maxPromptLength} characters or fewer.` };
  if (!process.env.GROQ_API_KEY?.trim()) return { error: missingGroqKeyError };

  const slot = claimAiSlot(guildId);
  if (!slot) return { error: busyMessage };
  try {
    const cooldown = claimAiCooldown(guildId, userId);
    if (cooldown) return { error: cooldown.error };
    const text = await withThinking(
      () => requestAi([{ role: "user", parts: [{ text: prompt.trim() }] }]),
      slot.thinkingTicks
    );
    return { text };
  } finally {
    slot.release();
  }
}

async function respondInChannel(message, withThinking) {
  const settings = await getAiSettings(message.guildId);
  if (!settings.enabled || settings.channelId !== message.channelId) return { status: "inactive" };

  const prompt = message.content.trim();
  if (!prompt) return { status: "ignored" };
  if (prompt.length > maxPromptLength) {
    return { error: `Messages in this AI channel must be ${maxPromptLength} characters or fewer.` };
  }
  if (!process.env.GROQ_API_KEY?.trim()) return { error: missingGroqKeyError };

  const slot = claimAiSlot(message.guildId);
  if (!slot) return { error: busyMessage };
  try {
    const cooldown = claimAiCooldown(message.guildId, message.author.id);
    if (cooldown) return { status: "cooldown" };

    const historyKey = `${message.guildId}:${message.channelId}`;
    const history = channelHistories.get(historyKey) ?? [];
    const sendTyping = () => {
      message.channel.sendTyping().catch((error) => {
        console.error(`Could not send AI typing status in ${message.guildId}/${message.channelId}:`, error);
      });
    };
    sendTyping();
    const typingTimer = setInterval(sendTyping, typingRefreshMs);
    let text;
    try {
      text = await withThinking(() => requestAi([
        ...history,
        { role: "user", parts: [{ text: prompt }] },
      ]), slot.thinkingTicks);
    } finally {
      clearInterval(typingTimer);
    }
    const latestSettings = await getAiSettings(message.guildId);
    if (!latestSettings.enabled || latestSettings.channelId !== message.channelId) {
      return { status: "inactive" };
    }

    const updatedHistory = [
      ...(channelHistories.get(historyKey) ?? []),
      { role: "user", parts: [{ text: prompt }] },
      { role: "model", parts: [{ text }] },
    ];
    channelHistories.set(historyKey, updatedHistory.slice(-maxHistoryEntries));
    return { status: "responded", text };
  } finally {
    slot.release();
  }
}

export function handleAiChannelMessage(message, withThinking = (operation) => operation()) {
  return respondInChannel(message, withThinking);
}

export function truncateAiResponse(text) {
  const maxLength = 1900;
  return text.length > maxLength ? `${text.slice(0, maxLength - 3)}...` : text;
}

function replaceBreaks(text) {
  return text.replace(/(`+)([\s\S]*?)\1|<br\s*\/?>/gi, (match, ticks) => ticks ? match : "\n");
}

function tableCells(line) {
  const cells = [];
  let cell = "";
  let codeTicks = 0;
  for (let index = 0; index < line.length; index++) {
    const char = line[index];
    if (char === "\\" && index + 1 < line.length) {
      cell += char + line[++index];
    } else if (char === "`") {
      let end = index;
      while (line[end] === "`") end++;
      const length = end - index;
      if (!codeTicks) codeTicks = length;
      else if (codeTicks === length) codeTicks = 0;
      cell += line.slice(index, end);
      index = end - 1;
    } else if (char === "|" && !codeTicks) {
      cells.push(cell.trim());
      cell = "";
    } else {
      cell += char;
    }
  }
  cells.push(cell.trim());
  if (line.trimStart().startsWith("|")) cells.shift();
  if (line.trimEnd().endsWith("|") && cells.at(-1) === "") cells.pop();
  return cells;
}

function boldLabel(text) {
  return /^\*\*.+\*\*$/.test(text) ? text : `**${text}**`;
}

function formatAiResponse(text) {
  const lines = text.split("\n");
  const formatted = [];
  let fence = null;
  for (let index = 0; index < lines.length; index++) {
    const line = lines[index];
    const marker = line.match(/^\s{0,3}(`{3,}|~{3,})/);
    if (marker) {
      if (!fence) fence = marker[1];
      else if (marker[1][0] === fence[0] && marker[1].length >= fence.length) fence = null;
      formatted.push(line);
      continue;
    }
    if (fence) {
      formatted.push(line);
      continue;
    }

    const headers = tableCells(line);
    const separator = index + 1 < lines.length ? tableCells(lines[index + 1]) : [];
    if (headers.length >= 2 && separator.length === headers.length &&
        separator.every((cell) => /^:?-{3,}:?$/.test(cell)) &&
        index + 2 < lines.length && tableCells(lines[index + 2]).length === headers.length) {
      index += 2;
      const rows = [];
      while (index < lines.length) {
        const cells = tableCells(lines[index]);
        if (cells.length !== headers.length) break;
        const title = cells[0] ? boldLabel(replaceBreaks(cells[0])) : "";
        const values = cells.slice(1).map((cell, cellIndex) => {
          const value = replaceBreaks(cell);
          if (cells.length === 2 || !headers[cellIndex + 1]) return value;
          return `${boldLabel(headers[cellIndex + 1])}: ${value}`;
        });
        rows.push([title, ...values].filter(Boolean).join("\n"));
        index++;
      }
      formatted.push(rows.join("\n\n"));
      index--;
      continue;
    }
    formatted.push(replaceBreaks(line));
  }
  return formatted.join("\n");
}

export function aiReplyOptions(userId, text) {
  return {
    content: `<@${userId}> ${truncateAiResponse(formatAiResponse(text))}`,
    allowedMentions: { parse: [], users: [userId], repliedUser: false },
  };
}

export function isAiThinkingContent(content) {
  return typeof content === "string" && (content === stillWorkingMessage || /^⏳\.*$/u.test(content));
}

export async function withAiThinking(operation, update, minimumThinkingTicks = aiCooldownSeconds, maximumThinkingTicks = maxThinkingTicks) {
  await update("⏳");
  let ticks = 0;
  let operationFinished = false;
  let pendingUpdate = Promise.resolve();
  let completeMinimum;
  const minimum = new Promise((resolve) => { completeMinimum = resolve; });
  let timerStopped = false;
  const stopTimer = () => {
    if (!timerStopped) {
      clearInterval(timer);
      timerStopped = true;
    }
  };
  const timer = setInterval(() => {
    ticks++;
    const content = ticks === maximumThinkingTicks && !operationFinished
      ? stillWorkingMessage
      : `⏳${".".repeat(Math.min(ticks, 1900))}`;
    pendingUpdate = pendingUpdate.then(() => update(content)).catch((error) => {
      console.error("Could not update the AI thinking message:", error);
    });
    if (ticks === minimumThinkingTicks) completeMinimum();
    if (ticks === maximumThinkingTicks) stopTimer();
  }, thinkingIntervalMs);
  try {
    const request = Promise.resolve().then(operation).finally(() => { operationFinished = true; });
    const [result] = await Promise.all([request, minimum]);
    return result;
  } finally {
    stopTimer();
    await pendingUpdate;
  }
}

export async function replyToAiChannelMessage(message) {
  let thinkingMessage;
  const updateThinking = async (content) => {
    const options = { content, allowedMentions: { parse: [], repliedUser: false } };
    if (thinkingMessage) {
      await thinkingMessage.edit(options);
    } else {
      thinkingMessage = await message.reply(options);
    }
  };
  const sendResult = async (text) => {
    const options = aiReplyOptions(message.author.id, text);
    if (thinkingMessage) await thinkingMessage.edit(options);
    else await message.reply(options);
  };
  const isActive = async () => {
    const settings = await getAiSettings(message.guildId);
    return settings.enabled && settings.channelId === message.channelId;
  };
  try {
    const result = await handleAiChannelMessage(message, (operation, ticks) => withAiThinking(operation, updateThinking, ticks));
    if (result.status === "responded" || result.error) {
      if (await isActive()) await sendResult(result.error ?? result.text);
      else if (thinkingMessage) await thinkingMessage.delete();
    } else if (thinkingMessage) {
      await thinkingMessage.delete();
    }
  } catch (error) {
    console.error(`AI channel response failed in ${message.guildId}/${message.channelId}:`, error);
    try {
      if (await isActive()) await sendResult("The AI couldn't respond right now. Please try again later.");
      else if (thinkingMessage) await thinkingMessage.delete();
    } catch (replyError) {
      console.error("Could not report the AI channel failure:", replyError);
    }
  }
}
// Ready to sync
