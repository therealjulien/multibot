const defaultPanelApiUrl = "https://panel.mc-node.net";
const defaultPanelServerId = "9d912719";

export async function requestServerRestart({
  env = process.env,
  fetchImpl = globalThis.fetch,
  timeoutMs = 10_000,
} = {}) {
  const panelApiUrl = env.PANEL_API_URL || defaultPanelApiUrl;
  const panelApiKey = env.PANEL_API_KEY;
  const panelServerId = env.PANEL_SERVER_ID || defaultPanelServerId;
  if (!panelApiKey) {
    throw new Error("Set PANEL_API_KEY to enable server restart.");
  }
  if (!/^[a-zA-Z0-9_-]+$/.test(panelServerId)) {
    throw new Error("PANEL_SERVER_ID must contain only letters, numbers, underscores, or hyphens.");
  }

  let panelUrl;
  try {
    panelUrl = new URL(panelApiUrl);
  } catch {
    throw new Error("PANEL_API_URL must be a valid HTTPS URL.");
  }
  if (
    panelUrl.protocol !== "https:" ||
    panelUrl.username ||
    panelUrl.password ||
    panelUrl.search ||
    panelUrl.hash
  ) {
    throw new Error("PANEL_API_URL must be a clean HTTPS URL without credentials, query, or fragment.");
  }

  const endpoint = new URL(
    `/api/client/servers/${encodeURIComponent(panelServerId)}/power`,
    panelUrl
  );
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetchImpl(endpoint, {
      method: "POST",
      headers: {
        Accept: "Application/vnd.pterodactyl.v1+json",
        Authorization: `Bearer ${panelApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ signal: "restart" }),
      redirect: "manual",
      signal: controller.signal,
    });
    if (response.status !== 204) {
      throw new Error(`Panel API returned HTTP ${response.status}; expected 204 for a successful restart.`);
    }
  } catch (error) {
    if (error.name === "AbortError") {
      throw new Error("The panel restart request timed out.");
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}
