import { randomInt } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const economyPath = fileURLToPath(new URL("../data/economy.json", import.meta.url));
const initialBalance = 100;
const dailyReward = 50;
export const slotSymbols = [
  { emoji: "🍒", name: "Cherry", weight: 12, multiplier: 7 },
  { emoji: "🍋", name: "Lemon", weight: 9, multiplier: 11 },
  { emoji: "🍉", name: "Watermelon", weight: 6, multiplier: 26 },
  { emoji: "🔔", name: "Bell", weight: 4, multiplier: 64 },
  { emoji: "💎", name: "Diamond", weight: 1, multiplier: 320 },
];
export const slotWildSymbol = "🃏";
export const slotReelCount = 4;
export const slotRtpMinPercent = 85;
export const slotRtpMaxPercent = 98;
const slotMachineConfigs = [
  {
    id: "classic",
    name: "Classic",
    emoji: "🎰",
    symbols: slotSymbols,
    wildSymbol: slotWildSymbol,
    wildWeight: 1,
    bonusSymbol: null,
    bonusPayouts: [],
    jackpotSymbol: "💎",
  },
  {
    id: "treasure",
    name: "Treasure Hunt",
    emoji: "🏴‍☠️",
    symbols: [
      { emoji: "🪙", name: "Gold Coin", weight: 12, multiplier: 7 },
      { emoji: "🗺️", name: "Treasure Map", weight: 9, multiplier: 11 },
      { emoji: "🦜", name: "Parrot", weight: 6, multiplier: 26 },
      { emoji: "⚓", name: "Anchor", weight: 4, multiplier: 64 },
      { emoji: "👑", name: "Crown", weight: 1, multiplier: 320 },
    ],
    wildSymbol: "🃏",
    wildWeight: 1,
    bonusSymbol: { emoji: "🧰", name: "Treasure Chest", weight: 1 },
    bonusPayouts: [2, 3, 5, 10],
    jackpotSymbol: "👑",
  },
  {
    id: "galaxy",
    name: "Galaxy Quest",
    emoji: "🌌",
    symbols: [
      { emoji: "🌙", name: "Moon", weight: 12, multiplier: 7 },
      { emoji: "☄️", name: "Comet", weight: 9, multiplier: 11 },
      { emoji: "🪐", name: "Planet", weight: 6, multiplier: 26 },
      { emoji: "🌠", name: "Shooting Star", weight: 4, multiplier: 64 },
      { emoji: "🛸", name: "UFO", weight: 1, multiplier: 320 },
    ],
    wildSymbol: "✨",
    wildWeight: 1,
    bonusSymbol: { emoji: "🌀", name: "Wormhole", weight: 1 },
    bonusPayouts: [2, 4, 6, 12],
    jackpotSymbol: "🛸",
  },
  {
    id: "candy",
    name: "Candy Rush",
    emoji: "🍭",
    symbols: [
      { emoji: "🍬", name: "Candy", weight: 12, multiplier: 7 },
      { emoji: "🍭", name: "Lollipop", weight: 9, multiplier: 11 },
      { emoji: "🍩", name: "Donut", weight: 6, multiplier: 26 },
      { emoji: "🍪", name: "Cookie", weight: 4, multiplier: 64 },
      { emoji: "🍰", name: "Cake", weight: 1, multiplier: 320 },
    ],
    wildSymbol: "🍫",
    wildWeight: 1,
    bonusSymbol: { emoji: "🌈", name: "Rainbow", weight: 1 },
    bonusPayouts: [2, 3, 4, 8],
    jackpotSymbol: "🍰",
  },
];
export const slotMachines = slotMachineConfigs.map(({ id, name, emoji }) => ({ id, name, emoji }));
const slotMachinesById = new Map(slotMachineConfigs.map((machine) => [machine.id, machine]));
const getSlotMachine = (machineId = "classic") => {
  const machine = slotMachinesById.get(machineId);
  if (!machine) throw new RangeError(`Unknown slot machine: ${machineId}`);
  return machine;
};
const getWeightedSlotSymbols = (machine) => [
  ...machine.symbols,
  { emoji: machine.wildSymbol, name: "WILD", weight: machine.wildWeight, multiplier: 0 },
  ...(machine.bonusSymbol ? [machine.bonusSymbol] : []),
];
const getBonusAverageMultiplier = (machine) =>
  machine.bonusPayouts.reduce((total, multiplier) => total + multiplier, 0) / machine.bonusPayouts.length;
const rouletteRedNumbers = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);
let queue = Promise.resolve();
const slotCooldownMs = 5_000;
const slotCooldowns = new Map();

export function randomSlotSymbol(machineId = "classic") {
  const weightedSymbols = getWeightedSlotSymbols(getSlotMachine(machineId));
  const totalWeight = weightedSymbols.reduce((total, symbol) => total + symbol.weight, 0);
  let roll = randomInt(totalWeight);
  for (const symbol of weightedSymbols) {
    roll -= symbol.weight;
    if (roll < 0) return symbol.emoji;
  }
  throw new Error("Slot symbol weights must add up to the total weight.");
}

export function getSlotOutcome(result, machineId = "classic") {
  const machine = getSlotMachine(machineId);
  const weightedSymbols = getWeightedSlotSymbols(machine);
  if (result.length !== slotReelCount) {
    throw new RangeError(`A slot result must contain exactly ${slotReelCount} symbols.`);
  }
  if (result.some((reel) => !weightedSymbols.some((symbol) => symbol.emoji === reel))) {
    throw new RangeError("A slot result contains an unknown symbol.");
  }

  const wildCount = result.filter((reel) => reel === machine.wildSymbol).length;
  const bonusCount = machine.bonusSymbol
    ? result.filter((reel) => reel === machine.bonusSymbol.emoji).length
    : 0;
  if (bonusCount >= 3) {
    return {
      symbol: machine.bonusSymbol,
      matchCount: bonusCount,
      multiplier: getBonusAverageMultiplier(machine) * (bonusCount === slotReelCount ? 2 : 1),
      usedWilds: false,
      bonus: true,
    };
  }

  let bestOutcome = { symbol: null, matchCount: 0, multiplier: 0, usedWilds: false };
  for (const symbol of machine.symbols) {
    const matchCount = result.filter((reel) => reel === symbol.emoji).length + wildCount;
    if (matchCount < 3) continue;

    const multiplier = matchCount === slotReelCount ? symbol.multiplier * 2 : symbol.multiplier;
    if (multiplier > bestOutcome.multiplier) {
      bestOutcome = {
        symbol,
        matchCount,
        multiplier,
        usedWilds: wildCount > 0,
      };
    }
  }
  return bestOutcome;
}

export function getSlotMultiplier(result, machineId = "classic") {
  return getSlotOutcome(result, machineId).multiplier;
}

function calculateBaseSlotRtp(machine) {
  const weightedSymbols = getWeightedSlotSymbols(machine);
  const totalWeight = weightedSymbols.reduce((total, symbol) => total + symbol.weight, 0);
  let weightedMultiplier = 0;
  function visit(reels, weight) {
    if (reels.length === slotReelCount) {
      weightedMultiplier += (weight / totalWeight ** slotReelCount) * getSlotMultiplier(reels, machine.id);
      return;
    }
    for (const symbol of weightedSymbols) {
      visit([...reels, symbol.emoji], weight * symbol.weight);
    }
  }
  visit([], 1);
  return weightedMultiplier * 100;
}

const slotBaseRtpByMachine = new Map(
  slotMachineConfigs.map((machine) => [machine.id, calculateBaseSlotRtp(machine)])
);
export const slotBaseRtpPercent = slotBaseRtpByMachine.get("classic");
export function getSlotBaseRtpPercent(machineId = "classic") {
  getSlotMachine(machineId);
  return slotBaseRtpByMachine.get(machineId);
}

const blackjackCardNames = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
const drawBlackjackCard = () => blackjackCardNames[randomInt(blackjackCardNames.length)];

function blackjackHandValue(cards) {
  let value = 0;
  let aces = 0;
  for (const card of cards) {
    if (card === "A") {
      value += 11;
      aces += 1;
    } else {
      value += Number(card) || 10;
    }
  }
  while (value > 21 && aces > 0) {
    value -= 10;
    aces -= 1;
  }
  return value;
}

export function playGame(game, wager, machineId = "classic") {
  let won = false;
  let detail;
  let payout = 0;
  let jackpot = false;
  let push = false;
  let reels;
  let slotMatchCount;
  let payoutPercent;
  let rtpTargetPercent;
  let machine;
  let bonusMultiplier;

  if (game === "coinflip") {
    const result = randomInt(2) === 0 ? "heads" : "tails";
    won = result === "heads";
    payout = won ? wager * 2 : 0;
    detail = `The coin landed **${result}**.`;
  } else if (game === "dice") {
    const result = randomInt(1, 7);
    won = result >= 4;
    payout = won ? wager * 2 : 0;
    detail = `The die rolled **${result}**.`;
  } else if (game === "slots") {
    machine = getSlotMachine(machineId);
    reels = Array.from({ length: slotReelCount }, () => randomSlotSymbol(machine.id));
    const outcome = getSlotOutcome(reels, machine.id);
    rtpTargetPercent = randomInt(slotRtpMinPercent, slotRtpMaxPercent + 1);
    const adjustedMultiplier = outcome.multiplier * rtpTargetPercent / getSlotBaseRtpPercent(machine.id);
    payout = Math.floor(wager * adjustedMultiplier);
    won = outcome.multiplier > 0;
    jackpot = outcome.matchCount === slotReelCount && (
      outcome.bonus || outcome.symbol?.emoji === machine.jackpotSymbol
    );
    slotMatchCount = outcome.matchCount;
    if (outcome.bonus) {
      const bonusPayouts = machine.bonusPayouts;
      bonusMultiplier = bonusPayouts[randomInt(bonusPayouts.length)]
        * (outcome.matchCount === slotReelCount ? 2 : 1);
      payout = Math.floor(wager * bonusMultiplier * rtpTargetPercent / getSlotBaseRtpPercent(machine.id));
      detail = `${outcome.matchCount} ${machine.bonusSymbol.name} symbols trigger the bonus round! It reveals **${bonusMultiplier}×**.`;
    } else {
      detail = won
        ? `${outcome.matchCount} matching ${outcome.symbol.name}${outcome.usedWilds ? " (WILD substituted)" : ""}.`
        : "No match.";
    }
    payoutPercent = won ? Math.round((payout / wager) * 100) : 0;
  } else if (game === "blackjack") {
    const playerCards = [drawBlackjackCard(), drawBlackjackCard()];
    const dealerCards = [drawBlackjackCard(), drawBlackjackCard()];
    const playerNatural = blackjackHandValue(playerCards) === 21;
    const dealerNatural = blackjackHandValue(dealerCards) === 21;

    while (blackjackHandValue(playerCards) < 17 && !playerNatural) {
      playerCards.push(drawBlackjackCard());
    }
    while (blackjackHandValue(dealerCards) < 17 && blackjackHandValue(playerCards) <= 21) {
      dealerCards.push(drawBlackjackCard());
    }

    const playerScore = blackjackHandValue(playerCards);
    const dealerScore = blackjackHandValue(dealerCards);
    if (playerNatural || dealerNatural) {
      if (playerNatural && dealerNatural) {
        push = true;
      } else if (playerNatural) {
        won = true;
        payout = wager * 2 + Math.floor(wager / 2);
      }
    } else if (playerScore <= 21) {
      if (dealerScore > 21 || playerScore > dealerScore) {
        won = true;
        payout = wager * 2;
      } else if (playerScore === dealerScore) {
        push = true;
      }
    }

    const result = push
      ? "It's a push; your wager is returned."
      : won
        ? "Blackjack! You win."
        : playerScore > 21
          ? "You bust. The dealer wins."
          : dealerScore > 21
            ? "The dealer busts. You win."
            : "The dealer wins.";
    detail = `You: **${playerCards.join(", ")}** (${playerScore}) · Dealer: **${dealerCards.join(", ")}** (${dealerScore}). ${result}`;
  } else if (game === "roulette") {
    const number = randomInt(37);
    const color = number === 0 ? "green" : rouletteRedNumbers.has(number) ? "red" : "black";
    won = color === "red";
    payout = won ? wager * 2 : 0;
    detail = `Roulette landed on **${number} ${color}**. You automatically bet on red.`;
  } else {
    throw new Error(`Unknown gamble game: ${game}`);
  }

  if (push) payout = wager;

  return {
    won,
    detail,
    payout,
    wager,
    jackpot,
    reels,
    push,
    slotMatchCount,
    payoutPercent,
    rtpTargetPercent,
    machineId: machine?.id,
    machineName: machine?.name,
    machineEmoji: machine?.emoji,
    bonusMultiplier,
  };
}

async function updateAccount(guildId, userId, update) {
  const task = queue.then(async () => {
    let economy;
    try {
      economy = JSON.parse(await readFile(economyPath, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      economy = {};
    }

    economy[guildId] ??= {};
    economy[guildId][userId] ??= { balance: initialBalance, lastDaily: null };
    const account = economy[guildId][userId];
    const result = update(account);

    await mkdir(new URL("../data/", import.meta.url), { recursive: true });
    const temporaryPath = `${economyPath}.${process.pid}.tmp`;
    await writeFile(temporaryPath, `${JSON.stringify(economy, null, 2)}\n`, "utf8");
    await rename(temporaryPath, economyPath);
    return result;
  });

  queue = task.catch(() => {});
  return task;
}

export function getBalance(guildId, userId) {
  return updateAccount(guildId, userId, (account) => account.balance);
}

export function claimDaily(guildId, userId) {
  return updateAccount(guildId, userId, (account) => {
    const today = new Date().toISOString().slice(0, 10);
    if (account.lastDaily === today) {
      return { claimed: false, balance: account.balance };
    }

    account.lastDaily = today;
    account.balance += dailyReward;
    return { claimed: true, reward: dailyReward, balance: account.balance };
  });
}

export function placeBet(guildId, userId, game, wager) {
  if (game === "slots") return placeSlotBet(guildId, userId, wager);

  return updateAccount(guildId, userId, (account) => {
    if (wager > account.balance) {
      return { error: "You don't have enough multicoins for that bet.", balance: account.balance };
    }

    const result = playGame(game, wager);
    account.balance += result.payout - wager;
    return { ...result, balance: account.balance };
  });
}

export function placeSlotBet(guildId, userId, wager, machineId = "classic") {
  getSlotMachine(machineId);
  const key = `${guildId}:${userId}`;
  if (slotCooldowns.size > 10_000) {
    const now = Date.now();
    for (const [cooldownKey, timestamp] of slotCooldowns) {
      if (now - timestamp >= slotCooldownMs) slotCooldowns.delete(cooldownKey);
    }
  }

  return updateAccount(guildId, userId, (account) => {
    const now = Date.now();
    const previousBet = slotCooldowns.get(key) ?? 0;
    if (now - previousBet < slotCooldownMs) {
      const secondsLeft = Math.ceil((slotCooldownMs - (now - previousBet)) / 1000);
      return {
        error: `Wait ${secondsLeft} second${secondsLeft === 1 ? "" : "s"} before playing slots again.`,
        balance: account.balance,
      };
    }
    if (!Number.isSafeInteger(wager) || wager < 1 || wager > 1000) {
      return { error: "Bet between 1 and 1,000 multicoins.", balance: account.balance };
    }
    if (wager > account.balance) {
      return { error: "You don't have enough multicoins for that bet.", balance: account.balance };
    }

    slotCooldowns.set(key, now);
    account.balance -= wager;
    const result = playGame("slots", wager, machineId);
    account.balance += result.payout;
    return { ...result, balance: account.balance };
  });
}
