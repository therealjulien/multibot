export const maxCommandCooldownSeconds = 8;

export function createCommandCooldown() {
  const users = new Map();
  const guilds = new Map();
  return {
    claim(userId, guildId) {
      if (users.has(userId)) {
        return { error: "⏳ Your previous bot command is still running. Please wait for it to finish." };
      }

      const guildKey = guildId ?? `dm:${userId}`;
      const active = guilds.get(guildKey) ?? new Set();
      const admission = {
        minimumTicks: 1,
        release() {
          if (!active.delete(admission)) return;
          users.delete(userId);
          if (active.size === 0) guilds.delete(guildKey);
        },
      };
      users.set(userId, admission);
      active.add(admission);
      guilds.set(guildKey, active);
      const duration = Math.min(active.size, maxCommandCooldownSeconds);
      for (const entry of active) entry.minimumTicks = Math.max(entry.minimumTicks, duration);
      return admission;
    },
  };
}

export const commandCooldown = createCommandCooldown();
