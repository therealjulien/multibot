import { PermissionFlagsBits } from "discord.js";
import { getGuildFeatureData, updateGuildFeatureData } from "./store.js";

const retainedCaseCount = 500;
const validActions = new Set(["warn", "kick", "ban", "hackban", "timeout"]);

function auditLogSettings(guild) {
  const mode = guild.auditLogMode ?? "standard";
  if (!["standard", "full"].includes(mode)) throw new Error("Saved audit-log mode is invalid.");
  if (guild.auditLogEnabled !== undefined && typeof guild.auditLogEnabled !== "boolean") {
    throw new Error("Saved audit-log enabled state is invalid.");
  }
  const channelId = guild.auditLogChannelId ?? null;
  return { channelId, mode, enabled: Boolean(channelId) && guild.auditLogEnabled !== false };
}

export function createModerationStore(featureStore = {
  getGuild: getGuildFeatureData,
  updateGuild: updateGuildFeatureData,
}) {
  return {
    async getAuditLogSettings(guildId) {
      const guild = await featureStore.getGuild(guildId);
      return auditLogSettings(guild);
    },

    async getAuditLogChannel(guildId) {
      const guild = await featureStore.getGuild(guildId);
      const settings = auditLogSettings(guild);
      return settings.enabled ? settings.channelId : null;
    },

    setAuditLogMode(guildId, mode) {
      if (!["standard", "full"].includes(mode)) throw new TypeError("Audit-log mode must be standard or full.");
      return featureStore.updateGuild(guildId, (guild) => {
        guild.auditLogMode = mode;
        return mode;
      });
    },

    setAuditLogChannel(guildId, channelId) {
      if (channelId !== null && (typeof channelId !== "string" || !channelId)) {
        throw new TypeError("An audit-log channel ID or null is required.");
      }
      return featureStore.updateGuild(guildId, (guild) => {
        guild.auditLogChannelId = channelId;
        guild.auditLogEnabled = channelId !== null;
        return channelId;
      });
    },

    setAuditLogEnabled(guildId, enabled) {
      if (typeof enabled !== "boolean") throw new TypeError("Audit-log enabled state must be a boolean.");
      return featureStore.updateGuild(guildId, (guild) => {
        if (enabled && !guild.auditLogChannelId) throw new Error("Choose an audit-log channel before enabling logs.");
        guild.auditLogEnabled = enabled;
        return enabled;
      });
    },

    createCase(guildId, details) {
      if (
        !validActions.has(details?.action) ||
        typeof details.targetId !== "string" ||
        typeof details.moderatorId !== "string"
      ) {
        throw new TypeError("Moderation case details are invalid.");
      }

      return featureStore.updateGuild(guildId, (guild) => {
        guild.moderation ??= { nextCaseNumber: 1, cases: [] };
        if (
          !guild.moderation ||
          typeof guild.moderation !== "object" ||
          !Array.isArray(guild.moderation.cases)
        ) {
          throw new Error("Moderation case data is invalid.");
        }

        const maxCaseNumber = guild.moderation.cases.reduce(
          (max, entry) => Math.max(max, entry.caseNumber ?? 0),
          0
        );
        const caseNumber = guild.moderation.nextCaseNumber ?? maxCaseNumber + 1;
        if (!Number.isSafeInteger(caseNumber) || caseNumber <= maxCaseNumber) {
          throw new Error("The next moderation case number is invalid.");
        }

        const record = {
          caseNumber,
          action: details.action,
          targetId: details.targetId,
          targetTag: details.targetTag ?? details.targetId,
          moderatorId: details.moderatorId,
          moderatorTag: details.moderatorTag ?? details.moderatorId,
          reason: (String(details.reason ?? "").trim() || "No reason provided.").slice(0, 400),
          createdAt: Date.now(),
        };
        if (Number.isSafeInteger(details.durationMs) && details.durationMs > 0) {
          record.durationMs = details.durationMs;
        }

        guild.moderation.nextCaseNumber = caseNumber + 1;
        guild.moderation.cases.push(record);
        if (guild.moderation.cases.length > retainedCaseCount) {
          guild.moderation.cases.splice(0, guild.moderation.cases.length - retainedCaseCount);
        }
        return record;
      });
    },

    async getCases(guildId, targetId, limit = 10) {
      if (!Number.isInteger(limit) || limit < 1 || limit > 25) {
        throw new RangeError("Case lookup limit must be between 1 and 25.");
      }
      const guild = await featureStore.getGuild(guildId);
      const cases = guild.moderation?.cases ?? [];
      if (!Array.isArray(cases)) throw new Error("Moderation case data is invalid.");
      return cases
        .filter((entry) => !targetId || entry.targetId === targetId)
        .sort((left, right) => right.caseNumber - left.caseNumber)
        .slice(0, limit);
    },
  };
}

const moderationStore = createModerationStore();

export const getAuditLogChannel = moderationStore.getAuditLogChannel;
export const getAuditLogSettings = moderationStore.getAuditLogSettings;
export const setAuditLogChannel = moderationStore.setAuditLogChannel;
export const setAuditLogMode = moderationStore.setAuditLogMode;
export const setAuditLogEnabled = moderationStore.setAuditLogEnabled;
export const createModerationCase = moderationStore.createCase;
export const getModerationCases = moderationStore.getCases;

export async function sendAuditLog(guild, embed) {
  const channelId = await getAuditLogChannel(guild.id);
  if (!channelId) return false;

  const channel = await guild.channels.fetch(channelId);
  if (!channel || !channel.isTextBased() || typeof channel.send !== "function") {
    throw new Error(`Configured audit-log channel ${channelId} is unavailable.`);
  }
  const botMember = guild.members.me;
  if (!botMember) throw new Error("The bot's server member is unavailable.");
  const permissions = channel.permissionsFor(botMember);
  if (!permissions?.has([
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.EmbedLinks,
  ])) {
    throw new Error(`The bot cannot send audit embeds in channel ${channelId}.`);
  }

  await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
  return true;
}
