import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { ActivityType, Events } from "discord.js";

const presencePath = fileURLToPath(new URL("../../data/presence.json", import.meta.url));
const refreshDelayMs = 5_000;
const refreshIntervalMs = 60_000;

function formatPeopleCount(count) {
  if (count < 1_000) return String(count);
  const tenths = Math.round(count / 100);
  return `${Math.floor(tenths / 10)}${tenths % 10 ? `,${tenths % 10}` : ""}k`;
}

export function createPresenceManager(filePath = presencePath) {
  let queue = Promise.resolve();
  let settings;
  let lastPresence;

  function enqueue(task) {
    const result = queue.then(task);
    queue = result.catch(() => {});
    return result;
  }

  async function load() {
    if (settings !== undefined) return settings;
    let loaded;
    try {
      loaded = JSON.parse(await readFile(filePath, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      loaded = null;
    }
    if (loaded !== null && (!loaded || !["online", "idle", "dnd", "invisible"].includes(loaded.status) ||
      typeof loaded.text !== "string" || typeof loaded.serverCount !== "boolean")) {
      throw new Error("Saved bot presence settings are invalid.");
    }
    settings = loaded;
    return settings;
  }

  function apply(client, current) {
    let count = "";
    if (current.serverCount) {
      let people = 0;
      for (const guild of client.guilds.cache.values()) {
        if (!Number.isInteger(guild.memberCount) || guild.memberCount < 0) {
          console.warn(`Member count is unavailable for guild ${guild.id}; excluding it from the presence.`);
          continue;
        }
        people += guild.memberCount;
      }
      const servers = client.guilds.cache.size;
      count = `${formatPeopleCount(people)} people in ${servers} ${servers === 1 ? "server" : "servers"}`;
    }
    const suffix = count && current.text ? ` | ${count}` : count;
    const text = current.text.slice(0, 128 - suffix.length) + suffix;
    const presence = {
      status: current.status,
      activities: text ? [{ name: text, type: current.serverCount ? ActivityType.Watching : ActivityType.Playing }] : [],
    };
    const serialized = JSON.stringify(presence);
    if (serialized !== lastPresence) {
      client.user.setPresence(presence);
      lastPresence = serialized;
    }
    return text;
  }

  return {
    set(client, next) {
      return enqueue(async () => {
        await load();
        await mkdir(dirname(filePath), { recursive: true });
        const temporaryPath = `${filePath}.${process.pid}.tmp`;
        await writeFile(temporaryPath, `${JSON.stringify(next, null, 2)}\n`, "utf8");
        await rename(temporaryPath, filePath);
        settings = next;
        return apply(client, settings);
      });
    },
    refresh(client, onlyServerCount = false) {
      return enqueue(async () => {
        const current = await load();
        if (current && (!onlyServerCount || current.serverCount)) return apply(client, current);
        return null;
      });
    },
  };
}

const manager = createPresenceManager();
export const setBotPresence = manager.set;

export function registerPresenceEvents(client, presenceManager = manager) {
  function refresh(onlyServerCount) {
    void presenceManager.refresh(client, onlyServerCount).catch((error) => {
      console.error("Could not update the bot presence:", error);
    });
  }
  let scheduled;
  function scheduleRefresh() {
    if (!client.isReady() || scheduled) return;
    scheduled = setTimeout(() => {
      scheduled = null;
      refresh(true);
    }, refreshDelayMs);
  }
  client.once(Events.ClientReady, () => {
    refresh(false);
    setInterval(() => refresh(true), refreshIntervalMs);
  });
  client.on(Events.GuildCreate, scheduleRefresh);
  client.on(Events.GuildDelete, scheduleRefresh);
  client.on(Events.GuildAvailable, scheduleRefresh);
  client.on(Events.GuildMemberAdd, scheduleRefresh);
  client.on(Events.GuildMemberRemove, scheduleRefresh);
}
