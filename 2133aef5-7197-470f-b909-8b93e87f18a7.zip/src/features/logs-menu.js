import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
  EmbedBuilder,
  PermissionFlagsBits,
} from "discord.js";
import {
  getAuditLogSettings,
  setAuditLogChannel,
  setAuditLogEnabled,
  setAuditLogMode,
} from "./moderation.js";

const prefix = "multibot:logs:";
const updating = new Set();
const defaultStore = { getAuditLogSettings, setAuditLogChannel, setAuditLogEnabled, setAuditLogMode };

export function logsSetupMenu(userId, settings) {
  const channel = settings.channelId ? `<#${settings.channelId}>` : "Not selected";
  const embed = new EmbedBuilder()
    .setColor(settings.enabled ? 0x57f287 : 0x5865f2)
    .setTitle("Modlogs setup")
    .setDescription(
      "1. Select a private log channel below to enable modlogs.\n" +
      "2. Optionally select **Use Full** for additional Discord audit events.\n" +
      "Use the module button to turn logging on or off without losing the channel or mode."
    )
    .addFields(
      { name: "Module", value: settings.enabled ? "Enabled" : "Disabled", inline: true },
      { name: "Log channel", value: channel, inline: true },
      { name: "Detail", value: settings.mode === "full" ? "Full" : "Standard", inline: true },
      {
        name: "What's logged",
        value: "Standard includes message edits/deletes, member, emoji, role and channel changes. Full adds Discord audit entries with available actor and change details.",
      },
      {
        name: "Permissions and privacy",
        value: "You need Manage Server. For Full, you and the bot also need View Audit Log. The bot needs View Channel, Send Messages and Embed Links in the log channel. Logs may contain private messages, so restrict access.",
      }
    );
  const select = new ChannelSelectMenuBuilder()
    .setCustomId(`${prefix}channel:${userId}`)
    .setPlaceholder("Choose a private modlogs channel")
    .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement);
  const buttons = [
    new ButtonBuilder()
      .setCustomId(`${prefix}toggle:${userId}`)
      .setLabel(settings.enabled ? "Disable modlogs" : "Enable modlogs")
      .setStyle(settings.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
      .setDisabled(!settings.channelId),
    new ButtonBuilder()
      .setCustomId(`${prefix}mode:${userId}`)
      .setLabel(settings.mode === "full" ? "Use Standard" : "Use Full")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(!settings.channelId),
    new ButtonBuilder()
      .setCustomId(`${prefix}close:${userId}`)
      .setLabel("Close")
      .setStyle(ButtonStyle.Secondary),
  ];
  return {
    embeds: [embed],
    components: [
      new ActionRowBuilder().addComponents(select),
      new ActionRowBuilder().addComponents(buttons),
    ],
    allowedMentions: { parse: [] },
  };
}

function fullModeProblem(interaction) {
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ViewAuditLog)) {
    return "You need View Audit Log to enable full modlogs.";
  }
  if (!interaction.guild.members.me?.permissions.has(PermissionFlagsBits.ViewAuditLog)) {
    return "I need View Audit Log to enable full modlogs.";
  }
  return null;
}

async function logChannelProblem(interaction, channelId) {
  let channel;
  try {
    channel = await interaction.guild.channels.fetch(channelId);
  } catch (error) {
    if (error.code !== 10003) throw error;
    return "That log channel no longer exists. Choose another channel.";
  }
  if (!channel || ![ChannelType.GuildText, ChannelType.GuildAnnouncement].includes(channel.type)) {
    return "Choose an available text or announcement channel for modlogs.";
  }
  const member = interaction.guild.members.resolve(interaction.user.id) ??
    await interaction.guild.members.fetch(interaction.user.id);
  if (!channel.permissionsFor(member)?.has(PermissionFlagsBits.ViewChannel)) {
    return "You need View Channel in the chosen log channel.";
  }
  const bot = interaction.guild.members.me;
  if (!bot || !channel.permissionsFor(bot)?.has([
    PermissionFlagsBits.ViewChannel,
    PermissionFlagsBits.SendMessages,
    PermissionFlagsBits.EmbedLinks,
  ])) {
    return "I need View Channel, Send Messages, and Embed Links in the chosen log channel.";
  }
  return null;
}

export function createLogsMenuHandler(store = defaultStore) {
  return async function handleLogsMenu(interaction) {
    if (!interaction.customId.startsWith(prefix)) return false;
    const [, , action, ownerId, ...extra] = interaction.customId.split(":");
    if (!interaction.guild || interaction.user.id !== ownerId ||
        !interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      await interaction.reply({ content: "Only the setup owner with Manage Server can use this menu.", ephemeral: true });
      return true;
    }
    if (extra.length ||
        !(action === "channel" && interaction.isChannelSelectMenu() ||
          ["toggle", "mode", "close"].includes(action) && interaction.isButton())) {
      await interaction.reply({ content: "That modlogs action is invalid. Run `/logs setup` again.", ephemeral: true });
      return true;
    }
    if (updating.has(interaction.guild.id)) {
      await interaction.reply({ content: "Modlogs settings are being updated. Please try again.", ephemeral: true });
      return true;
    }
    updating.add(interaction.guild.id);
    try {
      if (action === "close") {
        await interaction.update({ content: "Modlogs setup closed.", embeds: [], components: [] });
        return true;
      }
      await interaction.deferUpdate();
      const settings = await store.getAuditLogSettings(interaction.guild.id);
      let problem = null;
      if (action === "channel") {
        const channelId = interaction.values?.length === 1 ? interaction.values[0] : null;
        if (!channelId) {
          problem = "Choose one log channel.";
        } else {
          problem = settings.mode === "full" ? fullModeProblem(interaction) : null;
          problem ??= await logChannelProblem(interaction, channelId);
          if (!problem) await store.setAuditLogChannel(interaction.guild.id, channelId);
        }
      } else if (action === "toggle") {
        if (!settings.enabled) {
          problem = settings.channelId ? null : "Choose a log channel first.";
          if (!problem && settings.mode === "full") problem = fullModeProblem(interaction);
          if (!problem) problem = await logChannelProblem(interaction, settings.channelId);
        }
        if (!problem) await store.setAuditLogEnabled(interaction.guild.id, !settings.enabled);
      } else {
        const mode = settings.mode === "full" ? "standard" : "full";
        if (mode === "full") {
          problem = settings.channelId ? fullModeProblem(interaction) : "Choose a log channel first.";
        }
        if (!problem) await store.setAuditLogMode(interaction.guild.id, mode);
      }
      if (problem) {
        await interaction.followUp({ content: problem, ephemeral: true });
        return true;
      }
      const updated = await store.getAuditLogSettings(interaction.guild.id);
      await interaction.editReply(logsSetupMenu(ownerId, updated));
      return true;
    } finally {
      updating.delete(interaction.guild.id);
    }
  };
}

export const handleLogsMenu = createLogsMenuHandler();
