import { EmbedBuilder, Events } from "discord.js";
import { moderateMessage } from "./automod.js";
import { isAiThinkingContent } from "../ai.js";
import { registerAuditEvents } from "./audit-events.js";
import { startBirthdayAnnouncements } from "./birthdays.js";
import { sendAuditLog } from "./moderation.js";
import {
  primeInviteSnapshots,
  recordInviteUse,
  removeInviteSnapshot,
  updateInviteSnapshot,
} from "./invites.js";
import { handleFeatureButton } from "./interactive.js";
import { handleReactionRoleEvent } from "./reaction-roles.js";
import { handleServerBuilder } from "./server-builder.js";
import { handleLogsMenu } from "./logs-menu.js";
import {
  clearAfk,
  getAfk,
  getCustomCommand,
} from "./social.js";
import { refreshStickyMessage } from "./sticky.js";
import { startCommandTyping } from "./typing.js";
import { commandCooldown } from "./cooldown.js";
import { withCommandThinking } from "./command-progress.js";

const messageProcessing = new WeakMap();

function auditValue(value, limit = 1000) {
  const text = value?.trim() || "(empty or unavailable)";
  return text.length > limit ? `${text.slice(0, limit - 3)}...` : text;
}

async function reportAuditEvent(guild, label, embed) {
  try {
    await sendAuditLog(guild, embed);
  } catch (error) {
    console.error(`Could not write ${label} audit log for guild ${guild.id}:`, error);
  }
}

function createAuditEmbed(title, color = 0x5865f2) {
  return new EmbedBuilder().setColor(color).setTitle(title).setTimestamp();
}

export function renderCustomCommandResponse(response, context) {
  const values = {
    user: `<@${context.userId}>`,
    server: context.serverName,
    channel: context.channelName ?? "this channel",
    memberCount: String(context.memberCount),
    args: context.args?.trim() ?? "",
  };
  return response
    .replace(/\{(user|server|channel|memberCount|args)\}/g, (_, key) => values[key])
    .slice(0, 2000);
}

async function handleGuildMessage(message) {
  if (!message.guild || message.author.bot) return false;

  try {
    const reason = await moderateMessage(message);
    if (reason) return true;
  } catch (error) {
    console.error(`Automod failed for message ${message.id}:`, error);
  }

  try {
    if (await clearAfk(message.guildId, message.author.id)) {
      await message.reply({
        content: `Welcome back, <@${message.author.id}>! Your AFK status has been cleared.`,
        allowedMentions: { users: [message.author.id] },
      });
    }

    const afkUsers = [];
    for (const user of message.mentions.users.values()) {
      const afk = await getAfk(message.guildId, user.id);
      if (afk) afkUsers.push({ user, reason: afk.reason });
    }
    if (afkUsers.length) {
      const notices = afkUsers.slice(0, 5)
        .map(({ user, reason }) => `**${user.username}** is AFK${reason ? `: ${reason}` : "."}`)
        .join("\n");
      await message.reply({ content: notices, allowedMentions: { parse: [] } });
    }
  } catch (error) {
    console.error(`AFK handling failed for message ${message.id}:`, error);
  }

  const commandMatch = message.content.trim().match(/^!([a-z0-9_-]{1,32})(?:\s+([\s\S]*))?$/i);
  if (commandMatch) {
    try {
      const commandName = commandMatch[1].toLowerCase();
      const response = await getCustomCommand(message.guildId, commandName);
      if (response) {
        const admission = commandName === "help" ? null : commandCooldown.claim(message.author.id, message.guildId);
        if (admission?.error) {
          await message.reply({ content: admission.error, allowedMentions: { parse: [], repliedUser: false } });
        } else if (!admission) {
          const content = renderCustomCommandResponse(response, {
            userId: message.author.id,
            serverName: message.guild.name,
            channelName: message.channel.name,
            memberCount: message.guild.memberCount,
            args: commandMatch[2],
          });
          await message.channel.send({ content, allowedMentions: { parse: [] } });
        } else {
          const stopTyping = startCommandTyping({ channel: message.channel, commandName: `!${commandName}` });
          try {
            let progressMessage;
            const content = await withCommandThinking(
              async () => renderCustomCommandResponse(response, {
                userId: message.author.id,
                serverName: message.guild.name,
                channelName: message.channel.name,
                memberCount: message.guild.memberCount,
                args: commandMatch[2],
              }),
              async (progress) => {
                const payload = { content: progress, allowedMentions: { parse: [] } };
                if (progressMessage) await progressMessage.edit(payload);
                else progressMessage = await message.channel.send(payload);
              },
              admission,
              `!${commandName}`
            );
            await progressMessage.edit({ content, allowedMentions: { parse: [] } });
          } finally {
            stopTyping();
            admission.release();
          }
        }
      }
    } catch (error) {
      console.error(`Custom command failed for message ${message.id}:`, error);
    }
  }

  refreshStickyMessage(message);
  return false;
}

export function handleFeatureMessage(message) {
  const existing = messageProcessing.get(message);
  if (existing) return existing;
  const processing = handleGuildMessage(message);
  messageProcessing.set(message, processing);
  return processing;
}

function reportButtonFailure(interaction, error) {
  console.error(`Component interaction ${interaction.customId} failed:`, error);
  const response = { content: "I couldn't process that menu action. Please check the bot's permissions and try again.", ephemeral: true };
  if (interaction.deferred) {
    return interaction.editReply(response).catch((replyError) => {
      console.error("Could not report the component interaction failure:", replyError);
    });
  }
  if (interaction.replied) {
    return interaction.followUp(response).catch((replyError) => {
      console.error("Could not report the component interaction failure:", replyError);
    });
  }
  return interaction.reply(response).catch((replyError) => {
    console.error("Could not report the component interaction failure:", replyError);
  });
}

export function registerFeatureEvents(client, reportAudit = reportAuditEvent) {
  registerAuditEvents(client, reportAudit);
  client.once(Events.ClientReady, (readyClient) => {
    primeInviteSnapshots(readyClient);
    startBirthdayAnnouncements(readyClient);
  });

  client.on(Events.GuildMemberAdd, (member) => {
    void recordInviteUse(member);
    const embed = createAuditEmbed("Member joined", 0x57f287)
      .setDescription(`${member.user.tag} (<@${member.id}>)`)
      .addFields({ name: "Account created", value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:F>` });
    void reportAudit(member.guild, "member join", embed);
  });

  client.on(Events.GuildMemberRemove, (member) => {
    const embed = createAuditEmbed("Member left", 0xed4245)
      .setDescription(`${member.user?.tag ?? member.id} (<@${member.id}>)`);
    void reportAudit(member.guild, "member leave", embed);
  });

  client.on(Events.GuildMemberUpdate, (oldMember, newMember) => {
    const previousIds = new Set(oldMember.roles.cache.keys());
    const currentIds = new Set(newMember.roles.cache.keys());
    const added = [...currentIds]
      .filter((roleId) => !previousIds.has(roleId))
      .map((roleId) => newMember.roles.cache.get(roleId)?.name)
      .filter(Boolean);
    const removed = [...previousIds]
      .filter((roleId) => !currentIds.has(roleId))
      .map((roleId) => oldMember.roles.cache.get(roleId)?.name)
      .filter(Boolean);
    const previousTimeout = oldMember.communicationDisabledUntilTimestamp ?? null;
    const currentTimeout = newMember.communicationDisabledUntilTimestamp ?? null;
    const timeoutChanged = previousTimeout !== currentTimeout;
    const nicknameChanged = oldMember.nickname !== newMember.nickname;
    if (!added.length && !removed.length && !timeoutChanged && !nicknameChanged) return;

    const embed = createAuditEmbed("Member roles updated")
      .setDescription(`${newMember.user.tag} (<@${newMember.id}>)`);
    if (added.length) embed.addFields({ name: "Added", value: auditValue(added.join(", ")) });
    if (removed.length) embed.addFields({ name: "Removed", value: auditValue(removed.join(", ")) });
    if (nicknameChanged) {
      embed.setTitle("Member updated");
      embed.addFields({ name: "Nickname", value: `${auditValue(oldMember.nickname, 400)} → ${auditValue(newMember.nickname, 400)}` });
    }
    if (timeoutChanged) {
      embed.setTitle("Member updated");
      embed.addFields({
        name: "Timeout",
        value: currentTimeout
          ? `Active until <t:${Math.floor(currentTimeout / 1000)}:F>`
          : "Removed",
      });
    }
    void reportAudit(newMember.guild, "member role update", embed);
  });

  client.on(Events.GuildBanAdd, (ban) => {
    const embed = createAuditEmbed("Member banned", 0xed4245)
      .setDescription(`${ban.user.tag} (<@${ban.user.id}>)`);
    if (ban.reason) embed.addFields({ name: "Reason", value: auditValue(ban.reason) });
    void reportAudit(ban.guild, "member ban", embed);
  });

  client.on(Events.GuildBanRemove, (ban) => {
    const embed = createAuditEmbed("Member unbanned", 0x57f287)
      .setDescription(`${ban.user.tag} (<@${ban.user.id}>)`);
    void reportAudit(ban.guild, "member unban", embed);
  });

  client.on(Events.MessageDelete, (message) => {
    if (!message.guild) return;
    if (client.user?.id && message.author?.id === client.user.id && isAiThinkingContent(message.content)) return;
    const embed = createAuditEmbed("Message deleted", 0xed4245)
      .addFields(
        { name: "Author", value: message.author?.tag ?? "Unknown" },
        { name: "Channel", value: `<#${message.channelId}>` },
        { name: "Content", value: auditValue(message.content) }
      );
    void reportAudit(message.guild, "message deletion", embed);
  });

  client.on(Events.MessageBulkDelete, (messages) => {
    const firstMessage = messages.first();
    if (!firstMessage?.guild) return;
    const embed = createAuditEmbed("Messages bulk deleted", 0xed4245)
      .addFields(
        { name: "Channel", value: `<#${firstMessage.channelId}>` },
        { name: "Message count", value: String(messages.size) }
      );
    void reportAudit(firstMessage.guild, "bulk message deletion", embed);
  });

  client.on(Events.MessageUpdate, (oldMessage, newMessage) => {
    if (!newMessage.guild || oldMessage.content === newMessage.content) return;
    if (client.user?.id && newMessage.author?.id === client.user.id &&
        (isAiThinkingContent(oldMessage.content) || isAiThinkingContent(newMessage.content))) return;
    const embed = createAuditEmbed("Message edited")
      .addFields(
        { name: "Author", value: newMessage.author?.tag ?? "Unknown" },
        { name: "Channel", value: `<#${newMessage.channelId}>` },
        { name: "Before", value: auditValue(oldMessage.content) },
        { name: "After", value: auditValue(newMessage.content) }
      );
    void reportAudit(newMessage.guild, "message edit", embed);
  });

  client.on(Events.InviteCreate, (invite) => {
    if (invite.guild) updateInviteSnapshot(invite);
  });

  client.on(Events.InviteDelete, (invite) => {
    if (invite.guild) removeInviteSnapshot(invite);
  });

  for (const [event, added] of [[Events.MessageReactionAdd, true], [Events.MessageReactionRemove, false]]) {
    client.on(event, (reaction, user) => {
      void handleReactionRoleEvent(reaction, user, added).catch((error) => {
        console.error(`Could not ${added ? "add" : "remove"} reaction role for user ${user.id}:`, error);
      });
    });
  }

  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isButton() && !interaction.isStringSelectMenu() && !interaction.isChannelSelectMenu()) return;
    try {
      if (await handleLogsMenu(interaction)) return;
      if (await handleServerBuilder(interaction)) return;
      if (interaction.isButton()) await handleFeatureButton(interaction);
    } catch (error) {
      await reportButtonFailure(interaction, error);
    }
  });
}
