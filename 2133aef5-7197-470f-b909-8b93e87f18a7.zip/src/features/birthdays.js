import { getFeatureGuildIds } from "./store.js";
import { claimBirthdayAnnouncement, getBirthdays } from "./social.js";

let checkingBirthdays = false;
const warnedUnavailableChannels = new Set();

function getUtcDateParts(date = new Date()) {
  return {
    month: String(date.getUTCMonth() + 1).padStart(2, "0"),
    day: String(date.getUTCDate()).padStart(2, "0"),
    date: date.toISOString().slice(0, 10),
  };
}

export async function checkBirthdayAnnouncements(client) {
  if (checkingBirthdays) return;
  checkingBirthdays = true;
  try {
    const { month, day, date } = getUtcDateParts();
    for (const guildId of await getFeatureGuildIds()) {
      try {
        const settings = await getBirthdays(guildId);
        if (!settings.channelId || settings.lastAnnouncementDate === date) continue;
        const birthdayUsers = settings.birthdays
          .filter((entry) => entry.date === `${month}-${day}`)
          .map((entry) => entry.userId);
        if (!birthdayUsers.length) continue;

        const guild = client.guilds.cache.get(guildId);
        const channel = guild?.channels.cache.get(settings.channelId);
        if (!channel?.isTextBased() || !channel.send) {
          const warningKey = `${guildId}:${settings.channelId}`;
          if (!warnedUnavailableChannels.has(warningKey)) {
            warnedUnavailableChannels.add(warningKey);
            console.warn(`Birthday announcement channel ${settings.channelId} is unavailable in guild ${guildId}.`);
          }
          continue;
        }

        const mentions = birthdayUsers.slice(0, 50).map((userId) => `<@${userId}>`);
        const extraCount = birthdayUsers.length - mentions.length;
        const suffix = extraCount > 0 ? ` and ${extraCount} more` : "";
        await channel.send({
          content: `🎂 Happy birthday ${mentions.join(", ")}${suffix}!`,
          allowedMentions: { users: birthdayUsers.slice(0, 50) },
        });
        await claimBirthdayAnnouncement(guildId, date);
      } catch (error) {
        console.error(`Could not announce birthdays in guild ${guildId}:`, error);
      }
    }
  } catch (error) {
    console.error("Could not check birthday announcements:", error);
  } finally {
    checkingBirthdays = false;
  }
}

export function startBirthdayAnnouncements(client) {
  const timer = setInterval(() => {
    void checkBirthdayAnnouncements(client);
  }, 60_000);
  timer.unref();
  void checkBirthdayAnnouncements(client);
}
