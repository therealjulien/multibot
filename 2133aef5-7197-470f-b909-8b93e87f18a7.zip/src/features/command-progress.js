import { MessageFlags, MessageFlagsBitField } from "discord.js";
import { commandCooldown, maxCommandCooldownSeconds } from "./cooldown.js";
import { startCommandTyping } from "./typing.js";

const intervalMs = 1_000;
export const waitForCommandCooldown = Symbol("waitForCommandCooldown");

function createCommandAnimation(update, admission, commandName) {
  let ticks = 0;
  let pending = Promise.resolve();
  const waiters = new Set();
  let timer = setInterval(() => {
    ticks++;
    pending = pending.then(() => update(`⏳${".".repeat(ticks)}`)).catch((error) => {
      console.error(`Could not update command progress for ${commandName}:`, error);
    });
    if (ticks >= admission.minimumTicks) {
      for (const resolve of waiters) resolve();
      waiters.clear();
    }
    if (ticks >= maxCommandCooldownSeconds) {
      clearInterval(timer);
      timer = null;
    }
  }, intervalMs);

  return {
    wait() {
      if (ticks >= admission.minimumTicks) return Promise.resolve();
      return new Promise((resolve) => waiters.add(resolve));
    },
    async stop() {
      if (timer !== null) clearInterval(timer);
      timer = null;
      for (const resolve of waiters) resolve();
      waiters.clear();
      await pending;
    },
  };
}

export async function withCommandThinking(operation, update, admission, commandName) {
  await update("⏳");
  const animation = createCommandAnimation(update, admission, commandName);
  try {
    const result = await operation();
    await animation.wait();
    return result;
  } finally {
    await animation.stop();
  }
}

export function createCommandProgress(interaction, admission = { minimumTicks: 1 }) {
  const reply = interaction.reply.bind(interaction);
  const deferReply = interaction.deferReply.bind(interaction);
  const editReply = interaction.editReply.bind(interaction);
  let animation;
  let pendingResponse = false;

  function startAnimation() {
    animation = createCommandAnimation(
      (content) => editReply({ content, allowedMentions: { parse: [] } }),
      admission,
      `/${interaction.commandName}`
    );
  }

  async function stopAnimation(waitForMinimum) {
    const state = animation;
    if (!state) return;
    if (waitForMinimum) await state.wait();
    if (animation === state) animation = null;
    await state.stop();
  }

  async function finish(payload) {
    await stopAnimation(true);
    const resultPayload = pendingResponse && typeof payload === "object" && payload.content === undefined
      ? { ...payload, content: null }
      : payload;
    const result = await editReply(resultPayload);
    pendingResponse = false;
    return result;
  }

  const wrapped = new Proxy(interaction, {
    get(target, property) {
      if (property === waitForCommandCooldown) return () => animation?.wait() ?? Promise.resolve();
      if (property === "reply") {
        return async (options) => {
          const payload = typeof options === "string" ? { content: options } : options;
          const flags = new MessageFlagsBitField(payload.flags ?? 0);
          const ephemeral = payload.ephemeral === true || flags.has(MessageFlags.Ephemeral);
          await reply({ content: "⏳", ephemeral, allowedMentions: { parse: [] } });
          pendingResponse = true;
          startAnimation();
          const { ephemeral: ignoredEphemeral, withResponse, fetchReply, flags: originalFlags, ...edit } = payload;
          if (originalFlags !== undefined) {
            const remainingFlags = flags.remove(MessageFlags.Ephemeral);
            if (remainingFlags.bitfield) edit.flags = remainingFlags;
          }
          if (edit.content === undefined) edit.content = null;
          return finish(edit);
        };
      }
      if (property === "deferReply") {
        return async (options) => {
          const result = await deferReply(options);
          pendingResponse = true;
          await editReply({ content: "⏳", allowedMentions: { parse: [] } });
          startAnimation();
          return result;
        };
      }
      if (property === "editReply") return finish;
      const value = Reflect.get(target, property, target);
      return typeof value === "function" ? value.bind(target) : value;
    },
  });

  return {
    interaction: wrapped,
    get pendingResponse() { return pendingResponse; },
    stop: () => stopAnimation(false),
  };
}

export async function runCommand(interaction, command, cooldown = commandCooldown) {
  const admission = interaction.commandName === "help" ? null : cooldown.claim(interaction.user.id, interaction.guildId);
  if (admission?.error) {
    await interaction.reply({ content: admission.error, ephemeral: true });
    return;
  }
  const stopTyping = startCommandTyping(interaction);
  const progress = admission ? createCommandProgress(interaction, admission) : null;
  try {
    await command.execute(progress?.interaction ?? interaction);
  } catch (error) {
    console.error(`Command /${interaction.commandName} failed:`, error);
    const message = "That command failed. Check the bot's permissions and try again.";
    if (progress) await progress.stop();
    if (interaction.deferred || progress?.pendingResponse) {
      await interaction.editReply({ content: message });
    } else if (interaction.replied) {
      await interaction.followUp({ content: message, ephemeral: true });
    } else {
      await interaction.reply({ content: message, ephemeral: true });
    }
  } finally {
    if (progress) await progress.stop();
    stopTyping();
    admission?.release();
  }
}
