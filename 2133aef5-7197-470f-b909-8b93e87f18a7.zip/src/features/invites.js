import { getGuildFeatureData, updateGuildFeatureData } from "./store.js";

const inviteSnapshots = new Map();

function snapshotInvites(invites) {
  return new Map([...invites.values()].map((invite) => [invite.code, invite.uses ?? 0]));
}

export async function primeInviteSnapshots(client) {
  for (const guild of client.guilds.cache.values()) {
    try {
      inviteSnapshots.set(guild.id, snapshotInvites(await guild.invites.fetch()));
    } catch (error) {
      console.warn(`Could not load invites for guild ${guild.id}:`, error.message);
    }
  }
}

export function updateInviteSnapshot(invite) {
  const snapshot = inviteSnapshots.get(invite.guild.id) ?? new Map();
  snapshot.set(invite.code, invite.uses ?? 0);
  inviteSnapshots.set(invite.guild.id, snapshot);
}

export function removeInviteSnapshot(invite) {
  inviteSnapshots.get(invite.guild.id)?.delete(invite.code);
}

export async function recordInviteUse(member) {
  const before = inviteSnapshots.get(member.guild.id);
  try {
    const invites = await member.guild.invites.fetch();
    const after = snapshotInvites(invites);
    inviteSnapshots.set(member.guild.id, after);
    if (!before) return null;

    const usedInvite = [...invites.values()].find((invite) =>
      invite.inviter && (before.get(invite.code) ?? 0) < (invite.uses ?? 0)
    );
    if (!usedInvite) return null;

    await updateGuildFeatureData(member.guild.id, (guild) => {
      guild.inviteCounts ??= {};
      guild.inviteCounts[usedInvite.inviter.id] = (guild.inviteCounts[usedInvite.inviter.id] ?? 0) + 1;
    });
    return usedInvite.inviter.id;
  } catch (error) {
    console.warn(`Could not track invite for member ${member.id} in guild ${member.guild.id}:`, error.message);
    return null;
  }
}

export async function getInviteCount(guildId, userId) {
  const guild = await getGuildFeatureData(guildId);
  return guild.inviteCounts?.[userId] ?? 0;
}
