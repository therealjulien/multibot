import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { fileURLToPath } from "node:url";

const featurePath = fileURLToPath(new URL("../../data/features.json", import.meta.url));

export function createFeatureStore(filePath = featurePath) {
  let queue = Promise.resolve();
  let cachedData;

  async function readData() {
    let data;
    try {
      data = JSON.parse(await readFile(filePath, "utf8"));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      return { guilds: {} };
    }

    if (!data || typeof data !== "object" || Array.isArray(data)) {
      throw new Error("Feature data must be a JSON object.");
    }
    data.guilds ??= {};
    if (typeof data.guilds !== "object" || Array.isArray(data.guilds)) {
      throw new Error("Feature data must contain a guilds object.");
    }
    return data;
  }

  async function loadData() {
    if (!cachedData) cachedData = await readData();
    return cachedData;
  }

  function enqueue(task) {
    const result = queue.then(task);
    queue = result.catch(() => {});
    return result;
  }

  return {
    getGuild(guildId) {
      return enqueue(async () => {
        const data = await loadData();
        return structuredClone(data.guilds[guildId] ?? {});
      });
    },

    getGuildIds() {
      return enqueue(async () => Object.keys((await loadData()).guilds));
    },

    updateGuild(guildId, update) {
      if (typeof guildId !== "string" || !guildId || typeof update !== "function") {
        throw new TypeError("A guild ID and update function are required.");
      }

      return enqueue(async () => {
        const data = structuredClone(await loadData());
        const guild = data.guilds[guildId] ??= {};
        const result = update(guild);
        await mkdir(dirname(filePath), { recursive: true });
        const temporaryPath = `${filePath}.${process.pid}.tmp`;
        await writeFile(temporaryPath, `${JSON.stringify(data, null, 2)}\n`, "utf8");
        await rename(temporaryPath, filePath);
        cachedData = data;
        return structuredClone(result);
      });
    },
  };
}

const featureStore = createFeatureStore();

export const getGuildFeatureData = featureStore.getGuild;
export const getFeatureGuildIds = featureStore.getGuildIds;
export const updateGuildFeatureData = featureStore.updateGuild;
