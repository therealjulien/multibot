import { getGuildFeatureData, updateGuildFeatureData } from "./store.js";

export function createLevelRewardStore(featureStore = {
  getGuild: getGuildFeatureData,
  updateGuild: updateGuildFeatureData,
}) {
  return {
    async list(guildId) {
      const guild = await featureStore.getGuild(guildId);
      const rewards = guild.levelRoleRewards ?? {};
      if (!rewards || typeof rewards !== "object" || Array.isArray(rewards)) {
        throw new Error("Level role reward data is invalid.");
      }
      const entries = Object.entries(rewards)
        .map(([level, roleId]) => ({ level: Number(level), roleId }))
        .sort((left, right) => left.level - right.level);
      if (entries.some(({ level, roleId }) => !Number.isSafeInteger(level) || level < 1 || typeof roleId !== "string" || !roleId)) {
        throw new Error("Level role reward data is invalid.");
      }
      return entries;
    },

    set(guildId, level, roleId) {
      if (!Number.isSafeInteger(level) || level < 1 || typeof roleId !== "string" || !roleId) {
        throw new TypeError("A positive level and role ID are required.");
      }
      return featureStore.updateGuild(guildId, (guild) => {
        guild.levelRoleRewards ??= {};
        if (
          typeof guild.levelRoleRewards !== "object" ||
          Array.isArray(guild.levelRoleRewards)
        ) {
          throw new Error("Level role reward data is invalid.");
        }
        guild.levelRoleRewards[String(level)] = roleId;
        return { level, roleId };
      });
    },

    remove(guildId, level) {
      if (!Number.isSafeInteger(level) || level < 1) {
        throw new TypeError("A positive level is required.");
      }
      return featureStore.updateGuild(guildId, (guild) => {
        if (
          guild.levelRoleRewards &&
          (typeof guild.levelRoleRewards !== "object" || Array.isArray(guild.levelRoleRewards))
        ) {
          throw new Error("Level role reward data is invalid.");
        }
        if (!guild.levelRoleRewards || !Object.hasOwn(guild.levelRoleRewards, String(level))) {
          return false;
        }
        delete guild.levelRoleRewards[String(level)];
        return true;
      });
    },
  };
}

const levelRewardStore = createLevelRewardStore();

export const getLevelRoleRewards = levelRewardStore.list;
export const setLevelRoleReward = levelRewardStore.set;
export const removeLevelRoleReward = levelRewardStore.remove;

export async function applyLevelRoleReward(member, level, listRewards = getLevelRoleRewards) {
  const rewards = await listRewards(member.guild.id);
  const reward = rewards.filter((entry) => entry.level <= level).at(-1);
  if (!reward) return null;

  const role = await member.guild.roles.fetch(reward.roleId);
  if (!role) throw new Error(`Configured level ${reward.level} role no longer exists.`);
  if (!role.editable) {
    throw new Error(`Configured level ${reward.level} role is not below the bot's highest role.`);
  }

  const managedRewardIds = new Set(rewards.map((entry) => entry.roleId));
  const previousRoles = member.roles.cache.filter(
    (currentRole) => managedRewardIds.has(currentRole.id) && currentRole.id !== role.id
  );
  const uneditableRole = previousRoles.find((currentRole) => !currentRole.editable);
  if (uneditableRole) {
    throw new Error(`Previous level reward role ${uneditableRole.id} is not below the bot's highest role.`);
  }

  if (!member.roles.cache.has(role.id)) {
    await member.roles.add(role, `Reached level ${level}`);
  }
  if (previousRoles.size) {
    await member.roles.remove(previousRoles, `Replaced with level ${reward.level} reward`);
  }
  return role;
}
