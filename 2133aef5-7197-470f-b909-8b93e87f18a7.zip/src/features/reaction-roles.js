import { getGuildFeatureData, updateGuildFeatureData } from "./store.js";
import { isSafeReactionRole } from "./interactive.js";

export function emojiKey(input) {
  const custom = input.match(/^<a?:\w{2,32}:(\d{17,20})>$/);
  if (custom) return custom[1];
  if (/^\d{17,20}$/.test(input)) return input;
  if (/[\p{Extended_Pictographic}\p{Regional_Indicator}\u20e3]/u.test(input) &&
      !/[\p{L}\p{White_Space}]/u.test(input)) return input;
  return null;
}

export function createReactionRoleStore(updateGuild = updateGuildFeatureData) {
  return {
    add(guildId, messageId, channelId, emoji, roleId) {
      return updateGuild(guildId, (guild) => {
        guild.reactionAssignments ??= {};
        const panel = guild.reactionAssignments[messageId] ??= { channelId, roles: {} };
        if (panel.channelId !== channelId) throw new Error("Reaction-role channel does not match.");
        if (panel.roles[emoji]) return "emoji";
        if (Object.values(panel.roles).includes(roleId)) return "role";
        panel.roles[emoji] = roleId;
        return null;
      });
    },
    remove(guildId, messageId, emoji) {
      return updateGuild(guildId, (guild) => {
        const panel = guild.reactionAssignments?.[messageId];
        if (!panel) return null;
        if (emoji) {
          if (!panel.roles[emoji]) return null;
          delete panel.roles[emoji];
          if (!Object.keys(panel.roles).length) delete guild.reactionAssignments[messageId];
        } else {
          delete guild.reactionAssignments[messageId];
        }
        return panel;
      });
    },
  };
}

const reactionRoleStore = createReactionRoleStore();
export const addReactionRole = reactionRoleStore.add;
export const removeReactionAssignments = reactionRoleStore.remove;

const pending = new Map();

export function handleReactionRoleEvent(reaction, user, added, getData = getGuildFeatureData) {
  if (user.bot) return Promise.resolve();
  const key = `${reaction.message.id}:${user.id}:${reaction.emoji.id ?? reaction.emoji.name}`;
  const previous = pending.get(key) ?? Promise.resolve();
  const current = previous.catch(() => {}).then(async () => {
    const message = reaction.message;
    if (!message.guild) return;
    const emoji = reaction.emoji.id ?? reaction.emoji.name;
    const data = await getData(message.guild.id);
    const panel = data.reactionAssignments?.[message.id];
    const roleId = panel?.channelId === message.channelId ? panel.roles[emoji] : null;
    if (!roleId) return;
    if (user.partial) await user.fetch();
    if (user.bot) return;
    if (reaction.partial) await reaction.fetch();
    const role = await message.guild.roles.fetch(roleId);
    if (!role || !role.editable || !isSafeReactionRole(role)) {
      console.error(`Reaction role ${roleId} in guild ${message.guild.id} is missing, unassignable, or unsafe.`);
      return;
    }
    const member = await message.guild.members.fetch(user.id);
    if (added) {
      await member.roles.add(role, "Member added a Multibot role reaction");
    } else {
      await member.roles.remove(role, "Member removed a Multibot role reaction");
    }
  });
  pending.set(key, current);
  return current.finally(() => {
    if (pending.get(key) === current) pending.delete(key);
  });
}
