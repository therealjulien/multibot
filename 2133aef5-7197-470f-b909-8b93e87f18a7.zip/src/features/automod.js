import { getGuildFeatureData, updateGuildFeatureData } from "./store.js";

const defaultConfig = {
  enabled: false,
  blockInvites: false,
  blockedWords: [],
};

export async function getAutomodConfig(guildId) {
  const guild = await getGuildFeatureData(guildId);
  return { ...defaultConfig, ...(guild.automod ?? {}) };
}

export async function updateAutomodConfig(guildId, update) {
  return updateGuildFeatureData(guildId, (guild) => {
    guild.automod = { ...defaultConfig, ...(guild.automod ?? {}), ...update };
    return { ...guild.automod };
  });
}

export async function addBlockedWord(guildId, word) {
  const normalized = word.trim().toLocaleLowerCase();
  if (!normalized) return false;
  return updateGuildFeatureData(guildId, (guild) => {
    guild.automod = { ...defaultConfig, ...(guild.automod ?? {}) };
    if (guild.automod.blockedWords.some((item) => item.toLocaleLowerCase() === normalized)) {
      return false;
    }
    if (guild.automod.blockedWords.length >= 50) return false;
    guild.automod.blockedWords.push(normalized);
    return true;
  });
}

export async function removeBlockedWord(guildId, word) {
  const normalized = word.trim().toLocaleLowerCase();
  return updateGuildFeatureData(guildId, (guild) => {
    guild.automod = { ...defaultConfig, ...(guild.automod ?? {}) };
    const index = guild.automod.blockedWords.findIndex((item) => item.toLocaleLowerCase() === normalized);
    if (index < 0) return false;
    guild.automod.blockedWords.splice(index, 1);
    return true;
  });
}

export function getModerationReason(content, config) {
  if (!config.enabled) return null;
  const normalizedContent = content.toLocaleLowerCase();
  const hasInvite = config.blockInvites &&
    /(?:discord\.gg\/|discord(?:app)?\.com\/invite\/)[a-z0-9-]+/i.test(normalizedContent);
  const matchedWord = config.blockedWords.find((word) => {
    const escaped = word.toLocaleLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`(^|[^\\p{L}\\p{N}_])${escaped}(?=$|[^\\p{L}\\p{N}_])`, "iu").test(normalizedContent);
  });
  return hasInvite ? "invite" : matchedWord ? "blocked-word" : null;
}

export async function moderateMessage(message) {
  const config = await getAutomodConfig(message.guildId);
  const reason = getModerationReason(message.content, config);
  if (!reason) return null;

  await message.delete();
  return reason;
}
