import { AuditLogEvent, EmbedBuilder, Events } from "discord.js";
import { getAuditLogSettings } from "./moderation.js";

function embed(title, description, color = 0x5865f2) {
  return new EmbedBuilder().setColor(color).setTitle(title).setDescription(description).setTimestamp();
}

function display(value) {
  return String(value ?? "(none)").slice(0, 400);
}

function changedFields(before, after, properties) {
  const changes = [];
  for (const [label, key] of properties) {
    if (before[key] !== after[key]) {
      changes.push({ name: label, value: `${display(before[key])} → ${display(after[key])}` });
    }
  }
  return changes;
}

function overwriteSnapshot(channel) {
  const cache = channel.permissionOverwrites?.cache;
  if (!cache) return null;
  return [...cache.values()].map((entry) =>
    `${entry.id}:${entry.type}:${entry.allow.bitfield}:${entry.deny.bitfield}`
  ).sort().join("|");
}

function auditChangeValue(key, value) {
  const sensitive = /token|secret|password|webhook|invite|code|url/i;
  if (sensitive.test(key)) return "[redacted]";
  if (value === undefined || value === null) return "(none)";
  const text = typeof value === "string" ? value : JSON.stringify(value, (name, entry) =>
    sensitive.test(name) ? "[redacted]" : typeof entry === "bigint" ? entry.toString() : entry
  );
  const result = String(text);
  return result.length > 100 ? `${result.slice(0, 97)}...` : result;
}

export function createFullAuditEmbed(entry) {
  const action = AuditLogEvent[entry.action] ?? `Unknown action ${entry.action}`;
  const result = embed("Discord audit event", `**${action}** · Entry \`${entry.id}\``)
    .addFields(
      { name: "Moderator", value: entry.executorId ? `<@${entry.executorId}> (\`${entry.executorId}\`)` : "Unavailable", inline: true },
      { name: "Target", value: `${entry.targetType ?? "Unknown"}${entry.targetId ? ` · \`${entry.targetId}\`` : ""}`, inline: true }
    );
  if (entry.reason) result.addFields({ name: "Reason", value: display(entry.reason) });
  const changes = entry.changes ?? [];
  for (const change of changes.slice(0, 16)) {
    result.addFields({
      name: display(change.key).slice(0, 80),
      value: `Before: ${auditChangeValue(change.key, change.old)}\nAfter: ${auditChangeValue(change.key, change.new)}`,
    });
  }
  if (changes.length > 16) result.addFields({ name: "More changes", value: `${changes.length - 16} additional changes omitted.` });
  return result;
}

export function registerAuditEvents(client, report, getSettings = getAuditLogSettings) {
  client.on(Events.GuildAuditLogEntryCreate, (entry, guild) => {
    void (async () => {
      const settings = await getSettings(guild.id);
      if (settings.enabled && settings.channelId && settings.mode === "full") {
        await report(guild, "Discord audit event", createFullAuditEmbed(entry));
      }
    })().catch((error) => {
      console.error(`Could not process Discord audit event for guild ${guild.id}:`, error);
    });
  });
  client.on(Events.GuildEmojiCreate, (emoji) => {
    void report(emoji.guild, "emoji creation", embed("Emoji created", `${emoji.name} (\`${emoji.id}\`)`, 0x57f287));
  });
  client.on(Events.GuildEmojiDelete, (emoji) => {
    void report(emoji.guild, "emoji deletion", embed("Emoji deleted", `${emoji.name} (\`${emoji.id}\`)`, 0xed4245));
  });
  client.on(Events.GuildEmojiUpdate, (before, after) => {
    const fields = changedFields(before, after, [["Name", "name"], ["Available", "available"]]);
    if (!fields.length) return;
    void report(after.guild, "emoji update", embed("Emoji updated", `Emoji ID: \`${after.id}\``).addFields(fields));
  });

  client.on(Events.GuildRoleCreate, (role) => {
    void report(role.guild, "role creation", embed("Role created", `${role.name} (\`${role.id}\`)`, 0x57f287));
  });
  client.on(Events.GuildRoleDelete, (role) => {
    void report(role.guild, "role deletion", embed("Role deleted", `${role.name} (\`${role.id}\`)`, 0xed4245));
  });
  client.on(Events.GuildRoleUpdate, (before, after) => {
    const fields = changedFields(before, after, [
      ["Name", "name"], ["Color", "hexColor"], ["Position", "rawPosition"],
      ["Displayed separately", "hoist"], ["Mentionable", "mentionable"],
    ]);
    if (before.permissions.bitfield !== after.permissions.bitfield) {
      fields.push({
        name: "Permissions",
        value: `${display(before.permissions.toArray().join(", ") || "(none)")} → ${display(after.permissions.toArray().join(", ") || "(none)")}`,
      });
    }
    if (!fields.length) return;
    void report(after.guild, "role update", embed("Role updated", `Role: <@&${after.id}> (\`${after.id}\`)`).addFields(fields));
  });

  client.on(Events.ChannelCreate, (channel) => {
    if (!channel.guild) return;
    void report(channel.guild, "channel creation", embed("Channel created", `${channel.name} (\`${channel.id}\`) · Type ${channel.type}`, 0x57f287));
  });
  client.on(Events.ChannelDelete, (channel) => {
    if (!channel.guild) return;
    void report(channel.guild, "channel deletion", embed("Channel deleted", `${channel.name} (\`${channel.id}\`) · Type ${channel.type}`, 0xed4245));
  });
  client.on(Events.ChannelUpdate, (before, after) => {
    if (!after.guild) return;
    const fields = changedFields(before, after, [
      ["Name", "name"], ["Topic", "topic"], ["Category ID", "parentId"], ["Type", "type"], ["Position", "rawPosition"],
      ["Age restricted", "nsfw"], ["Slowmode (seconds)", "rateLimitPerUser"], ["Voice bitrate", "bitrate"],
      ["Voice user limit", "userLimit"],
    ]);
    const previousOverwrites = overwriteSnapshot(before);
    const currentOverwrites = overwriteSnapshot(after);
    if (previousOverwrites !== null && currentOverwrites !== null && previousOverwrites !== currentOverwrites) {
      fields.push({ name: "Permissions", value: "Channel permission overwrites changed." });
    }
    if (!fields.length) return;
    void report(after.guild, "channel update", embed("Channel updated", `Channel: <#${after.id}> (\`${after.id}\`)`).addFields(fields));
  });

  client.on(Events.GuildUpdate, (before, after) => {
    const fields = changedFields(before, after, [
      ["Name", "name"], ["Verification level", "verificationLevel"], ["Content filter", "explicitContentFilter"],
      ["AFK channel ID", "afkChannelId"], ["System channel ID", "systemChannelId"], ["Icon", "icon"],
    ]);
    if (!fields.length) return;
    void report(after, "server update", embed("Server settings updated", `Server ID: \`${after.id}\``).addFields(fields));
  });
}
