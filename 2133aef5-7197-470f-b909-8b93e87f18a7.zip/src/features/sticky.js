import { getGuildFeatureData, updateGuildFeatureData } from "./store.js";

const channelQueues = new Map();

export async function setStickyMessage(guildId, channelId, content) {
  return updateGuildFeatureData(guildId, (guild) => {
    const previous = guild.stickyMessages?.[channelId] ?? null;
    guild.stickyMessages ??= {};
    guild.stickyMessages[channelId] = { content, messageId: previous?.messageId ?? null };
    return previous;
  });
}

export async function setStickyMessageId(guildId, channelId, messageId) {
  return updateGuildFeatureData(guildId, (guild) => {
    const sticky = guild.stickyMessages?.[channelId];
    if (sticky) sticky.messageId = messageId;
  });
}

export async function clearStickyMessage(guildId, channelId) {
  return updateGuildFeatureData(guildId, (guild) => {
    const previous = guild.stickyMessages?.[channelId];
    if (!previous) return null;
    delete guild.stickyMessages[channelId];
    return previous;
  });
}

export async function getStickyMessage(guildId, channelId) {
  const guild = await getGuildFeatureData(guildId);
  return guild.stickyMessages?.[channelId] ?? null;
}

export function refreshStickyMessage(message) {
  const key = `${message.guildId}:${message.channelId}`;
  const previous = channelQueues.get(key) ?? Promise.resolve();
  const next = previous.then(async () => {
    const sticky = await getStickyMessage(message.guildId, message.channelId);
    if (!sticky) return;

    if (sticky.messageId) {
      try {
        await message.channel.messages.delete(sticky.messageId);
      } catch (error) {
        if (error.code !== 10008) throw error;
      }
    }

    const posted = await message.channel.send({
      content: sticky.content,
      allowedMentions: { parse: [] },
    });
    await setStickyMessageId(message.guildId, message.channelId, posted.id);
  });
  channelQueues.set(key, next.catch((error) => {
    console.error(`Could not refresh sticky message in channel ${message.channelId}:`, error);
  }));
}
