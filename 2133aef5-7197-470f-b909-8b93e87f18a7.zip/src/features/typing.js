const refreshMs = 8_000;

export function startCommandTyping(interaction) {
  const channel = interaction.channel;
  if (typeof channel?.sendTyping !== "function") return () => {};
  const send = () => {
    Promise.resolve().then(() => channel.sendTyping()).catch((error) => {
      console.error(`Could not send typing status for command ${interaction.commandName}:`, error);
    });
  };
  send();
  const timer = setInterval(send, refreshMs);
  return () => clearInterval(timer);
}
