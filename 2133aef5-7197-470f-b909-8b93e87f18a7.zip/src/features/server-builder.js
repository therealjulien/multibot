import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } from "discord.js";

export const builderTemplates = {
  gaming: {
    label: "Gaming Server", button: "Gaming", emoji: "🎮",
    channels: ["game-chat", "looking-for-group", "game-news", "game-clips", "game-screenshots", "game-recommendations", "game-guides", "game-events", "team-recruitment", "off-topic"],
  },
  community: {
    label: "Community Server", button: "Community", emoji: "🌐",
    channels: ["welcome", "rules", "announcements", "community-chat", "introductions", "questions", "suggestions", "events", "media-sharing", "off-topic"],
  },
  tech: {
    label: "Tech Server", button: "Tech", emoji: "💻",
    channels: ["tech-chat", "help", "projects", "coding", "hardware", "software", "tech-news", "resources", "showcase", "troubleshooting"],
  },
  hangout: {
    label: "Hangout Server", button: "Hangout", emoji: "☕",
    channels: ["general-chat", "introductions", "off-topic", "media", "memes", "music", "movies-and-tv", "food-and-drink", "hobbies", "events"],
  },
};

const prefix = "multibot:builder:";
const building = new Set();
const updatingMenus = new Set();

function categoryName(guildName, label) {
  const suffix = ` - ${label}`;
  return `${guildName.slice(0, 100 - suffix.length)}${suffix}`;
}

export function builderMenu(userId, selected = []) {
  const state = selected.join(",") || "-";
  const categories = new ActionRowBuilder().addComponents(
    ...Object.entries(builderTemplates).map(([value, template]) =>
      new ButtonBuilder()
        .setCustomId(`${prefix}toggle:${userId}:${state}:${value}`)
        .setLabel(template.button)
        .setEmoji(template.emoji)
        .setStyle(selected.includes(value) ? ButtonStyle.Success : ButtonStyle.Secondary)
    )
  );
  const actions = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`${prefix}all:${userId}:${state}`).setLabel("Select all").setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`${prefix}clear:${userId}:${state}`).setLabel("Clear").setStyle(ButtonStyle.Secondary).setDisabled(!selected.length),
    new ButtonBuilder().setCustomId(`${prefix}create:${userId}:${state}`).setLabel("Create selected").setStyle(ButtonStyle.Success).setDisabled(!selected.length)
  );
  return [categories, actions];
}

function builderPreview(guildName, choices) {
  if (!choices.length) return `Choose categories for **${guildName}** using the buttons below. Each adds 10 text channels and one general voice channel.`;
  const preview = choices.map((choice) => {
    const template = builderTemplates[choice];
    return `**${categoryName(guildName, template.label)}**\n${template.channels.map((name) => `#${name}`).join(", ")}\nVoice: General`;
  }).join("\n\n");
  return `Selected categories (press a button again to remove it). Existing matching channels are kept.\n\n${preview}`;
}

export async function handleServerBuilder(interaction) {
  if (!interaction.customId.startsWith(prefix)) return false;
  const [, , action, ownerId, selected, target, ...extra] = interaction.customId.split(":");
  if (interaction.user.id !== ownerId || !interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) {
    await interaction.reply({ content: "Only the setup owner with Manage Channels can use this menu.", ephemeral: true });
    return true;
  }
  const choices = action === "select" ? interaction.values : selected === "-" ? [] : selected?.split(",");
  if (extra.length || !choices || new Set(choices).size !== choices.length || choices.some((choice) => !Object.hasOwn(builderTemplates, choice))) {
    await interaction.reply({ content: "That server builder selection is invalid. Run `/server-builder` again.", ephemeral: true });
    return true;
  }
  const isSelection = (action === "select" && interaction.isStringSelectMenu()) ||
    (["toggle", "all", "clear"].includes(action) && interaction.isButton());
  if (isSelection) {
    if ((action === "toggle" && !Object.hasOwn(builderTemplates, target)) ||
        (action !== "toggle" && target !== undefined)) {
      await interaction.reply({ content: "That server builder action is invalid.", ephemeral: true });
      return true;
    }
    if (building.has(interaction.guildId)) {
      await interaction.reply({ content: "A server build is already in progress. Try again when it finishes.", ephemeral: true });
      return true;
    }
    const key = `${interaction.guildId}:${interaction.message.id}`;
    if (updatingMenus.has(key)) {
      await interaction.reply({ content: "Please wait for the selection to update.", ephemeral: true });
      return true;
    }
    updatingMenus.add(key);
    try {
      const selectedChoices = new Set(choices);
      if (action === "toggle") {
        if (selectedChoices.has(target)) selectedChoices.delete(target);
        else selectedChoices.add(target);
      } else if (action === "all") {
        for (const choice of Object.keys(builderTemplates)) selectedChoices.add(choice);
      } else if (action === "clear") {
        selectedChoices.clear();
      }
      const next = Object.keys(builderTemplates).filter((choice) => selectedChoices.has(choice));
      await interaction.update({ content: builderPreview(interaction.guild.name, next), components: builderMenu(ownerId, next), allowedMentions: { parse: [] } });
    } finally {
      updatingMenus.delete(key);
    }
    return true;
  }
  if (action !== "create" || !interaction.isButton() || !choices.length || target !== undefined) {
    await interaction.reply({ content: "That server builder action is invalid.", ephemeral: true });
    return true;
  }
  if (interaction.message?.id && updatingMenus.has(`${interaction.guildId}:${interaction.message.id}`)) {
    await interaction.reply({ content: "Please wait for the selection to update.", ephemeral: true });
    return true;
  }
  if (!interaction.guild.members.me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
    await interaction.reply({ content: "I need Manage Channels to build the server.", ephemeral: true });
    return true;
  }
  if (building.has(interaction.guildId)) {
    await interaction.reply({ content: "A server build is already in progress. Try again when it finishes.", ephemeral: true });
    return true;
  }
  building.add(interaction.guildId);
  const created = [];
  try {
    await interaction.deferUpdate();
    await interaction.editReply({ content: "Creating the selected categories and channels...", components: [] });
    await interaction.guild.channels.fetch();
    for (const choice of choices) {
      const template = builderTemplates[choice];
      const name = categoryName(interaction.guild.name, template.label);
      let category = interaction.guild.channels.cache.find((channel) => channel.type === ChannelType.GuildCategory && channel.name === name);
      if (!category) {
        category = await interaction.guild.channels.create({ name, type: ChannelType.GuildCategory, reason: `Server builder requested by ${interaction.user.tag}` });
        created.push(`Category: ${name}`);
      }
      const channels = [...template.channels.map((channelName) => [channelName, ChannelType.GuildText]), ["General", ChannelType.GuildVoice]];
      for (const [channelName, type] of channels) {
        if (interaction.guild.channels.cache.some((channel) => channel.parentId === category.id && channel.name === channelName && channel.type === type)) continue;
        const channel = await interaction.guild.channels.create({ name: channelName, type, parent: category.id, reason: `Server builder requested by ${interaction.user.tag}` });
        created.push(`Channel: ${channel.name}`);
      }
    }
    await interaction.editReply({ content: created.length ? `Server build complete:\n${created.join("\n")}` : "All selected categories and channels already exist.", components: [] });
  } catch (error) {
    console.error(`Server builder failed for guild ${interaction.guildId}:`, error);
    const summary = created.length ? ` Already created:\n${created.join("\n")}` : "";
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply({ content: `Server build stopped. Check my permissions and run it again.${summary}`, components: [] });
    } else {
      throw error;
    }
  } finally {
    building.delete(interaction.guildId);
  }
  return true;
}
