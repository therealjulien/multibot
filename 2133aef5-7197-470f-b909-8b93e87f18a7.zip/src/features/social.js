import { getGuildFeatureData, updateGuildFeatureData } from "./store.js";

export async function setAfk(guildId, userId, reason) {
  const record = { reason, since: Date.now() };
  await updateGuildFeatureData(guildId, (guild) => {
    guild.afk ??= {};
    guild.afk[userId] = record;
  });
  return record;
}

export function getAfk(guildId, userId) {
  return getGuildFeatureData(guildId).then((guild) => guild.afk?.[userId] ?? null);
}

export async function clearAfk(guildId, userId) {
  const guild = await getGuildFeatureData(guildId);
  if (!guild.afk?.[userId]) return false;
  return updateGuildFeatureData(guildId, (guild) => {
    if (!guild.afk?.[userId]) return false;
    delete guild.afk[userId];
    return true;
  });
}

export async function setBirthday(guildId, userId, month, day) {
  const date = new Date(Date.UTC(2000, month - 1, day));
  if (date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
    throw new RangeError("Enter a valid month and day.");
  }
  const birthday = `${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  await updateGuildFeatureData(guildId, (guild) => {
    guild.birthdays ??= {};
    guild.birthdays[userId] = birthday;
  });
  return birthday;
}

export async function removeBirthday(guildId, userId) {
  return updateGuildFeatureData(guildId, (guild) => {
    if (!guild.birthdays?.[userId]) return false;
    delete guild.birthdays[userId];
    return true;
  });
}

export async function setBirthdayChannel(guildId, channelId) {
  return updateGuildFeatureData(guildId, (guild) => {
    guild.birthdayChannelId = channelId;
    if (!guild.birthdays) guild.birthdays = {};
    return channelId;
  });
}

export async function claimBirthdayAnnouncement(guildId, date) {
  return updateGuildFeatureData(guildId, (guild) => {
    if (guild.lastBirthdayAnnouncementDate === date) return false;
    guild.lastBirthdayAnnouncementDate = date;
    return true;
  });
}

export async function getBirthdays(guildId) {
  const guild = await getGuildFeatureData(guildId);
  return {
    channelId: guild.birthdayChannelId ?? null,
    lastAnnouncementDate: guild.lastBirthdayAnnouncementDate ?? null,
    birthdays: Object.entries(guild.birthdays ?? {})
      .map(([userId, date]) => ({ userId, date }))
      .sort((left, right) => left.date.localeCompare(right.date)),
  };
}

export function createCustomCommandStore(featureStore = {
  getGuild: getGuildFeatureData,
  updateGuild: updateGuildFeatureData,
}) {
  return {
    add(guildId, name, response) {
      return featureStore.updateGuild(guildId, (guild) => {
        guild.customCommands ??= {};
        if (["__proto__", "constructor", "prototype"].includes(name)) {
          return { added: false, reason: "invalid" };
        }
        if (!Object.hasOwn(guild.customCommands, name) && Object.keys(guild.customCommands).length >= 25) {
          return { added: false, reason: "limit" };
        }
        if (Object.hasOwn(guild.customCommands, name)) return { added: false, reason: "exists" };
        guild.customCommands[name] = response;
        return { added: true };
      });
    },

    update(guildId, name, response) {
      return featureStore.updateGuild(guildId, (guild) => {
        if (!guild.customCommands || !Object.hasOwn(guild.customCommands, name)) return false;
        guild.customCommands[name] = response;
        return true;
      });
    },

    remove(guildId, name) {
      return featureStore.updateGuild(guildId, (guild) => {
        if (!guild.customCommands || !Object.hasOwn(guild.customCommands, name)) return false;
        delete guild.customCommands[name];
        return true;
      });
    },

    async get(guildId, name) {
      const guild = await featureStore.getGuild(guildId);
      return guild.customCommands?.[name] ?? null;
    },

    async list(guildId) {
      const guild = await featureStore.getGuild(guildId);
      return Object.keys(guild.customCommands ?? {}).sort();
    },
  };
}

const customCommandStore = createCustomCommandStore();

export const addCustomCommand = customCommandStore.add;
export const updateCustomCommand = customCommandStore.update;
export const removeCustomCommand = customCommandStore.remove;
export const getCustomCommand = customCommandStore.get;
export const listCustomCommands = customCommandStore.list;

export async function setProfile(guildId, userId, bio) {
  return updateGuildFeatureData(guildId, (guild) => {
    guild.profiles ??= {};
    guild.profiles[userId] = { bio, updatedAt: Date.now() };
  });
}

export async function getProfile(guildId, userId) {
  const guild = await getGuildFeatureData(guildId);
  return guild.profiles?.[userId] ?? null;
}

export async function recordThanks(guildId, giverId, recipientId) {
  if (giverId === recipientId) return { recorded: false, reason: "self" };
  const now = Date.now();
  return updateGuildFeatureData(guildId, (guild) => {
    guild.thanks ??= { counts: {}, lastGave: {} };
    guild.thanks.counts ??= {};
    guild.thanks.lastGave ??= {};
    const previous = guild.thanks.lastGave[giverId] ?? 0;
    if (now - previous < 60_000) return { recorded: false, reason: "cooldown" };
    guild.thanks.lastGave[giverId] = now;
    guild.thanks.counts[recipientId] = (guild.thanks.counts[recipientId] ?? 0) + 1;
    return { recorded: true, count: guild.thanks.counts[recipientId] };
  });
}

export async function getThanksLeaderboard(guildId, limit = 10) {
  const guild = await getGuildFeatureData(guildId);
  return Object.entries(guild.thanks?.counts ?? {})
    .map(([userId, count]) => ({ userId, count }))
    .sort((left, right) => right.count - left.count || left.userId.localeCompare(right.userId))
    .slice(0, limit);
}
