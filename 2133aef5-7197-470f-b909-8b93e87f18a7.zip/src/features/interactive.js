import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
} from "discord.js";
import { getGuildFeatureData, updateGuildFeatureData } from "./store.js";

export const ticketOpenCustomId = "multibot:ticket:open";
export const ticketCloseCustomId = "multibot:ticket:close";
export const reactionRoleCustomId = (messageId) => `multibot:role:${messageId}`;
const openingTickets = new Set();
const restrictedRolePermissions = [
  PermissionFlagsBits.Administrator,
  PermissionFlagsBits.ManageGuild,
  PermissionFlagsBits.ManageRoles,
  PermissionFlagsBits.ManageChannels,
  PermissionFlagsBits.ViewAuditLog,
  PermissionFlagsBits.KickMembers,
  PermissionFlagsBits.BanMembers,
  PermissionFlagsBits.ManageMessages,
  PermissionFlagsBits.MentionEveryone,
  PermissionFlagsBits.ManageWebhooks,
  PermissionFlagsBits.ModerateMembers,
  PermissionFlagsBits.ManageThreads,
];

export function isSafeReactionRole(role) {
  return !restrictedRolePermissions.some((permission) => role.permissions.has(permission));
}

export async function saveReactionRole(guildId, messageId, roleId, channelId) {
  return updateGuildFeatureData(guildId, (guild) => {
    guild.reactionRoles ??= {};
    guild.reactionRoles[messageId] = { roleId, channelId };
  });
}

export async function removeReactionRole(guildId, messageId) {
  return updateGuildFeatureData(guildId, (guild) => {
    const panel = guild.reactionRoles?.[messageId];
    if (!panel) return null;
    delete guild.reactionRoles[messageId];
    return panel;
  });
}

export async function setTicketStaffRole(guildId, roleId) {
  return updateGuildFeatureData(guildId, (guild) => {
    guild.ticketStaffRoleId = roleId;
  });
}

async function handleReactionRole(interaction, messageId) {
  const guildData = await getGuildFeatureData(interaction.guildId);
  const panel = guildData.reactionRoles?.[messageId];
  const roleId = typeof panel === "string" ? panel : panel?.roleId;
  if (!roleId) {
    await interaction.reply({ content: "This role panel is no longer configured.", ephemeral: true });
    return;
  }

  const role = await interaction.guild.roles.fetch(roleId);
  const member = await interaction.guild.members.fetch(interaction.user.id);
  if (!role || !role.editable || !isSafeReactionRole(role)) {
    await interaction.reply({
      content: "I can't assign that role. Choose a role without server-management or moderation permissions, and check my role position.",
      ephemeral: true,
    });
    return;
  }

  if (member.roles.cache.has(role.id)) {
    await member.roles.remove(role, "Member toggled a Multibot role panel");
    await interaction.reply({ content: `Removed the **${role.name}** role.`, ephemeral: true });
  } else {
    await member.roles.add(role, "Member selected a Multibot role panel");
    await interaction.reply({ content: `Added the **${role.name}** role.`, ephemeral: true });
  }
}

async function openTicket(interaction) {
  const key = `${interaction.guildId}:${interaction.user.id}`;
  if (openingTickets.has(key)) {
    await interaction.reply({ content: "Your ticket is still being created. Please wait a moment.", ephemeral: true });
    return;
  }
  openingTickets.add(key);
  try {
    await createTicket(interaction);
  } finally {
    openingTickets.delete(key);
  }
}

async function createTicket(interaction) {
  const guildData = await getGuildFeatureData(interaction.guildId);
  const staffRoleId = guildData.ticketStaffRoleId;
  const staffRole = staffRoleId ? await interaction.guild.roles.fetch(staffRoleId) : null;
  if (!staffRole) {
    await interaction.reply({ content: "Tickets aren't configured yet. Ask an administrator to run `/tickets setup`.", ephemeral: true });
    return;
  }

  const topic = `multibot-ticket:${interaction.user.id}`;
  const existing = interaction.guild.channels.cache.find((channel) => channel.topic === topic);
  if (existing) {
    await interaction.reply({ content: `You already have an open ticket: ${existing}.`, ephemeral: true });
    return;
  }

  const botMember = interaction.guild.members.me;
  if (!botMember?.permissions.has(PermissionFlagsBits.ManageChannels)) {
    await interaction.reply({ content: "I need Manage Channels to create tickets.", ephemeral: true });
    return;
  }

  const channelName = `ticket-${interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "-").slice(0, 20)}`;
  const channel = await interaction.guild.channels.create({
    name: channelName,
    type: ChannelType.GuildText,
    topic,
    permissionOverwrites: [
      { id: interaction.guildId, deny: [PermissionFlagsBits.ViewChannel] },
      {
        id: interaction.user.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
        ],
      },
      {
        id: staffRole.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.ManageMessages,
        ],
      },
      {
        id: botMember.id,
        allow: [
          PermissionFlagsBits.ViewChannel,
          PermissionFlagsBits.SendMessages,
          PermissionFlagsBits.ReadMessageHistory,
          PermissionFlagsBits.ManageChannels,
        ],
      },
    ],
    reason: `Support ticket opened by ${interaction.user.tag}`,
  });

  try {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(ticketCloseCustomId)
        .setLabel("Close ticket")
        .setStyle(ButtonStyle.Danger)
    );
    await channel.send({
      content: `<@${interaction.user.id}> <@&${staffRole.id}>`,
      embeds: [{
        title: "Support ticket",
        description: "Describe what you need help with. A staff member will be with you soon.",
      }],
      components: [row],
      allowedMentions: { users: [interaction.user.id], roles: [staffRole.id] },
    });
  } catch (error) {
    try {
      await channel.delete("Could not send the ticket welcome message");
    } catch (cleanupError) {
      console.error(`Could not clean up ticket channel ${channel.id}:`, cleanupError);
    }
    throw error;
  }
  await interaction.reply({ content: `Your ticket is ready: ${channel}.`, ephemeral: true });
}

async function closeTicket(interaction) {
  const channel = interaction.channel;
  const match = channel?.topic?.match(/^multibot-ticket:(\d+)$/);
  if (!match) {
    await interaction.reply({ content: "This isn't an active Multibot ticket.", ephemeral: true });
    return;
  }

  const guildData = await getGuildFeatureData(interaction.guildId);
  const isOwner = interaction.user.id === match[1];
  const member = await interaction.guild.members.fetch(interaction.user.id);
  const isStaff = guildData.ticketStaffRoleId && member.roles.cache.has(guildData.ticketStaffRoleId);
  const canManage = interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels);
  if (!isOwner && !isStaff && !canManage) {
    await interaction.reply({ content: "Only the ticket owner or server staff can close this ticket.", ephemeral: true });
    return;
  }

  await interaction.deferReply({ ephemeral: true });
  await channel.permissionOverwrites.edit(match[1], {
    SendMessages: false,
  }, { reason: `Ticket closed by ${interaction.user.tag}` });
  await channel.setTopic(`multibot-ticket-closed:${match[1]}`, `Ticket closed by ${interaction.user.tag}`);
  if (!channel.name.startsWith("closed-")) {
    await channel.setName(`closed-${channel.name}`.slice(0, 100), `Ticket closed by ${interaction.user.tag}`);
  }
  await interaction.message.edit({ components: [] });
  await interaction.editReply("Ticket closed. Staff can delete the channel when the conversation is complete.");
}

export async function handleFeatureButton(interaction) {
  const roleMatch = interaction.customId.match(/^multibot:role:(\d+)$/);
  if (roleMatch) {
    await handleReactionRole(interaction, roleMatch[1]);
    return true;
  }
  if (interaction.customId === ticketOpenCustomId) {
    await openTicket(interaction);
    return true;
  }
  if (interaction.customId === ticketCloseCustomId) {
    await closeTicket(interaction);
    return true;
  }
  return false;
}
