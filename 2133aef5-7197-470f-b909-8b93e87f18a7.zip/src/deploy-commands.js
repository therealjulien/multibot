import "dotenv/config";
import { Client, Events, GatewayIntentBits, REST, Routes } from "discord.js";
import { commands } from "./commands.js";

const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;

if (!DISCORD_TOKEN || !CLIENT_ID) {
  throw new Error("Set DISCORD_TOKEN and CLIENT_ID in your .env file before deploying commands.");
}

const rest = new REST({ version: "10" }).setToken(DISCORD_TOKEN);
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const ready = new Promise((resolve, reject) => {
  client.once(Events.ClientReady, resolve);
  client.once(Events.Error, reject);
});

try {
  await client.login(DISCORD_TOKEN);
  await ready;

  await rest.put(Routes.applicationCommands(CLIENT_ID), {
    body: commands.map((command) => command.data.toJSON()),
  });

  const guildIds = [...client.guilds.cache.keys()];
  for (const guildId of guildIds) {
    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, guildId), { body: [] });
  }
  console.log(
    `Registered ${commands.length} global slash commands and removed per-server duplicates from ${guildIds.length} server(s).`
  );
} finally {
  client.destroy();
}
